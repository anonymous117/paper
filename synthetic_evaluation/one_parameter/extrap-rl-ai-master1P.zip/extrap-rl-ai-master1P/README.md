# ExtraP Sparse Modeling with Reinforcement Learning

*Special version of the master branch to do the synthetic evaluation of the 1 parameter modeler, with terms and scaling analysis for different repetitions and point lengths.*
  

---

This project contains the source code and version of Extra-P that was used for the data generation, evaluation and analysis of the "IPDPS" paper. It also contains additional evaluation code and testes methods.

## Master branch

The code in this branch was used for the synthetic evaluation of the new sparse modeler. For the code the ml was tested with see the 3ParameterSupport branch!

## How to use Docker to run ExtraP ML version with GPU support

`docker build -t <extrap-ml> .`  
`docker run -i -t --name <test> <extrap-ml>`  
`docker stop <name>`  
`docker rmi <name>`  
`docker rm <name>`  
`docker start <name>`  
`docker exec -i -t <name> /bin/bash`  
`docker exec -itd artemis /extrap/bin/extrap-data run --name data0 -i 1000 -r 25 -n 0 -s 0 --count 0`  

## Using the tensorboard to visualize the Data and Network 

`tensorboard --logdir='logs'`

## Retrieving the Data from the Server

`sudo docker cp -a <container-id>:/home/marcus/results/. test/`  
`scp -r marcus@130.83.143.241:/home/marcus/results .`  

## Synthetic Data Evaluation of the Sparse Modeler

The memory on the system might not be enough to evaluate the sparse modeler e.g. for 100.000 functions at once. Therefore, the data generation and evaluation process can be splitted in several parts. They are saved as different runs and rebuilt with the evaluation script. The evaluation script transforms the massive amount of generated data into small results files, that contain all the necessary data to create the plots.

### Test Layout

The detailed configuration of a test is saved in a configuration file while generating the data. The following is an example for a configuration file:

```
generate model options: GENERATE_MODEL_MEAN
single parameter points strategy: CHEAPEST_POINTS
multi parameter points strategy: INCREASING_COST
number minimum points: 5
measurement points for p: [4,8,16,32,64]
measurement points for size: [10,20,30,40,50]
measurement points for n: [2,4,6,8,10]
noise percent: 0.0
epsilon, term contribution minimum: 1.0
```

In general the Sparse Modeler is tested for 100.000 functions each, with different configuration settings.

- Noise %: [0,1,2,5]
- Single Parameter Experiment Point Selection Strategy: [0,1,2]
  * FIRST_POINTS_FOUND
  * MAX_NUMBER_POINTS
  * CHEAPEST_POINTS
- Multi Parameter Experiment Point Selection Strategy: [0,1]
  * INCREASING_COST
  * DECREASING_COST
- Optional: change the minimum number of required points for the single parameter experiments
- Optional: change the coordinates used for the evaluation (not supported with the current code version!)

1. Evaluate the standard settings with different noise levels
2. Find the best selection strategy with the RL AI

### Evaluation Process

###### Data Generation

`extrap-data run [--name=<n>] [-i=<i>] [-r=<r>] [-n=<a>] [-s=<s>] [--count=<c>] [--minp=<x>] [--so=<y>] [--mo=<z>] [--debug]`  

```
--name=<n>      Select the source folder name for the evaluation.
-i=<i>          Number of iterations.
-r=<r>          Number of repetitions.
-n=<a>          Set the noise percent for the measurements.
-s=<s>          Set the seed.
--count=<c>     Set the start number for the output folders.
--debug         Set log level to debug. Lowest log level.
--minp=<x>      Set the minimum number of points required for the single parameter experiments [4,5].
--so=<y>        Set the option for the single parameter point selection strategy [0,1,2].
--mo=<z>        Set the option for the multi parameter point selection strategy [0,1].
```

`./extrap-data run --name alice -i 100 -r 10 -n 0 -s 0 --count 0`  
`./extrap-data run --name bob -i 100 -r 10 -n 0 -s 0 --count 10`

`docker exec -itd cortana /extrap/bin/extrap-data run --name alice -i 100 -r 1`  

Copy the inputs and ouputs data folders into one common base folder.

`mv bob/inputs/* alice/inputs/`  
`mv bob/outputs/* alice/outputs/`  

###### Data Evaluation

`extrap-eval run [--name=<n>] [-i=<i>] [-r=<r>] [--debug]`  

```
--name=<n>  Select the source folder name for the evaluation.
-i=<i>      Number of iterations.
-r=<r>      Number of repetitions.
--debug     Set log level to debug. Lowest log level.
```

`./extrap-eval run --name alice -i 100 -r 20`  

`docker exec -itd cortana /extrap/bin/extrap-eval run --name alice -i 100 -r 1`  

Make sure you double the amount of repetitions in this step when the data generation was splitted.

###### Plotting the Results

`extrap-charts run [--name=<n>] [-i=<i>] [-r=<r>] [--debug]`  

```
--debug     Enable debug logs.
--name=<n>  Select the source folder name for the evaluation.
-i=<i>      Number of iterations.
-r=<r>      Number of repetitions.
```

`./extrap-charts run --name alice -i 100 -r 20`  

Make sure to include the number of iterations and repetitions correctly, as they are important for plotting the data correctly.

###### Scaling Analysis

Use the scaling analysis script in order to create the plots for the scaling analysis. It is under root in the folder scripts.

`python3 analyze_scaling.py`  

