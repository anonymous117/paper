import math
import tkinter as tk
from tkinter import filedialog
import os

def parse_folder_name(folder_name):
    pos = folder_name.find('d')
    part2 = folder_name[pos:]
    part1 = folder_name[:pos]
    new = part1 + '.' + part2
    folder_name = new
    pos = folder_name.find('g')
    part2 = folder_name[pos:]
    part1 = folder_name[:pos]
    new = part1 + '.' + part2
    folder_name = new
    pos = len(folder_name)-2
    part2 = folder_name[pos:]
    part1 = folder_name[:pos]
    new = part1 + '.' + part2
    folder_name = new
    #print(folder_name)
    new_name = folder_name
    return new_name

def rename_folder(dir_path, old_name, new_name):
	old_name = dir_path + '/' + old_name
	new_name = dir_path + '/' + new_name
	#print(dir_path, old_name, new_name)
	os.rename(old_name, new_name)

if __name__== '__main__':
    #detect all dirs and their names in a dir
	#name = "i7j7k7p0016m1"
	#parse_folder_name(name)
	root = tk.Tk()
	root.withdraw()
	dir_path = filedialog.askdirectory()
	sub_dirs = []
	for x in os.walk(dir_path):
		sub_dirs.append(x[1])
	sub_dirs = sub_dirs[0]
	#print(sub_dirs)
	for i in range(len(sub_dirs)):
		folder_name = sub_dirs[i]
		#print(folder_name)
		new_folder_name = parse_folder_name(folder_name)
		#print(new_folder_name)
		rename_folder(dir_path, folder_name, new_folder_name)