import tkinter as tk
from tkinter import filedialog
import os
import sys

def select_folder():
    root = tk.Tk()
    root.withdraw()
    return filedialog.askdirectory()

def get_file_names(path):
	return os.listdir(path)

def check_for_parameters(function_term):
    pos1 = function_term.find("p")
    pos2 = function_term.find("size")
    if pos1==-1 and pos2==-1:
        return False
    else:
        return True

def parse_terms(terms):
    for j in range(len(terms)):
        terms[j] = terms[j].replace(" ", "")
    terms_copy = []
    for j in range(len(terms)):
        has_parameter = check_for_parameters(terms[j])
        if has_parameter==True:
            terms_copy.append(terms[j]) 
    for j in range(len(terms_copy)):
        temp = terms_copy[j]
        pos = temp.find("*")
        temp = temp[pos+1:]
        terms_copy[j] = temp
    return terms_copy

def search_term(base_terms, term):
    for i in range(len(base_terms)):
        if base_terms[i] == term:
            return True
    return False

def term_analysis(baseline_function, modeled_function):
    baseline_function = baseline_function[3:]
    baseline_function_terms = baseline_function.split("+")
    baseline_function_terms = parse_terms(baseline_function_terms)
    modeled_function = modeled_function[3:]
    modeled_function_terms = modeled_function.split("+")
    modeled_function_terms = parse_terms(modeled_function_terms)
    if len(baseline_function_terms)!=len(modeled_function_terms):
        return False
    else:
        normal_modeler_correct_terms = 0
        for i in range(len(baseline_function_terms)):
            modeler_function_string_term = modeled_function_terms[i]
            is_existing = search_term(baseline_function_terms, modeler_function_string_term)
            if is_existing==True:
                normal_modeler_correct_terms = normal_modeler_correct_terms + 1
        if len(baseline_function_terms) == normal_modeler_correct_terms:
            return True
        else:
            return False

if __name__ == '__main__':
    #1=normal modeler
    #2-17=sparse modelers
    modeler_number = int(input("Choose Modeler. 1=Normal Modeler. 2-17=Sparse Models."))
    path = select_folder()
    files = get_file_names(path)
    counter = 0
    for i in range(len(files)):
        file = files[i]
        src = path + '/' + file
        with open(src) as f:
            lines = f.readlines()
        for j in range(len(lines)):
            string = lines[j]
            lines[j] = string[:-1]
        baseline_function = lines[0]
        modeled_function = lines[modeler_number]
        all_terms_correct = term_analysis(baseline_function, modeled_function)
        if all_terms_correct == False:
            counter = counter + 1
            print("")
            print("Baseline Function: "+baseline_function)
            print("Modeled Function: "+modeled_function)
            print("Path: "+src)
    print("\n"+str(counter)+" functions found that were not correctly modeled!")