import math
import tkinter as tk
from tkinter import filedialog
import os

def parse_folder_name(folder_name):
	tmp = folder_name
	pos = tmp.find('p')
	tmp = tmp[pos+1:]
	pos = tmp.find("_")
	tmp = tmp[:pos]
	p = int(tmp)
	#print(p)

	tmp = folder_name
	pos = tmp.find('size')
	tmp = tmp[pos+len('size'):]
	pos = tmp.find(".")
	tmp = tmp[:pos]
	size = int(tmp)
	#print(size)

	tmp = folder_name
	pos = tmp.find('.')
	tmp = tmp[pos+2:]
	rep = int(tmp)
	#print(rep)

	prefix = 'relearn'
	new_name = prefix + '.p' + str(p) + '.size' + str(size) + '.r' + str(rep)
	#print(new_name)
	return new_name

def rename_folder(dir_path, old_name, new_name):
	old_name = dir_path + '/' + old_name
	new_name = dir_path + '/' + new_name
	print(dir_path, old_name, new_name)
	os.rename(old_name, new_name)

if __name__== '__main__':
        #detect all dirs and their names in a dir
	#name = "relearn_p4_size1500.r1"
	#parse_folder_name(name)

	root = tk.Tk()
	root.withdraw()
	dir_path = filedialog.askdirectory()
	sub_dirs = []
	for x in os.walk(dir_path):
		sub_dirs.append(x[1])
	sub_dirs = sub_dirs[0]
	#print(sub_dirs)
	for i in range(len(sub_dirs)):
		folder_name = sub_dirs[i]
		#print(folder_name)
		new_folder_name = parse_folder_name(folder_name)
		#print(new_folder_name)
		rename_folder(dir_path, folder_name, new_folder_name)
