/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_SingleParameterRefiningModelGenerator.hpp>
#include <EXTRAP_SingleParameterRefiningFunctionModeler.hpp>

namespace EXTRAP
{
const std::string SingleParameterRefiningModelGenerator::SINGLEPARAMETERREFININGMODELGENERATOR_PREFIX = "SingleParameterRefiningModelGenerator";

SingleParameterRefiningModelGenerator::SingleParameterRefiningModelGenerator()
{
    m_modeler = new SingleParameterRefiningFunctionModeler();
}

SingleParameterFunctionModeler&
SingleParameterRefiningModelGenerator::getFunctionModeler() const
{
    return *m_modeler;
}

bool
SingleParameterRefiningModelGenerator::serialize( IoHelper* ioHelper ) const
{
    SAFE_RETURN( ioHelper->writeString(  SINGLEPARAMETERREFININGMODELGENERATOR_PREFIX ) );
    //write id
    SAFE_RETURN( this->SingleParameterModelGenerator::serialize( ioHelper ) );
    return true;
}

SingleParameterRefiningModelGenerator*
SingleParameterRefiningModelGenerator::deserialize( IoHelper* ioHelper )
{
    SingleParameterRefiningModelGenerator* generator = new SingleParameterRefiningModelGenerator();
    generator->SingleParameterModelGenerator::deserialize( ioHelper );
    return generator;
}

bool
equal( const SingleParameterRefiningModelGenerator* lhs,
       const SingleParameterRefiningModelGenerator* rhs )
{
    if ( lhs == rhs )
    {
        return true;
    }
    if ( lhs == NULL || rhs == NULL )
    {
        return false;
    }
    bool result = true;
    result &= lhs->getCrossvalidationMethod() == rhs->getCrossvalidationMethod();
    result &= lhs->getEpsilon() == rhs->getEpsilon();
    result &= equal( lhs->getModelGeneratorOptions(), rhs->getModelGeneratorOptions() );
    return result;
}
}; // Close namespace
