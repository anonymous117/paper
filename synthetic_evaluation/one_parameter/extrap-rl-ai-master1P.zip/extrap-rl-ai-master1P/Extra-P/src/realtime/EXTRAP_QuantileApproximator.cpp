/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */
#include <config.h>
#include <EXTRAP_Interface.hpp>
#include <realtime/EXTRAP_QuantileApproximator.hpp>

#define BUCKET_COUNT 5

namespace EXTRAP
{
QuantileApproximator::QuantileApproximator( double quantilePercentage )
{
    this->p = quantilePercentage;

    for ( int i = 0; i < BUCKET_COUNT; i++ )
    {
        this->dn.push_back( BUCKET_COUNT * GetIncrement( i, p ) );
        this->n.push_back( i );
    }
}

EXTRAP::Value
QuantileApproximator::GetQuantileValue()
{
    if ( this->q.size() == 0 )
    {
        return 0.0;
    }
    else if ( this->q.size() == BUCKET_COUNT )
    {
        return this->q[ this->q.size() / 2 ];
    }

    return this->q[ this->q.size() * this->p ];

    /*if ( this->q.size() % 2 == 1 )
       {
        return this->q[ this->q.size() * this->p ];
       }
       else
       {
        return ( this->q[ this->q.size() * this->p - 1 ] + this->q[ this->q.size() * this->p ] ) / 2.0;
       }*/
}

double
QuantileApproximator::GetIncrement( int i, double p )
{
    if ( i < BUCKET_COUNT / 2 )
    {
        return BUCKET_COUNT / 2.0 * p * ( ( double )i / ( double )BUCKET_COUNT );
    }
    else if ( i == BUCKET_COUNT / 2 )
    {
        return p;
    }
    else
    {
        return p + ( 1.0 - p ) * ( ( i - ( double )( BUCKET_COUNT / 2 ) ) / ( double )( BUCKET_COUNT / 2 ) );
    }
}

void
QuantileApproximator::Update( EXTRAP::Value datapoint )
{
    if ( this->q.size() < BUCKET_COUNT )
    {
        int i = 0;
        for (; i < this->q.size(); i++ )
        {
            if ( datapoint <= this->q[ i ] )
            {
                break;
            }
        }
        this->q.insert( this->q.begin() + i, datapoint );
    }
    else
    {
        int k = -1;
        if ( datapoint < this->q[ 0 ] )
        {
            this->q[ 0 ] = datapoint;
            k            = 0;
        }
        else if ( datapoint >= this->q[ BUCKET_COUNT - 1 ] )
        {
            if ( datapoint > this->q[ BUCKET_COUNT - 1 ] )
            {
                this->q[ BUCKET_COUNT - 1 ] = datapoint;
            }
            k = BUCKET_COUNT - 1;
        }
        else
        {
            for ( int i = 1; i < BUCKET_COUNT; i++ )
            {
                if ( datapoint < this->q[ i ] )
                {
                    k = i - 1;
                    break;
                }
            }
        }

        for ( int i = 0; i < BUCKET_COUNT; i++ )
        {
            if ( i >= k )
            {
                this->n[ i ] += 1;
            }
            this->dn[ i ] = dn[ i ] + GetIncrement( i, this->p );
        }

        for ( int i = 1; i < BUCKET_COUNT - 1; i++ )
        {
            double d = this->dn[ i ] - this->n[ i ];

            if ( ( d >= 1 && this->n[ i + 1 ] - this->n[ i ] > 1 ) ||
                 ( d <= -1 && this->n[ i - 1 ] - this->n[ i ] < -1 ) )
            {
                d = d < 0 ? -1 : 1;
                double q = this->q[ i ] + ( d / ( this->n[ i + 1 ] - this->n[ i - 1 ] ) ) *
                           (
                    ( this->n[ i ] - this->n[ i - 1 ] + d ) * ( this->q[ i + 1 ] - this->q[ i ] ) / ( this->n[ i + 1 ] - this->n[ i ] ) +
                    ( this->n[ i + 1 ] - this->n[ i ] - d ) * ( this->q[ i ] - this->q[ i - 1 ] ) / ( this->n[ i ] - this->n[ i - 1 ] )
                           ) * ( this->n[ i ] + d );

                if ( this->q[ i - 1 ] < q && q < this->q[ i + 1 ] )
                {
                    this->q[ i ] = q;
                }
                else
                {
                    this->q[ i ] = this->q[ i ] + d * ( this->q[ i + d ] - this->q[ i ] ) / ( this->n[ i + d ] - this->n[ i ] );
                }

                this->n[ i ] += d;
            }
        }
    }
}
}; // Close namespace
