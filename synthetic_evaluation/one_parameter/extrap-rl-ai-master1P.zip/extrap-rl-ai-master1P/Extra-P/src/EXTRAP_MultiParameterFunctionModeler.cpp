/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_MultiParameterModelGenerator.hpp>
#include <EXTRAP_MultiParameterHypothesis.hpp>
#include <EXTRAP_MultiParameterFunction.hpp>
#include <EXTRAP_SingleParameterRefiningFunctionModeler.hpp>
#include <EXTRAP_SingleParameterSimpleFunctionModeler.hpp>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <cassert>

namespace EXTRAP
{
MultiParameterFunctionModeler::MultiParameterFunctionModeler()
{
    //TODO: simple modeler here for the evaluation
    m_single_parameter_function_modeler = new SingleParameterSimpleFunctionModeler();
    //m_single_parameter_function_modeler = new SingleParameterRefiningFunctionModeler();
}

MultiParameterFunction*
MultiParameterFunctionModeler::createConstantModel( const std::vector<DataPoint>& modeledDataPointList )

{
    MultiParameterFunction* constantFunction = new MultiParameterFunction();

    DebugStream << "Creating constant model." << std::endl;

    double meanModel = 0;

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        meanModel += modeledDataPointList[ i ].getValue() / ( double )modeledDataPointList.size();
    }

    constantFunction->setConstantCoefficient( meanModel );

    return constantFunction;
}
}; // Close namespace
