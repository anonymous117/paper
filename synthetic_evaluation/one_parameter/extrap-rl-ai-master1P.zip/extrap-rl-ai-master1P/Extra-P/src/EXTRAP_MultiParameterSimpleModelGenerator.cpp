/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_MultiParameterSimpleModelGenerator.hpp>
#include <EXTRAP_MultiParameterSimpleFunctionModeler.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
const std::string MultiParameterSimpleModelGenerator::MULTIPARAMETERSIMPLEMODELGENERATOR_PREFIX = "MultiParameterSimpleModelGenerator";

MultiParameterSimpleModelGenerator::MultiParameterSimpleModelGenerator()
{
    m_modeler = new MultiParameterSimpleFunctionModeler();
}

MultiParameterFunctionModeler&
MultiParameterSimpleModelGenerator::getFunctionModeler() const
{
    return *m_modeler;
}

bool
MultiParameterSimpleModelGenerator::serialize( IoHelper* ioHelper ) const
{
    SAFE_RETURN( ioHelper->writeString(  MULTIPARAMETERSIMPLEMODELGENERATOR_PREFIX ) );
    MultiParameterModelGenerator::serialize( ioHelper );
    return true;
}

MultiParameterSimpleModelGenerator*
MultiParameterSimpleModelGenerator::deserialize( IoHelper* ioHelper )
{
    MultiParameterSimpleModelGenerator* generator = new MultiParameterSimpleModelGenerator();
    generator->MultiParameterModelGenerator::deserialize( ioHelper );
    return generator;
}

bool
equal( const MultiParameterSimpleModelGenerator* lhs,
       const MultiParameterSimpleModelGenerator* rhs )
{
    if ( lhs == rhs )
    {
        return true;
    }
    if ( lhs == NULL || rhs == NULL )
    {
        return false;
    }
    bool result = true;
    result &= equal( lhs->getModelGeneratorOptions(), rhs->getModelGeneratorOptions() );
    return result;
}
}; // Close namespace
