# -*- coding: utf-8 -*-
##
## This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
##
## Copyright (c) 2016-2017,
## Technische Universitaet Darmstadt, Germany
##
## This software may be modified and distributed under the terms of
## a BSD-style license.  See the COPYING file in the package base
## directory for details.
##

import EXTRAP
import os
try:
   from PyQt4.QtGui import *
   from PyQt4.QtCore import *
except ImportError:
   from PyQt5.QtGui import *
   from PyQt5.QtCore import *
   from PyQt5.QtWidgets import *


class SingleParameterExhaustiveModeler(QWidget):
   
   def __init__(self, modelerWidget, parent):
      super(SingleParameterExhaustiveModeler, self).__init__(parent)

      self.modeler_widget = modelerWidget
      self.main_widget = modelerWidget.main_widget

      self.initUI()

   def initUI(self):
      
      grid = QGridLayout( self )
      self.setLayout( grid )

      label = QLabel( self )
      label.setText("Output file:")
      label.setFixedHeight(25)
      grid.addWidget( label, 0, 0, 1, 2 )

      self.output_file_edit = QLineEdit(self)
      self.output_file_edit.setText( os.path.abspath( "generated_models.csv" ))
      grid.addWidget( self.output_file_edit, 1, 0, 1, 1 )

      choose_file_button = QPushButton(self)
      choose_file_button.setText( "Choose")
      choose_file_button.pressed.connect( self.chooseFile )
      grid.addWidget(choose_file_button, 1, 1, 1, 1)

      model_button = QPushButton(self)
      model_button.setText( "Generate models")
      model_button.pressed.connect( self.generate )
      
      grid.addWidget( model_button, 4, 0, 1, 2)

      widget = QWidget( self )
      widget.setMinimumHeight( self.height() - 120 )
      grid.addWidget( widget, 5, 0)

   def getName(self):
      return "Exhaustive Model Generator"

   def chooseFile(self):
      new_filename = self.main_widget.get_file_name(QFileDialog.getSaveFileName( self,
                                   self.tr( "Save As" ),
                                   self.output_file_edit.text(),
                                   "CSV files (*.csv)" ))
      self.output_file_edit.setText(new_filename)

   def generate(self):
      
      modeler = EXTRAP.SingleParameterExhaustiveModelGenerator()
      options = EXTRAP.ModelGeneratorOptions()

      #init the optins
      options.setMinNumberPoints(5)
      options.setUseAddPoints(False)
      options.setNumberAddPoints(0)
      options.setSinglePointsStrategy(EXTRAP.FIRST_POINTS_FOUND)
      options.setMultiPointsStrategy(EXTRAP.INCREASING_COST)

      modeler.openOutputFile(self.output_file_edit.text())

      self.modeler_widget.onGenerate( modeler, options )
      
      '''
      #TODO: this code does not work because of the new model options!
      metric = self.main_widget.getSelectedMetric()
      experiment = self.main_widget.getExperiment()
      callpaths = experiment.getAllCallpaths()
      for i in range(0, callpaths.size()):
         callpath = callpaths[i]
         points = experiment.getPoints(metric, callpath)
         modeler.setFunctionName(callpath.getFullName())
         modeler.createModel(points) # create model(s) and ignore the results
      '''

      modeler.closeOutputFile()