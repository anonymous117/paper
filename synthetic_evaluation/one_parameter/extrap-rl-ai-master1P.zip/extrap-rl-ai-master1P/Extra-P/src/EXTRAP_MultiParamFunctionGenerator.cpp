/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_MultiParameterFunction.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_MultiParamFunctionGenerator.hpp>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <iostream>

namespace EXTRAP
{
MultiParamFunctionGenerator::MultiParamFunctionGenerator( const FunctionCategory       functionCat,
                                                          const int                    terms,
                                                          const EXTRAP::ParameterList& parameterNames,
                                                          const double                 epsilon,
                                                          const int seed )
    : FunctionGenerator( functionCat, terms ), m_paramList( parameterNames )
{
    m_epsilon = epsilon;
    srand( seed );
}

EXTRAP::Function*
MultiParamFunctionGenerator::getFunction()
{
    //needed to evaluate the term contributions
    /*
    const int        p_min    = 4;
    const int        p_max    = 64;
    const int        size_min = 10;
    const int        size_max = 50;
    const int n_min = 2;
    const int n_max = 10;
    std::vector<int> mins;
    mins.push_back( p_min );
    mins.push_back( size_min );
    mins.push_back( n_min );
    std::vector<int> maxs;
    maxs.push_back( p_max );
    maxs.push_back( size_max );
    maxs.push_back( n_max );
    */

    EXTRAP::MultiParameterFunction* function = new EXTRAP::MultiParameterFunction();

    function->setConstantCoefficient( getRandomCoeff() );
    if ( m_functionCat == EXTRAP::CONST_CAT )
    {
        return function;
    }

    function->getMultiParameterTerms().clear();

    EXTRAP::MultiParameterTerm multi_term;
    FunctionCategory           ac_cat[ m_paramList.size() ];
    bool                       is_triv[ m_paramList.size() ];
    for ( int j = 0; j < m_paramList.size(); ++j )
    {
        EXTRAP::CompoundTerm comp_term;
        generateCompoundTerm( comp_term, ac_cat[ j ], is_triv[ j ] );
        multi_term.addCompoundTermParameterPair( comp_term, m_paramList[ j ] );
    }
    double rand_coeff = getRandomCoeff();
    multi_term.setCoefficient( rand_coeff );
    function->addMultiParameterTerm( multi_term );
    return function;
}

bool
MultiParamFunctionGenerator::flipCoin()
{
    double u = drand48();
    return u >= 0.5;
}

int
MultiParamFunctionGenerator::randomSwitch( int min, int max )
{
    int output = min + ( rand() % static_cast<int>( max - min + 1 ) );
    return output;
}
}
