/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <EXTRAP_ModelGeneratorOptions.hpp>
#include <EXTRAP_Interface.hpp>

namespace EXTRAP
{
ModelGeneratorOptions::ModelGeneratorOptions()
{
}

ModelGeneratorOptions::~ModelGeneratorOptions()
{
}

void
ModelGeneratorOptions::setGenerateModelOptions( GenerateModelOptions value )
{
    generate_model_options = value;
}

GenerateModelOptions
ModelGeneratorOptions::getGenerateModelOptions( void )
{
    return generate_model_options;
}

void
ModelGeneratorOptions::setMinNumberPoints( int value )
{
    min_number_points = value;
}

int
ModelGeneratorOptions::getMinNumberPoints( void )
{
    return min_number_points;
}

void
ModelGeneratorOptions::setSinglePointsStrategy( SparseModelerSingleParameterStrategy value )
{
    single_points_strategy = value;
}

SparseModelerSingleParameterStrategy
ModelGeneratorOptions::getSinglePointsStrategy( void )
{
    return single_points_strategy;
}

void
ModelGeneratorOptions::setUseAddPoints( bool value )
{
    use_add_points = value;
}

bool
ModelGeneratorOptions::getUseAddPoints( void )
{
    return use_add_points;
}

void
ModelGeneratorOptions::setNumberAddPoints( int value )
{
    number_add_points = value;
}

int
ModelGeneratorOptions::getNumberAddPoints( void )
{
    return number_add_points;
}

void
ModelGeneratorOptions::setMultiPointsStrategy( SparseModelerMultiParameterStrategy value )
{
    multi_points_strategy = value;
}

SparseModelerMultiParameterStrategy
ModelGeneratorOptions::getMultiPointsStrategy( void )
{
    return multi_points_strategy;
}

bool
equal( const ModelGeneratorOptions lhs,
       const ModelGeneratorOptions rhs )
{
    ModelGeneratorOptions o1 = lhs;
    ModelGeneratorOptions o2 = rhs;
    if ( o1.getGenerateModelOptions() == o2.getGenerateModelOptions() )
    {
        if ( o1.getMinNumberPoints() == o2.getMinNumberPoints() )
        {
            if ( o2.getSinglePointsStrategy() == o2.getSinglePointsStrategy() )
            {
                if ( o1.getUseAddPoints() == o2.getUseAddPoints() )
                {
                    if ( o1.getNumberAddPoints() == o2.getNumberAddPoints() )
                    {
                        if ( o1.getMultiPointsStrategy() == o2.getMultiPointsStrategy() )
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}
};
