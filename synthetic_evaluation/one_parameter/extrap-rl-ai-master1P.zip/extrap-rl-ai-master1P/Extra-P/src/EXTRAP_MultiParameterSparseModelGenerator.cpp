/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_MultiParameterSparseModelGenerator.hpp>
#include <EXTRAP_MultiParameterSparseFunctionModeler.hpp>

namespace EXTRAP
{
const std::string MultiParameterSparseModelGenerator::MULTIPARAMETERSPARSEMODELGENERATOR_PREFIX = "MultiParameterSparseModelGenerator";

MultiParameterSparseModelGenerator::MultiParameterSparseModelGenerator()
{
    m_modeler = new MultiParameterSparseFunctionModeler();
}

MultiParameterFunctionModeler&
MultiParameterSparseModelGenerator::getFunctionModeler() const
{
    return *m_modeler;
}

bool
MultiParameterSparseModelGenerator::serialize( IoHelper* ioHelper ) const
{
    SAFE_RETURN( ioHelper->writeString(  MULTIPARAMETERSPARSEMODELGENERATOR_PREFIX ) );
    MultiParameterModelGenerator::serialize( ioHelper );
    return true;
}

MultiParameterSparseModelGenerator*
MultiParameterSparseModelGenerator::deserialize( IoHelper* ioHelper )
{
    MultiParameterSparseModelGenerator* generator = new MultiParameterSparseModelGenerator();
    generator->MultiParameterModelGenerator::deserialize( ioHelper );
    return generator;
}

bool
equal( const MultiParameterSparseModelGenerator* lhs,
       const MultiParameterSparseModelGenerator* rhs )
{
    if ( lhs == rhs )
    {
        return true;
    }
    if ( lhs == NULL || rhs == NULL )
    {
        return false;
    }
    bool result = true;
    result &= equal( lhs->getModelGeneratorOptions(), rhs->getModelGeneratorOptions() );
    return result;
}
}; // Close namespace
