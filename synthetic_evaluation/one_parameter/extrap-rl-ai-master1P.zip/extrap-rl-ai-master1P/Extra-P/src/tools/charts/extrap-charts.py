##/*
## * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
## *
## * Copyright (c) 2019,
## * Technische Universitaet Darmstadt, Germany
## *
## * This software may be modified and distributed under the terms of
## * a BSD-style license.  See the COPYING file in the package base
## * directory for details.
## *
## */

"""Extra-P Chart Tool.

Usage:
  extrap-charts run [--name=<n>] [-i=<i>] [-r=<r>] [--debug]
  extrap-charts -h | --help
  extrap-charts --version

Options:
  --debug   Enable debug logs.
  --name=<n>    Select the source folder name for the evaluation.
  -i=<i>    Number of iterations.
  -r=<r>    Number of repetitions.
"""

import logging
import sys
import os
import shutil
import re
import numpy as np
import matplotlib.pyplot as plt
import csv
import EXTRAP
from math import *
from extrap.docopt import docopt
from extrap.docopt import docopt
from extrap.util import ModelerResult
from extrap.util import InputFile
from extrap.util import Parameter
from extrap.util import Metric
from extrap.util import MeasurementPoint
from extrap.util import Measurement
from extrap.util import BaselineFunction

def plot_relative_error(relative_errors, n):
    plt.rcdefaults()
    fig, ax = plt.subplots()
    labels = []
    labels.append("B125")
    for i in range(126):
        if i >=13 and i <=125:
            labels.append("B"+str(i))

    print(len(relative_errors))
    print(relative_errors)
    print(len(labels))
    print(labels)

    modeler = (labels)
    y_pos = np.arange(len(modeler))
    ax.barh(y_pos, relative_errors, align='center', color='blue')
    ax.set_yticks(y_pos)
    ax.set_yticklabels(modeler)
    ax.set_xscale('log')
    ax.invert_yaxis()  # labels read top-to-bottom
    ax.set_xlabel(u'Relative error [%]')
    plt.show()

def make_plot_1(term_data, percentage_errors):
    zero = []
    one = []
    two = []
    for i in range(len(term_data)):
        zero.append(term_data[i][0])
        one.append(term_data[i][1])
        two.append(term_data[i][2])
    ind = np.arange(len(zero))
    width = 0.2
    fig, ax = plt.subplots()
    rects1 = ax.bar(ind-width, zero, width, color='red', label='model is incorrect')
    rects2 = ax.bar(ind, one, width, color='orange', label='lead order term correct')
    rects3 = ax.bar(ind+width, two, width, color='green', label='model is identical')
    ax2 = ax.twinx()
    ax2.semilogy(ind, percentage_errors, "b-^")
    #ax2.plot(ind, percentage_errors, "b^-")
    ax2.set_ylabel('Relative error [%]')
    ax.set_ylabel('Model prediction [%]')
    #ax.set_title('title')
    ax.set_xticks(ind)
    ax.set_xticklabels(('N25', 'S9', 'S10', 'S11', 'S12', 'S13', 'S14', 'S15', 'S16', 'S17', 'S18', 'S19', 'S20', 'S21', 'S22', 'S23', 'S24', 'S25'))
    ax.set_xlabel('Modeler')
    fig.tight_layout()
    ax.legend(loc='upper right')
    plt.show()

def load_csv(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        data = list(reader)
    return data

def set_log_level(arguments):
    if arguments['--debug']:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

def convert_data(data):
    output = []
    for i in range(len(data)):
        output.append(float(data[i][0]))
    return output

def convert_data2(data):
    output = []
    for i in range(len(data)):
        temp = []
        temp.append(float(data[i][0]))
        temp.append(float(data[i][1]))
        temp.append(float(data[i][2]))
        output.append(temp)
    return output

if __name__ == '__main__':
    args = docopt(__doc__, version='Extra-P Chart Tool.')
    set_log_level(args)

    if args['run']:
        # check options parsed
        if args['--name']:
            folder_name = str(args['--name'])
        number_function_terms = 2
        if args['-i']:
            iterations = int(args['-i'])
        else:
            iterations = 100
        if args['-r']:
            repetitions = int(args['-r'])
        else:
            repetitions = 10
        logging.info("Running chart tool for outputs in folder '"+str(folder_name)+"' with "+str(repetitions)+" repetitions and "+str(iterations)+" iterations.")
        number_of_functions = iterations * repetitions

        # path for save files
        path = "/home/marcus/"+folder_name+"/"

        # load all data for plotting
        relative_errors = load_csv(path+"relative_errors.csv")
        relative_errors = convert_data(relative_errors)
        absolute_term_data = load_csv(path+"absolute_term_data.csv")
        absolute_term_data = convert_data2(absolute_term_data)
        percentage_errors = load_csv(path+"percentage_errors.csv")
        percentage_errors = convert_data(percentage_errors)
        percentage_term_data = load_csv(path+"percentage_term_data.csv")
        percentage_term_data = convert_data2(percentage_term_data)
       
        # plot relative error by modeler
        plot_relative_error(relative_errors, number_of_functions)
        
        # plot term analysis and percentage error by modeler
        make_plot_1(percentage_term_data, percentage_errors)

        logging.info("Chart tool finished. Results saved to "+str(path)+".")