import EXTRAP

from extrap.TrainingDataGenerator import TrainingDataGenerator
from extrap.Environment import Environment
from extrap.Agent import Agent

from extrap.Reward2 import Reward2
from extrap.Actions import Actions
from extrap.MPE import MPE
from extrap.Heatmap import Heatmap

from extrap.Util import read_ml_evaluation_config
from extrap.Util import read_environment_config

if __name__ == "__main__":

    '''
    Read machine learning config file
    '''
    ml_config = read_ml_evaluation_config()
    evaluation_episodes = ml_config["episodes"]
    alpha = ml_config["learning_rate"]
    reward_decay = ml_config["reward_decay"]
    learning_update_frequency = ml_config["learning_update_frequency"]
    replace_target_iter = ml_config["replace_target_network"]
    memory_size = ml_config["memory_size"]
    batch_size = ml_config["batch_size"]
    replay_start_size = ml_config["replay_start_size"]
    final_exploration = ml_config["final_exploration"]
    epsilon_max = ml_config["epsilon_max"]
    epsilon_min = ml_config["epsilon_min"]
    epsilon_upgrade_frequency = ml_config["epsilon_upgrade_frequency"]

    '''
    Read environment config file
    '''
    ev_config = read_environment_config()
    number_parameters = len(ev_config["parameters"])
    parameters = ev_config["parameters"]
    repetitions = ev_config["repetitions"]
    parameter_values = []
    for i in range(number_parameters):
        p_name = "p"+str(i+1)
        parameter_values.append(ev_config[p_name])
    if ev_config["use_seed"] == 0:
        use_seed = False
    else:
        use_seed = True
    evaluation_seed = ev_config["evaluation_seed"]
    noise = ev_config["noise"]
    term_contribution = ev_config["term_contribution"]

    '''
    Initialize global variables
    '''
    evaluation_rewards = []
    #evaluation_max_rewards = []
    evaluation_mpe = []
    evaluation_n_selected_points = []
    evaluation_selected_points = []
    # the number of actions equals the measurement points that are available
    n_actions = 1
    for i in range(number_parameters):
        n_actions *= len(parameter_values[i])
    # * 8 for the search space history
    n_features = n_actions * 8

    '''
    Create Evaluation Data
    '''
    evaluation_data_generator = TrainingDataGenerator(use_seed, evaluation_seed, noise, term_contribution, repetitions, parameters, parameter_values)
    evaluation_data = evaluation_data_generator.create_training_data_set(evaluation_episodes)

    '''
    Create the Agent
    '''
    test_agent = Agent(n_actions, n_features, epsilon_max, epsilon_min, alpha, reward_decay, replace_target_iter, memory_size, batch_size, replay_start_size, final_exploration, epsilon_upgrade_frequency)

    '''
    Load NN
    '''
    test_agent.load_NN()

    '''
    Evaluate the agent for n episodes
    '''
    test_agent.set_epsilon(0.05)
    for i in range(evaluation_episodes):
        env = Environment(evaluation_data[i], n_actions, False, parameter_values)
        state = env.get_state()
        while True:
            action = test_agent.choose_action(state, env)
            state_, reward, done = env.step(action)
            state = state_
            if done == True:
                n_selected_points = env.get_number_selected_points()
                mpe = env.get_mpe()
                selected_points = env.get_selected_points()
                evaluation_rewards.append(reward)
                evaluation_n_selected_points.append(n_selected_points)
                evaluation_mpe.append(mpe)
                evaluation_selected_points.append(selected_points[0])
                #evaluation_max_rewards.append(env.get_max_reward())
                break

    '''
    Analyze rewards
    '''
    #test_reward = Reward2(evaluation_rewards, evaluation_max_rewards)
    #test_reward.plot()

    '''
    Analyze actions
    '''
    #training_actions = Actions(evaluation_n_selected_points)
    #training_actions.plot()
    #training_actions.calc_average_number_actions()

    '''
    Analyze mpe
    '''
    #evaluation_mpe = MPE(evaluation_mpe)
    #evaluation_mpe.plot()
    #evaluation_mpe.calc_average_mpe()

    '''
    Data for point selection heatmap
    '''
    heatmap = Heatmap(evaluation_selected_points)
    heatmap.plot()
    heatmap.save()
