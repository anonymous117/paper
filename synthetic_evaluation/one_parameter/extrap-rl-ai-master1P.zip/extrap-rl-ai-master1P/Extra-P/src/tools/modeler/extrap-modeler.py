##/*
## * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
## *
## * Copyright (c) 2016-2019,
## * Technische Universitaet Darmstadt, Germany
## *
## * This software may be modified and distributed under the terms of
## * a BSD-style license.  See the COPYING file in the package base
## * directory for details.
## *
## */
""" Extrap modeler.

Usage:
  extrap-modeler input <inputfile> [-o <out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>] [--debug]
  extrap-modeler cube <cubedir> [-o <out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>] [options] [--debug]
  extrap-modeler json <jsonfile> [-o <out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>] [--debug]
  extrap-modeler -h | --help
  extrap-modeler --version

Options:
  -o=<out>                 Write output to <out> [default: ./out].
  --simple                 Use simple modeler (else use refining modeler)
  --poly=<poly>            Polynomial exponents for simple modeler e.g. '1.0,1.5,1.8'
  --log=<log>              Logarithm exponents for simple modeler e.g. '1.0,1.5,1.8'
  --model=<m>              Model (means | medians) [default: means]
  --modelname=<n>          Model name [default: default]
  --filename=<filename>    Cube files filename [default: profile.cubex]
  --parameter1=<parameter> Cube files parameter name 1 (disables parameter auto detection)
  --parameter2=<parameter> Cube files parameter name 2 (disables parameter auto detection)
  --parameter3=<parameter> Cube files parameter name 3 (disables parameter auto detection)
  --parameter4=<parameter> Cube files parameter name 4 (disables parameter auto detection)
  --parameter5=<parameter> Cube files parameter name 5 (disables parameter auto detection)
  --values1=<values>       Cube files values for parameter 1, e.g. '32,64,128' (disables values auto detection).
  --values2=<values>       Cube files values for parameter 2, e.g. '32,64,128' (disables values auto detection).
  --values3=<values>       Cube files values for parameter 3, e.g. '32,64,128' (disables values auto detection).
  --values4=<values>       Cube files values for parameter 4, e.g. '32,64,128' (disables values auto detection).
  --values5=<values>       Cube files values for parameter 5, e.g. '32,64,128' (disables values auto detection).
  --prefix=<prefix>        Cube files prefix (disables prefix auto detection).
  --postfix=<postfix>      Cube files postfix (disables postfix auto detection).
  --scaling=<scaling>      Cube files scaling (weak | strong) [default: weak]
  --repetitions=<reps>     Cube files repetitions (disables repetitions auto detection).
  -h --help                Show this screen.
  --version                Show version.
  --debug                  Enable debug logs.
"""

import logging
import sys
import os
import re

import EXTRAP
from extrap.docopt import docopt


def py_int_list_to_int_vector(py_int_list):
    """
    Returns int vector with the same content as py int list
    :param py_int_list: python int list
    :return: int vector with the same content as py int list
    """
    numbers = EXTRAP.StdVectorInt()
    for num in py_int_list:
        numbers.push_back(num)
    return numbers


def py_double_list_to_double_vector(py_double_list):
    """
    Returns double vector with the same content as py double list
    :param py_double_list: python double list
    :return: double vector with the same content as py double list
    """
    numbers = EXTRAP.StdVectorDouble()
    for num in py_double_list:
        numbers.push_back(float(num))
    return numbers


def default_cube_options():
    """
    Returns default options for cube files opening process
    :return: default options for cube files opening process
    """
    options = {'filename': 'profile.cubex', 'parameter1': 'p', 'prefix': 'unknown', 'postfix': '',
               'values1': [2, 4, 8, 16, 32, 64], 'repetitions': 4, 'scaling': 1}
    return options


def parse_cube_files(dir_name):
    """
    Returns regexp pattern matching results for each cube file inside dir name
    :param dir_name: cube files path (directory name)
    :return: regexp pattern matching results for each cube file inside dir name
    """
    cube_file_regex = re.compile(r"^([^.]+[_\.])([^\d]+)(\d+)[_\.]r(\d+)$")
    matches = [cube_file_regex.match(d) for d in os.listdir(dir_name)]
    return [m for m in matches if m is not None]


def create_model(args,multiparam):
    """
    Returns model for modeler depending on args provided by the user.
    :param args: arguments parsed from command line
    :return: model for modeler depending on options provided by the user.
    """
    # Run the multi parameter sparse modeler
    if multiparam or args['--parameter2'] and args['--values2']:
        logging.debug("using multi-parameter sparse-model generator")
        #TODO: instantiate the sparse modeler
        #modeler = EXTRAP.MultiParameterSimpleModelGenerator()
        return modeler
    # Run the single parameter function modeler
    if args['--simple']:
        logging.debug("using simple model generator")
        modeler = EXTRAP.SingleParameterSimpleModelGenerator()
        if args['--poly']:
            polynomial_exponents = [float(e) for e in args['--poly'].split(',')]
            logging.debug("polynomial exponents: %s", polynomial_exponents)
        else:
            print("[Extra-P] Missing --poly argument for the simple modeler.")
            sys.exit(-1)
        if args['--log']:
            logarithm_exponents = [float(e) for e in args['--log'].split(',')]
            logging.debug("logarithm exponents: %s", logarithm_exponents)
        else:
            print("[Extra-P] Missing --log argument for the simple modeler.")
            sys.exit(-1)
        modeler.generateHypothesisBuildingBlockSet(
            py_double_list_to_double_vector(polynomial_exponents),
            py_double_list_to_double_vector(logarithm_exponents))
        if args['<terms>']:
            terms = int(args['<terms>'])
        else:
            print("[Extra-P] Missing <terms> argument for the simple modeler.")
            sys.exit(-1)
        modeler.setMaxTermCount( terms )
        modeler.setEpsilon(0.01)
    else:  # refining
        logging.debug("using refining model generator")
        modeler = EXTRAP.SingleParameterRefiningModelGenerator()
    return modeler


#TODO: run sparse modeler as new standard for 2+ parameter experiments
def model_all(experiment, args):
    """
    Add model to experiment.
    :param experiment:
    :param args: arguments parsed from command line
    :return: None (updates experiment)
    """
    modeler = create_model(args,experiment.getParameters().size() > 1)
    modeler.setUserName(args['--modelname'])
    modeler.thisown = False  # Pass ownership to C++ library, core dumped if omitted...
    if args['--model'] == 'means':
        logging.debug('model: means')
        modeler.setModelOptions(EXTRAP.GENERATE_MODEL_MEAN)
    else:
        logging.debug('model: medians')
        modeler.setModelOptions(EXTRAP.GENERATE_MODEL_MEDIAN)
    experiment.addModelGenerator(modeler)
    experiment.modelAll(modeler)


def detect_prefix(dir_matches):
    """get prefix from pattern matching results (see parse_cube_files)"""
    return dir_matches[0].group(1)


def detect_parameter(dir_matches):
    """get parameter from pattern matching results (see parse_cube_files)"""
    return dir_matches[0].group(2)


def detect_values(dir_matches, prefix):
    """get values from pattern matching results (see parse_cube_files)"""
    matching_prefix = [d for d in dir_matches if d.group(1) == prefix]
    return sorted(set(int(m.group(3)) for m in matching_prefix))


def detect_repetitions(dir_matches, prefix):
    """get repetitions from pattern matching results (see parse_cube_files)"""
    matching_prefix = [d for d in dir_matches if d.group(1) == prefix]
    return max(int(m.group(4)) for m in matching_prefix)


def set_parameter(options, args, dir_matches):
    """
    Set parameter field from options.
    :param options: cube files opening options
    :param args: arguments parsed from command line
    :param dir_matches: regexp pattern matching results for each cube file inside dir name
    :return: None, (updates options)
    """
    if args['--parameter1']:
        options['parameter1'] = args['--parameter1']
    elif dir_matches:
        options['parameter1'] = detect_parameter(dir_matches)
    else:
        logging.info("falling back to default for parameter: %s", options['parameter'])
    if args['--parameter2']:
        options['parameter2'] = args['--parameter2']
    if args['--parameter3']:
        options['parameter3'] = args['--parameter3']
    if args['--parameter4']:
        options['parameter4'] = args['--parameter4']
    if args['--parameter5']:
        options['parameter5'] = args['--parameter5']


def set_prefix(options, args, dir_matches):
    """
    Set prefix field from options.
    :param options: cube files opening options
    :param args: arguments parsed from command line
    :param dir_matches: regexp pattern matching results for each cube file inside dir name
    :return: None, (updates options)
    """
    if args['--prefix']:
        options['prefix'] = args['--prefix']
    elif dir_matches:
        options['prefix'] = detect_prefix(dir_matches)
    else:
        logging.info("falling back to default for prefix: %s", options['prefix'])


def set_values(options, args, dir_matches):
    """
    Set values field from options.
    :param options: cube files opening options
    :param args: arguments parsed from command line
    :param dir_matches: regexp pattern matching results for each cube file inside dir name
    :return: None, (updates options)
    """
    if args['--values1']:
        options['values1'] = [int(v) for v in args['--values1'].split(',')]
    elif dir_matches:
        options['values'] = detect_values(dir_matches, options['prefix'])
    else:
        logging.info("falling back to default for values: %s", options['values'])
    if args['--values2']:
        options['values2'] = [int(v) for v in args['--values2'].split(',')]
    if args['--values3']:
        options['values3'] = [int(v) for v in args['--values3'].split(',')]
    if args['--values4']:
        options['values4'] = [int(v) for v in args['--values4'].split(',')]
    if args['--values5']:
        options['values5'] = [int(v) for v in args['--values5'].split(',')]


def set_repetitions(options, args, dir_matches):
    """
    Set repetitions field from options.
    :param options: cube files opening options
    :param args: arguments parsed from command line
    :param dir_matches: regexp pattern matching results for each cube file inside dir name
    :return: None, (updates options)
    """
    if args['--repetitions']:
        options['repetitions'] = int(args['--repetitions'])
    elif dir_matches:
        options['repetitions'] = detect_repetitions(dir_matches, options['prefix'])
    else:
        logging.info("falling back to default for repetitions: %s", options['repetitions'])


def set_scaling(options, args):
    """
    Set scaling field from options.
    :param options: cube files opening options
    :param args: arguments parsed from command line
    :return: None, (updates options)
    """
    if args['--scaling']:
        options['scaling'] = 1 if args['--scaling'] == 'weak' else 0  # strong = any value != 1
    else:
        logging.info("falling back to default for scaling: %s (1->weak, else strong)", options['scaling'])


def cube_file_options(dir_name, args):
    """
    Returns cube files opening options
    :param dir_name: input file path (directory name)
    :param args: arguments parsed from command line
    :return: cube files opening options
    """
    options = default_cube_options()
    dir_matches = parse_cube_files(dir_name)
    if not dir_matches:
        logging.error("files in %s do not match cube file name format", dir_name)
    if args['--filename']:
        options['filename'] = args['--filename']
    set_parameter(options, args, dir_matches)
    set_prefix(options, args, dir_matches)
    if args['--postfix']:
        options['postfix'] = args['--postfix']
    set_values(options, args, dir_matches)
    set_repetitions(options, args, dir_matches)
    set_scaling(options, args)
    return options


def load_experiment_from_text_input(text_input):
    """
    Load experiment from text input
    :param text_input: name of text input
    :return: experiment object if loading successful else system exit
    """
    logging.info("opening text input: " + text_input)
    experiment = EXTRAP.Experiment.openTextInput(text_input)
    if experiment is not None:
        return experiment
    else:
        logging.critical("failed to open: " + text_input)
        sys.exit(1)


def load_experiment_from_json_input(json_input):
    """
    Load experiment from json input
    :param json_input: name of json input file (.txt file)
    :return: experiment object if loading successful else system exit
    """
    logging.info("opening json input: " + json_input)
    experiment = EXTRAP.Experiment.openJsonInput(json_input)
    if experiment is not None:
        return experiment
    else:
        logging.critical("failed to open: " + json_input)
        sys.exit(1) 


def add_parameter( reader, name, values ):
    """
    Adds a parameter to the reader.
    """
    if name[0] == '_' or name[0] == '.':
        displayed_name = name[1:]
    else:
        displayed_name = name
    reader.addParameter( EXTRAP.Parameter( displayed_name ), 
                         name, 
                         py_int_list_to_int_vector(values) )


def load_experiment_from_cube_files(dir_name, args):
    """
    Load experiment from cube files
    :param dir_name: cube files path (directory name)
    :param args: arguments parsed from command line
    :return: experiment object
    """
    logging.info("opening cube files: " + dir_name)
    options = cube_file_options(dir_name, args)
    logging.debug(options)
    reader = EXTRAP.CubeFileReader()
    reader.prepareCubeFileReader(options['scaling'], dir_name, options['prefix'],
                                 options['postfix'],
                                 options['filename'],
                                 options['repetitions'])
    add_parameter( reader,
                   options['parameter1'],
                   options['values1'])
    num_params = 1
    if args['--parameter2'] and args['--values2']:
        add_parameter( reader,
                       options['parameter2'],
                       options['values2'])
        num_params = num_params + 1
    if args['--parameter3'] and args['--values3']:
        add_parameter( reader,
                       options['parameter3'],
                       options['values3'])
        num_params = num_params + 1
    if args['--parameter4'] and args['--values4']:
        add_parameter( reader,
                       options['parameter4'],
                       options['values4'])
        num_params = num_params + 1
    if args['--parameter5'] and args['--values5']:
        add_parameter( reader,
                       options['parameter5'],
                       options['values5'])
        num_params = num_params + 1
    
    files = reader.getFileNames(num_params)
    if not files:
        logging.error("no cube file matching options -> no file read!")
    else:
        for cube_file in files:
            if not os.path.exists(cube_file):
                logging.error("could not open: " + cube_file)
    experiment = reader.readCubeFiles(num_params)
    return experiment


def save_experiment(experiment, out_file):
    """
    Save experiment to out file
    :param experiment: to save
    :param out_file: name of save file
    :return: None
    """
    if experiment is not None:
        logging.info("saving experiment to: " + out_file)
        experiment.writeExtrapFile(out_file)
    else:
        logging.error("could not save experiment file (empty)")


def set_log_level(arguments):
    """
    Set log level according to arguments
    :param arguments: parsed from command line
    :return: None
    """
    if arguments['--debug']:
        logging.basicConfig(level=logging.DEBUG)  # lowest logging level -> displays everything
    else:
        logging.basicConfig(level=logging.INFO)


if __name__ == '__main__':
    args = docopt(__doc__, version='Experiment File Modeler 3.0')
    set_log_level(args)
    logging.debug(args)

    if args['input']:
        experiment = load_experiment_from_text_input(args['<inputfile>'])
        model_all(experiment, args)
        save_experiment(experiment, args['-o'])

    elif args['cube']:
        experiment = load_experiment_from_cube_files(args['<cubedir>'], args)
        model_all(experiment, args)
        save_experiment(experiment, args['-o'])

    elif args['json']:
        experiment = load_experiment_from_json_input(args['<jsonfile>'])
        model_all(experiment, args)
        save_experiment(experiment, args['-o'])