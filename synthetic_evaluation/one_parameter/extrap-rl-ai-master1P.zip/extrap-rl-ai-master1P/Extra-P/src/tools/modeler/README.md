# EXTRAP Modeler

Command Line Tool for Extra-P (<http://www.scalasca.org/software/extra-p/download.html>)

## Usage

```
""" Extrap modeler.

Usage:
  extrap-modeler input <inputfile> [-o=<out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>]  [--debug]
  extrap-modeler cube <cubedir> [-o=<out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>] [options] [--debug]
  extrap-modeler json  <jsonfile> [-o=<out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>]  [--debug]
  extrap-modeler experiment <experimentfile> [-o=<out>] [--simple --poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>]  [--debug]
  extrap-modeler -h | --help
  extrap-modeler --version

Options:
  -o=<out>                 Write output to <out> [default: ./out].
  --simple                 Use simple modeler (else use refining modeler)
  --poly=<poly>            Polynomial exponents for simple modeler e.g. '1.0,1.5,1.8'
  --log=<log>              Logarithm exponents for simple modeler e.g. '1.0,1.5,1.8'
  --model=<m>              Model (means | medians) [default: means]
  --modelname=<n>          Model name [default: default]
  --filename=<filename>    Cube files filename [default: profile.cubex]
  --parameter=<parameter>  Cube files parameter (disables parameter auto detection)
  --prefix=<prefix>        Cube files prefix (disables prefix auto detection).
  --postfix=<postfix>      Cube files postfix (disables postfix auto detection).
  --values=<values>        Cube files values e.g. '32,64,128' (disables values auto detection).
  --scaling=<scaling>      Cube files scaling (weak | strong) [default: weak]
  --repetitions=<reps>     Cube files repetitions (disables repetitions auto detection).
  -h --help                Show this screen.
  --version                Show version.
  --debug                  Enable debug logs.
"""
```

## Examples

> Open `input.txt`, run refining modeler and save experiment file to `out`.

`./extrap-modeler input input.txt`

```
INFO:root:opening text input: input.txt
INFO:root:saving experiment to: ./out
```

> Open `input.txt`, run simple modeler and save file to `output`.

`./extrap-modeler input input.txt -o output --simple --poly 0.1,0.2,0.5,1.0,1.2 --log 1 1`

```
INFO:root:opening text input: input.txt
INFO:root:saving experiment to: output
```

> Open set of cube files `sweep3D`, run refining modeler on medians with debug logs enabled.

`./extrap-modeler cube sweep3D --model medians --debug`

```
DEBUG:root:{'--debug': True,
 '--filename': 'profile.cubex',
 '--help': False,
 '--log': None,
 '--model': 'medians',
 '--parameter': None,
 '--poly': None,
 '--postfix': None,
 '--prefix': None,
 '--repetitions': None,
 '--scaling': 'weak',
 '--simple': False,
 '--values': None,
 '--version': False,
 '-o': './out',
 '<cubedir>': 'sweep3D',
 '<inputfile>': None,
 '<term>': None,
 'cube': True,
 'input': False}
INFO:root:opening cube files: sweep3D
DEBUG:root:{'prefix': 'scorep_scorep_weak.', 'postfix': '', 'parameter': 'p', 'scaling': 1, 'repetitions': 4, 'values': [32, 64, 128, 256, 512, 1024, 2048], 'filename': 'profile.cubex'}
DEBUG:root:using refining model generator
DEBUG:root:model: medians
INFO:root:saving experiment to: ./out
```

> Open set of cube files `sweep3D`, run simple modeler, override values with debug logs enabled.

`./extrap-modeler cube sweep3D --simple --poly 0.1,0.2,1.0,1.2 --log 1 1 --values 32,64 --debug`

```
DEBUG:root:{'--debug': True,
 '--filename': 'profile.cubex',
 '--help': False,
 '--log': '1',
 '--model': 'means',
 '--parameter': None,
 '--poly': '0.1,0.2,1.0,1.2',
 '--postfix': None,
 '--prefix': None,
 '--repetitions': None,
 '--scaling': 'weak',
 '--simple': True,
 '--values': '32,64',
 '--version': False,
 '-o': './out',
 '<cubedir>': 'sweep3D',
 '<inputfile>': None,
 '<term>': '1',
 'cube': True,
 'input': False}
INFO:root:opening cube files: sweep3D
DEBUG:root:{'filename': 'profile.cubex', 'scaling': 1, 'values': [32, 64], 'postfix': '', 'repetitions': 4, 'parameter': 'p', 'prefix': 'scorep_scorep_weak.'}
DEBUG:root:using simple model generator
DEBUG:root:polynomial exponents: [0.1, 0.2, 1.0, 1.2]
DEBUG:root:logarithm exponents: [1.0]
DEBUG:root:model: means
INFO:root:saving experiment to: ./out
```

> Open `input.txt` json format input file, run refining modeler and save experiment file to `out`.

`./extrap-modeler json json_input.txt`

```
INFO:root:opening json input: input.txt
INFO:root:saving experiment to: ./out
```

> Open `out` (binary) serialized ExtraP experiment object as file, run refining modeler and save experiment file to `out`.

`./extrap-modeler experiment out`

```
INFO:root:opening text input: input.txt
INFO:root:saving experiment to: ./out
```

## Dependencies

* docopt (command line parsing <https://github.com/docopt/docopt>)
* Extra-P (<http://www.scalasca.org/software/extra-p/download.html>)
