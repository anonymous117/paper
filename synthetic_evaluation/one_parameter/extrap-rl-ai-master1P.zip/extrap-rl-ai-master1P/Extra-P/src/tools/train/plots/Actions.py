import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from extrap.Util import smooth

class Actions():

    def __init__(self, number_actions):
        self.number_actions = number_actions
        self.smooth_number_actions = smooth(self.number_actions, 0.9) 

    def plot(self):
        ax = plt.subplot(111)
        ax.plot(self.number_actions, 'b-')
        ax.plot(self.smooth_number_actions, 'r-')
        # Hide the right and top spines
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        # Only show ticks on the left and bottom spines
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')
        ax.set_xlim(0,len(self.number_actions))
        ax.xaxis.labelpad = 10
        ax.yaxis.labelpad = 10
        plt.xlabel("Epochs")
        plt.ylabel("Actions")
        plt.show()

    def calc_average_number_actions(self):
        sum = 0
        for i in range(len(self.number_actions)):
            sum += self.number_actions[i]
        average_number_actions = sum / len(self.number_actions) 
        print("Average number of actions: "+str(average_number_actions))
    
    def save(self):
        actions_file = open("plotdata/actionsdata.t", "w")
        for i in range(len(self.number_actions)):
            actions_file.write(str(i+1)+" "+str(self.number_actions[i])+"\n")
        actions_file.close()
        smooth_actions_file = open("plotdata/smoothactionsdata.t", "w")
        for i in range(len(self.smooth_number_actions)):
            smooth_actions_file.write(str(i+1)+" "+str(self.smooth_number_actions[i])+"\n")
        smooth_actions_file.close()