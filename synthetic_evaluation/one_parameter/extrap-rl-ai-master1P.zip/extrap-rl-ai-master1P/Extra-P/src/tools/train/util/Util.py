import json

'''
Read data from Json File
'''
def read_json_file(path):
    with open(path) as json_file:  
        data = json.load(json_file)
        return data

'''
Read training configuration
'''
def read_ml_training_config():
    path = "config/ml_training_config.json"
    data = read_json_file(path)
    return data

'''
Read evaluation configuration
'''
def read_ml_evaluation_config():
    path = "config/ml_evaluation_config.json"
    data = read_json_file(path)
    return data

'''
Read environment configuration
'''
def read_environment_config():
    path = "config/environment_config.json"
    data = read_json_file(path)
    return data

'''
Function to smooth data
'''
def smooth(scalars, weight):  # Weight between 0 and 1
    last = scalars[0]  # First value in the plot (first timestep)
    smoothed = list()
    for point in scalars:
        smoothed_val = last * weight + (1 - weight) * point  # Calculate smoothed value
        smoothed.append(smoothed_val)                        # Save it
        last = smoothed_val                                  # Anchor the last smoothed value
    return smoothed