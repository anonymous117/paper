import EXTRAP

from extrap.TrainingDataGenerator import TrainingDataGenerator
from extrap.Environment import Environment
from extrap.Agent import Agent

from extrap.Reward import Reward
from extrap.Loss import Loss
from extrap.Cost import Cost
from extrap.Actions import Actions

from extrap.Util import read_ml_training_config
from extrap.Util import read_environment_config

if __name__ == "__main__":

    '''
    Read machine learning config file
    '''
    ml_config = read_ml_training_config()
    training_episodes = ml_config["episodes"]
    alpha = ml_config["learning_rate"]
    reward_decay = ml_config["reward_decay"]
    learning_update_frequency = ml_config["learning_update_frequency"]
    replace_target_iter = ml_config["replace_target_network"]
    memory_size = ml_config["memory_size"]
    batch_size = ml_config["batch_size"]
    replay_start_size = ml_config["replay_start_size"]
    final_exploration = ml_config["final_exploration"]
    epsilon_max = ml_config["epsilon_max"]
    epsilon_min = ml_config["epsilon_min"]
    epsilon_upgrade_frequency = ml_config["epsilon_upgrade_frequency"]

    '''
    Read environment config file
    '''
    ev_config = read_environment_config()
    number_parameters = len(ev_config["parameters"])
    parameters = ev_config["parameters"]
    repetitions = ev_config["repetitions"]
    parameter_values = []
    for i in range(number_parameters):
        p_name = "p"+str(i+1)
        parameter_values.append(ev_config[p_name])
    if ev_config["use_seed"] == 0:
        use_seed = False
    else:
        use_seed = True
    training_seed = ev_config["training_seed"]
    noise = ev_config["noise"]
    term_contribution = ev_config["term_contribution"]

    '''
    Initialize global variables
    '''
    learning_update_counter = 0
    number_learning_updates = 0
    rewards = []
    number_actions = []
    cost = []
    # the number of actions equals the measurement points that are available
    n_actions = 1
    for i in range(number_parameters):
        n_actions *= len(parameter_values[i])
    # * 8 for the search space history
    n_features = n_actions * 8

    '''
    Create Training Data
    '''
    training_data_generator = TrainingDataGenerator(use_seed, training_seed, noise, term_contribution, repetitions, parameters, parameter_values)
    training_data = training_data_generator.create_training_data_set(training_episodes)

    '''
    Create the Agent
    '''
    agent = Agent(n_actions, n_features, epsilon_max, epsilon_min, alpha, reward_decay, replace_target_iter, memory_size, batch_size, replay_start_size, final_exploration, epsilon_upgrade_frequency)

    '''
    Train the agent for n episodes
    '''
    for i in range(training_episodes):

        if i % 1000 == 0:
            print("Episode "+str(i))

        # reduce the learning rate based on the number of episodes
        if i == 30000:
            agent.set_alpha(0.01)

        if i == 35000:
            agent.set_alpha(0.001)

        # create environment for episode
        env = Environment(training_data[i], n_actions, False, parameter_values)

        # get the initial state
        state = env.get_state()

        # init local variables
        total_steps = 0
        total_cost = 0

        # execute episode until termination
        while True:
            # choose the next action based on the current observation
            action = agent.choose_action(state, env)

            # perform the selected action
            state_, reward, done = env.step(action)

            # store transition data in memory
            agent.store_transition(state, action, reward, state_)

            # update state
            state = state_

            # when episode is finished
            if done == True:
                rewards.append(reward)
                total_steps = env.get_step_number()
                total_cost = env.get_cost()
                break

        # learn
        if i >= replay_start_size:
            if learning_update_counter >= learning_update_frequency:
                learning_update_counter = 0
                agent.learn(i)
                number_learning_updates += 1
                number_actions.append(total_steps)
                cost.append(total_cost)
        learning_update_counter += 1

        # update epsilon value for e-greedy strategy
        agent.adjust_epsilon(i)

    '''
    Save NN
    '''
    agent.save_NN()

    '''
    Analyze Loss
    '''
    loss = agent.get_loss()
    training_loss = Loss(loss)
    training_loss.plot()
    training_loss.save()

    '''
    Analyze Reward
    '''
    training_reward = Reward(rewards, number_learning_updates, replay_start_size, learning_update_frequency, training_episodes)
    training_reward.plot()
    training_reward.save()

    '''
    Analyze Cost
    '''
    training_cost = Cost(cost)
    training_cost.plot()
    training_cost.save()

    '''
    Analyze Actions
    '''
    training_actions = Actions(number_actions)
    training_actions.plot()
    training_actions.save()
