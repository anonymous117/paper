from random import uniform

class Coefficients():
   
    def __init__(self):
        self.min = 0.001
        self.max = 1000
    
    def get_random_coefficient(self):
        return uniform(self.min, self.max)