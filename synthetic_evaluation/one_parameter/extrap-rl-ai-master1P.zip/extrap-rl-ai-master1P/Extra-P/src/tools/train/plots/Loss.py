import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from extrap.Util import smooth

class Loss():

    def __init__(self, loss):
        self.loss = loss
        self.smooth_loss = smooth(self.loss, 0.9) 

    def plot(self):
        ax = plt.subplot(111)
        ax.plot(self.loss, 'b-')
        ax.plot(self.smooth_loss, 'r-')
        # Hide the right and top spines
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        # Only show ticks on the left and bottom spines
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')
        ax.set_xlim(0,len(self.loss))
        ax.xaxis.labelpad = 10
        ax.yaxis.labelpad = 10
        plt.xlabel("Training epochs")
        plt.ylabel("Loss")
        plt.show()
    
    def save(self):
        loss_file = open("plotdata/lossdata.t", "w")
        for i in range(len(self.loss)):
            loss_file.write(str(i+1)+" "+str(self.loss[i])+"\n")
        loss_file.close()
        smooth_loss_file = open("plotdata/smoothlossdata.t", "w")
        for i in range(len(self.smooth_loss)):
            smooth_loss_file.write(str(i+1)+" "+str(self.smooth_loss[i])+"\n")
        smooth_loss_file.close()