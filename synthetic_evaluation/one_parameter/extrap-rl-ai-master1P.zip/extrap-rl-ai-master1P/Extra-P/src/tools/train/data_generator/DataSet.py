class DataSet():
    
    def __init__(self, function, parameters, coordinates, data_points):
        self.function = function
        self.parameters = parameters
        self.coordinates = coordinates
        self.data_points = data_points
        
    def get_function(self):
        return self.function
    
    def get_parameters(self):
        return self.parameters
    
    def get_coordinates(self):
        return self.coordinates
    
    def get_data_points(self):
        return self.data_points