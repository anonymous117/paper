import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from extrap.Util import smooth

class Reward2():

    def __init__(self, rewards, evaluation_max_rewards):
        self.rewards = rewards
        self.smooth_rewards = smooth(self.rewards, 0.9)
        self.evaluation_max_rewards = evaluation_max_rewards

    def plot(self):
        ax = plt.subplot(111)
        ax.plot(self.rewards, 'b-')
        ax.plot(self.smooth_rewards, 'r-')
        ax.plot(self.evaluation_max_rewards, 'g^-')
        # Hide the right and top spines
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        # Only show ticks on the left and bottom spines
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')
        ax.set_xlim(0,len(self.rewards))
        ax.xaxis.labelpad = 10
        ax.yaxis.labelpad = 10
        plt.xlabel("Evaluation epochs")
        plt.ylabel("Average reward per episode")
        plt.show()