import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from extrap.Util import smooth

class Reward():

    def __init__(self, rewards, learn_counter, replay_start_size, tnuf, training_episodes):
        self.rewards = rewards
        self.learn_counter = learn_counter
        self.replay_start_size = replay_start_size
        self.tnuf = tnuf
        self.training_episodes = training_episodes
        self.average_rewards = []
        self.compute_average_rewards()
        self.smooth_average_rewards = smooth(self.average_rewards, 0.9)

    def compute_average_rewards(self):
        # 1 element
        sum = 0
        for i in range(self.replay_start_size):
            sum += self.rewards[i]
        average = sum / self.replay_start_size
        self.average_rewards.append(average)
        self.learn_counter -= 1
        # other elements
        index = self.replay_start_size
        for _ in range(self.learn_counter):
            sum = 0
            for j in range(self.tnuf):
                sum += self.rewards[index + j]
            average = sum / self.tnuf
            index += self.tnuf
            self.average_rewards.append(average)

    def plot(self):
        ax = plt.subplot(111)
        ax.plot(self.average_rewards, 'b-')
        ax.plot(self.smooth_average_rewards, 'r-')
        # Hide the right and top spines
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        # Only show ticks on the left and bottom spines
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')
        ax.set_xlim(0,len(self.average_rewards))
        ax.xaxis.labelpad = 10
        ax.yaxis.labelpad = 10
        plt.xlabel("Training epochs")
        plt.ylabel("Average reward per episode")
        plt.show()

    def save(self):
        reward_file = open("plotdata/rewarddata.t", "w")
        for i in range(len(self.average_rewards)):
            reward_file.write(str(i+1)+" "+str(self.average_rewards[i])+"\n")
        reward_file.close()
        smooth_reward_file = open("plotdata/smoothrewarddata.t", "w")
        for i in range(len(self.smooth_average_rewards)):
            smooth_reward_file.write(str(i+1)+" "+str(self.smooth_average_rewards[i])+"\n")
        smooth_reward_file.close()