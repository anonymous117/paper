##/*
## * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
## *
## * Copyright (c) 2016-2018,
## * Technische Universitaet Darmstadt, Germany
## *
## * This software may be modified and distributed under the terms of
## * a BSD-style license.  See the COPYING file in the package base
## * directory for details.
## *
## */
"""Experiment File Printer.

Usage:
  extrap-print <file> [--sparse] [-o <out>] [--debug]
  extrap-print <file> (callpaths | regions | metrics | parameters | function ) [--sparse] [-o <out>] [--debug]
  extrap-print -h | --help
  extrap-print --version

Options:
  --sparse                  Load binary file from the sparse modeler.
  -o <out>                  Write output to <out>.
  -h --help                 Show this screen.
  --version                 Show version.
  --debug                   Enable debug logs.
"""
import logging
import sys
import textwrap
import json
import re

import EXTRAP
from extrap.docopt import docopt


def as_py_list(vector):
    """python list from wrapped c++ vector"""
    return [vector[i] for i in range(0, vector.size())]


def load_experiment(experiment_file_name):
    """
    Load experiment object from experiment file name
    :param experiment_file_name: experiment file to load
    :return: experiment if file loading successful else system exit
    """
    logging.info("opening: " + experiment_file_name)
    experiment = EXTRAP.Experiment.openExtrapFile(experiment_file_name)
    if experiment is not None:
        return experiment
    else:
        logging.critical("failed to open: " + experiment_file_name)
        sys.exit(1)


def load_sparse_modeler_result(experiment_file_name):
    """
    Load result object sparse modeler from file name
    :param experiment_file_name: result object file to load
    :return: function string if file loading successful else system exit
    """
    logging.info("opening: " + experiment_file_name)
    sparse_modeler = EXTRAP.MultiParameterSparseModeler()
    function = sparse_modeler.openResultFile(experiment_file_name)
    sparse_modeler.thisown = False
    if function != "":
        return function
    else:
        logging.error("failed to open: " + experiment_file_name)
        sys.exit(1)


def save_output(text, out_file_name):
    """
    Save text output to out file name
    :param text: to save
    :param out_file_name: file to save to
    :return: None
    """
    with open(out_file_name, "w+") as out:
        out.write(text)
        logging.info("output written to: " + out_file_name)


def save_output_json(json_object, out_file_name):
    """
    Save json object to out file name
    :param json_object: to save
    :param out_file_name: file to save to
    :return: None
    """
    out_file_name = out_file_name + ".json"
    with open(out_file_name, 'w') as outfile:
        json.dump(json_object, outfile)
        logging.info("output written to: " + out_file_name)


class Description(object):
    @staticmethod
    def desc_point(point, parameter):
        """
        String description of point
        :param point: for description
        :param parameter: for point values
        :return: string description of point
        """
        text_point = ""
        text_point += " {:.2E}".format(point.getParameterValue(parameter))
        text_point += " Mean: {:.2E}".format(point.getMean())
        text_point += " Median: {:.2E}".format(point.getMedian())
        return text_point

    @staticmethod
    def desc_model(model, experiment):
        """
        String description of a model
        :param model: for description
        :param experiment: from which the model comes from
        :return: string description of the model
        """
        text_model = ""
        model_formula = model.getModelFunction().getAsString(experiment.getParameters())
        text_model += " model: {}\n".format(model_formula)
        text_model += " RSS: {:.2E}\n".format(model.getRSS())
        text_model += " Adjusted R^2: {:.2E}\n".format(model.getAR2())
        return text_model

    @staticmethod
    def desc_call_paths(experiment):
        """
        String description of all call paths from experiment
        :param experiment: containing call paths
        :return: string description of all call paths from experiment
        """
        return "\n".join(call_path.getFullName() for call_path in
                         as_py_list(experiment.getAllCallpaths()))

    @staticmethod
    def desc_metrics(experiment):
        """
        String description of all metrics from experiment
        :param experiment: containing metrics
        :return: string description of all metrics from experiment
        """
        return "\n".join(metric.getName() for metric
                         in as_py_list(experiment.getMetrics()))

    @staticmethod
    def desc_regions(experiment):
        """
        String description of all regions from experiment
        :param experiment: containing regions
        :return: string description of all regions from experiment
        """
        return "\n".join(region.getName() for region
                         in as_py_list(experiment.getRegions()))

    @staticmethod
    def desc_parameters(experiment):
        """
        String description of all parameters from experiment
        :param experiment: containing parameters
        :return: string description of all parameters from experiment
        """
        return "\n".join(parameter.getName() for parameter
                         in as_py_list(experiment.getParameters()))


    @staticmethod
    def desc_function(experiment, sparse_flag):
        """
        Python math function notation for the ExtraP function
        :param experiment: ExtraP experiment
        :return: Python math function of the ExtraP function as string
        """
        if sparse_flag == False:
            #load binary from normal modeler
            call_paths = experiment.getAllCallpaths()
            metrics = experiment.getMetrics()
            metric = metrics[0]
            call_path = call_paths[0]
            models = experiment.getModels(metric, call_path)
            model = models[0]
            model_function = model.getModelFunction()
            function_string = model_function.getAsString(experiment.getParameters())
            function = function_string
        else:
            #load binary from sparse modeler
            function = experiment

        # remove leading + for the first coefficient
        if function[0] == ' ':
            function = function[1:]
        if function[0] == '+':
            function = function[1:]
        if function[0] == ' ':
            function = function[1:]

        # replace power operator ^ with **
        while True:
            id = 0
            complete = True
            for i in range(0,len(function)):
                if function[i] == '^':
                    id = i
                    complete = False
                    break

            if complete == True:
                break
            
            temp = function[:id]
            temp2 = function[id+2:]
            exponent = function[id+1]
            temp2 = '**' + exponent + temp2
            function = temp + temp2

        # replace log operator log2(x) with log(x,2)
        while True:
            id = function.find('log2')
            if id == -1:
                break
            else:
                temp = function[:id]
                temp2 = function[id+4:]
                bracket1 = temp2.find('(')
                bracket2 = temp2.find(')')
                parameter = temp2
                parameter = parameter[bracket1+1:]
                parameter = re.sub('\)$', '', parameter)
                temp3 = temp2[:bracket1]
                temp4 = temp2[bracket2+1:]
                temp2 = temp3 + temp4
                function = temp + 'log(' + parameter + ',2)' + temp2
            break

        return function


    @staticmethod
    def desc_json(experiment):
        """
        JSON object notation for experiment
        :param experiment: ExtraP experiment
        :return: json object notation for experiment as string
        """
        data = {}
        parameters = []
        parameter_list = experiment.getParameters()
        for parameter_value in parameter_list:
            parameters.append(parameter_value.getName())
        call_paths = experiment.getAllCallpaths()
        metrics = experiment.getMetrics()
        metric = metrics[0]
        call_path = call_paths[0]
        models = experiment.getModels(metric, call_path)
        # there are several model???
        # for now just use the first one
        # but investigate this topic!!!
        model = models[0]
        model_function = model.getModelFunction()
        function_string = model_function.getAsString(experiment.getParameters())
        function = function_string

        # remove leading + for the first coefficient
        if function[0] == ' ':
            function = function[1:]
        if function[0] == '+':
            function = function[1:]
        if function[0] == ' ':
            function = function[1:]

        # replace power operator ^ with **
        while True:
            id = 0
            complete = True
            for i in range(0,len(function)):
                if function[i] == '^':
                    id = i
                    complete = False
                    break

            if complete == True:
                break
            
            temp = function[:id]
            temp2 = function[id+2:]
            exponent = function[id+1]
            temp2 = '**' + exponent + temp2
            function = temp + temp2

        # replace log operator log2(x) with log(x,2)
        while True:
            id = function.find('log2')
            if id == -1:
                break
            else:
                temp = function[:id]
                temp2 = function[id+4:]
                bracket1 = temp2.find('(')
                bracket2 = temp2.find(')')
                parameter = temp2
                parameter = parameter[bracket1+1:]
                parameter = re.sub('\)$', '', parameter)
                temp3 = temp2[:bracket1]
                temp4 = temp2[bracket2+1:]
                temp2 = temp3 + temp4
                function = temp + 'log(' + parameter + ',2)' + temp2
            break
        
        #rss = model.getRSS()
        #ar2 = model.getAR2()
        
        # add data to json object
        data["parameters"] = parameters
        #data['rss'] = rss
        #data['adjusted_r^2'] = ar2

        model = {}
        model["python"] = function
        data["model"] = model

        # function
        #num_param = parameter_list.size()
        #if num_param == 1:
        #    print("single\n")
        #    compund_terms_size = model_function.getCompoundTerms().size()
        #    print(compund_terms_size)
        #else:
        #    print("multi\n")
        #    multi_param_term_size = model_function.getMultiParameterTerms().size()
        #    print(multi_param_term_size)
        return data


    @staticmethod
    def desc_all(experiment):
        """
        String description for experiment
        :param experiment: ExtraP experiment
        :return: string description for experiment
        """
        text = ""
        for call_path in as_py_list(experiment.getAllCallpaths()):
            call_path_name = call_path.getFullName()
            text += "callpath: {}\n".format(call_path_name)
            for metric in as_py_list(experiment.getMetrics()):
                metric_name = metric.getName()
                text += textwrap.indent("metric: {}\n".format(metric_name), "\t")
                for point in as_py_list(experiment.getPoints(metric, call_path)):
                    text_point = Description.desc_point(point, experiment.getParameters()[0])  # only one parameter
                    text += textwrap.indent(text_point + "\n", "\t\t")
                models = as_py_list(experiment.getModels(metric, call_path))
                if models:
                    text_model = Description.desc_model(models[0], experiment)  # only first model is displayed
                    text += textwrap.indent(text_model, "\t\t")
                else:
                    logging.error('no model found for call path' + call_path_name)
        return text


def desc(experiment, args, sparse_flag):
    if args['callpaths']:
        logging.debug('printing call paths')
        text = Description.desc_call_paths(experiment)
    elif args['metrics']:
        logging.debug('printing metrics')
        text = Description.desc_metrics(experiment)
    elif args['regions']:
        logging.debug('printing regions')
        text = Description.desc_regions(experiment)
    elif args['parameters']:
        logging.debug('printing parameters')
        text = Description.desc_parameters(experiment)
    #elif args['json']:
    #    logging.debug('printing json object')
    #    text = Description.desc_json(experiment)
    elif args['function']:
        logging.debug('printing function')
        text = Description.desc_function(experiment, sparse_flag)
    else:
        logging.debug('printing all')
        text = Description.desc_all(experiment)
    return text


def set_log_level(arguments):
    """
    Set global log level from arguments.
    :param arguments: parsed from command line
    :return: None
    """
    if arguments['--debug']:
        logging.basicConfig(level=logging.DEBUG)  # lowest logging level -> displays everything
    else:
        logging.basicConfig(level=logging.INFO)


def main():
    args = docopt(__doc__, version='Experiment File Printer 3.0')
    set_log_level(args)
    logging.debug(args)

    #for the sparse modeler output
    if args['--sparse']:
        if args['function']:
            function = load_sparse_modeler_result(args['<file>'])
            text = desc(function, args, True)
            print(text)
            if args['-o']:
                save_output(text, args['-o'])
        #TODO:be able to output other values (metrics etc.)
        #default else should output all in the end!
        """
        else:
            function = load_sparse_modeler_result(args['<file>'])
            text = desc(function, args, True)
            print(text)
            if args['-o']:
                save_output(text, args['-o'])
        """
    #for the normal modeler output
    else:
        experiment = load_experiment(args['<file>'])
        if args['function']:
            text = desc(experiment, args, False)
            stripped = text
        else:
            text = desc(experiment, args, False)
            stripped = '\n'.join(line for line in text.split('\n') if line.strip() != '')  # remove blank lines
        print(stripped)
        if args['-o']:
            save_output(stripped, args['-o'])


if __name__ == '__main__':
    main()
