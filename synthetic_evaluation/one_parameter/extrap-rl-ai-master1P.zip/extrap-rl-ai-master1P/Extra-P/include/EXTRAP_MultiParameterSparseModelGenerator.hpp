/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MULTI_PARAMETER_SPARSE_MODEL_GENERATOR_HPP
#define EXTRAP_MULTI_PARAMETER_SPARSE_MODEL_GENERATOR_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_MultiParameterHypothesis.hpp>
#include <EXTRAP_MultiParameterModelGenerator.hpp>
#include <EXTRAP_MultiParameterSparseFunctionModeler.hpp>

namespace EXTRAP
{
class SingleParameterFunction;
class MultiParameterFunction;

class MultiParameterSparseModelGenerator : public MultiParameterModelGenerator
{
public:

    static const std::string MULTIPARAMETERSPARSEMODELGENERATOR_PREFIX;
    MultiParameterSparseModelGenerator();


    virtual bool
    serialize( IoHelper* ioHelper ) const;

    static MultiParameterSparseModelGenerator*
    deserialize( IoHelper* ioHelper );

protected:
    virtual MultiParameterFunctionModeler&
    getFunctionModeler() const;

    MultiParameterSparseFunctionModeler* m_modeler;
};

bool
equal( const MultiParameterSparseModelGenerator* lhs,
       const MultiParameterSparseModelGenerator* rhs );
};

#endif
