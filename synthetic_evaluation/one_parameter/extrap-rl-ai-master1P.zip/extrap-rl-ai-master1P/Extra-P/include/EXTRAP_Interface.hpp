/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_INTERFACE_HPP
#define EXTRAP_INTERFACE_HPP

/**
 * @file
 * This file defines the theobejcts that form the main interface of Extra-P
 * It is the interface between C++ and Python.
 * Objects in this class are wrapped for Python, thus, it contains only
 * definitions that need to be part of the Python interface.
 */
#include <EXTRAP_Experiment.hpp>
#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

#endif
