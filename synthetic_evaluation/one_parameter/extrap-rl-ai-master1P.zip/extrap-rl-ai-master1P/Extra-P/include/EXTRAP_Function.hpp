/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_FUNCTION_HPP
#define EXTRAP_FUNCTION_HPP

#include <EXTRAP_Parameter.hpp>
#include <stdint.h>

namespace EXTRAP
{
class Function
{
public:
    static const std::string FUNCTION_PREFIX;
    virtual
    ~Function();

    virtual Value
    evaluate( const ParameterValueList& parameterValues ) const;

    virtual std::string
    getAsString( const ParameterList& parameterNames ) const;

    virtual Function*
    clone( void ) const;

    virtual bool
    serialize(
        IoHelper* ioHelper ) const;
    static Function*
    deserialize(
        IoHelper*   ioHelper,
        std::string prefix );

    virtual FunctionClass
    getFunctionClass() const;
};
bool
equal( const Function* lhs,
       const Function* rhs );

typedef struct
{
    Function* upper;
    Function* lower;
} FunctionPair;
};

#endif
