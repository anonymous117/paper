/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_TIMING_HPP
#define EXTRAP_TIMING_HPP

#include <string>
#include <vector>
#include <map>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <iostream>
#include <stdarg.h>
#include <cstring>
#include "EXTRAP_RealtimeDataPoint.hpp"

#ifdef USE_PAPI
#include <papi.h>
#endif

/*inline double
   EXTRAP_getTime( void )
   {
    struct timeval tv;
    gettimeofday( &tv, NULL );
    return ( double )tv.tv_sec + ( double )tv.tv_usec / 1000000.0;
   }*/


struct EXTRAPTimingData
{
    EXTRAPTimingData() :
        started( false ),
        start_time( 0.0 ),
        total_time( 0.0 ),
        prev_time( 0.0 ),
        count( 0 )
    {
    }

    bool                   started;
    double                 start_time;
    double                 total_time;
    double                 prev_time;
    size_t                 count;
#ifdef USE_PAPI
    std::vector<long long> papi_start_values;
    std::vector<size_t>    papi_total;
#endif
};

class EXTRAPTiming
{
public:
    ~EXTRAPTiming();

    void
    start( std::string const& name );

    void
    stop( std::string const& name );

    void
    stopAll( void );

    void
    clear( void );

    double
    getTime( std::string const& name ) const;

    void
    setPapiEvents( std::vector<std::string> names );

private:
    typedef std::map<std::string, EXTRAPTimingData> TimerMap;
    TimerMap timers;
#ifdef USE_PAPI
    std::vector<std::string> papi_names;
    std::vector<int>         papi_event;
    int                      papi_set;
#endif
};

class EXTRAPRealtimeModel
{
public:
    void
    tryModel( std::string const name, std::vector<double>* params, double time )
    {
        counter = 0;
        std::cout << name << ": ";
        for ( std::vector<double>::iterator i = params->begin(); i != params->end(); ++i )
        {
            if ( dataPoints.size() <= counter )
            {
                dataPoints.push_back( new std::map<double, EXTRAP::RealtimeDataPoint* >() );
            }
            if ( dataPoints[ counter ]->find( *i ) == dataPoints[ counter ]->end() )
            {
                dataPoints[ counter ]->insert( dataPoints[ counter ]->begin(),
                                               std::pair<double, EXTRAP::RealtimeDataPoint*>( *i, new EXTRAP::RealtimeDataPoint( time, new EXTRAP::Region( name, "", 1 ), new EXTRAP::Metric( "time", "s" ) ) ) );
            }
            else
            {
                dataPoints[ counter ]->at( *i )->update( time );
            }

            counter++;
            std::cout << *i << " ";
        }
        std::cout << "; Time: " << time << std::endl;

        /*if (this->data == nullptr)
           {
            this->data = new EXTRAP::RealtimeDataPoint(dataPoint, region, metric, tvalueFilePath);
           }
           else
           {
            this->data->update(dataPoint);
           }

           //std::cout << "Time for " << this->region->getName() << ": " << dataPoint << "; Median: " << this->data->getMedian() << "; Mean: " << this->data->getMean() << std::endl;

           double start = this->data->getMean() - this->data->getStandardDeviation();
           double end = this->data->getMean() + this->data->getStandardDeviation();

           double deviation = max(0.0, abs(dataPoint - this->data->getMean()) / this->data->getStandardDeviation()) - 1.0;

           if (deviation > 0.5)
           {
            this->num_warnings++;
            //std::cout << "Warning: Measured " << dataPoint << " seconds! Expected measurements in range [" << start << ", " << end << "] Deviation: " << (deviation * 100) << "%" << std::endl;
           }*/
    }
private:

    unsigned int                                                counter;
    std::vector<std::map<double, EXTRAP::RealtimeDataPoint*>* > dataPoints;
};

#include <stdio.h>

// Aides timing a block of code, with automatic timer stopping
class ExtrapTimer
{
public:
    static void
    InitializeTimers( std::vector<std::string>* names )
    {
        for ( std::vector<std::string>::iterator name = names->begin(); name != names->end(); ++name )
        {
            printf( "Initializing timer called %s.", ( *name ).c_str() );
            EXTRAP_MODELS[ ( *name ).c_str() ] = new EXTRAPRealtimeModel();
        }
    }

    inline ExtrapTimer( std::string const& timer_name, int num_args, ... ) : name( timer_name )
    {
        params = new std::vector<double>();
        va_list ap;
        va_start( ap, num_args );
        for (; num_args > 0; num_args-- )
        {
            params->push_back( va_arg( ap, double ) );
        }

        EXTRAP_TIMER->start( name );
    }

    inline ~ExtrapTimer()
    {
        EXTRAP_TIMER->stop( name );
        if ( EXTRAP_MODELS.find( name.c_str() ) == EXTRAP_MODELS.end() )
        {
            std::string err = "//////////////////////////////////////////////////////////////////////////\n";
            err += "No timer called \"" + name + "\" was initialized.\n";
            if ( EXTRAP_MODELS.size() == 0 )
            {
                err += "Try adding:\n";
                err += "\tstd::vector<std::string> *names = new std::vector<std::string>();\n";
                err += "\tnames->push_back(\"" + name + "\");\n";
                err += "\tExtrapTimer::InitializeTimers(names);\n";
                err += "as first statements in your main().\n\n";
                err += "...and don't forget to #include <EXTRAP_Timing.hpp>.\n";
            }
            else
            {
                err += "Forgot to add " + name + " to the initializer list?\n";
                err += "Known timers:\n";
                for ( std::map<std::string, EXTRAPRealtimeModel*>::iterator timer = EXTRAP_MODELS.begin();
                      timer != EXTRAP_MODELS.end(); ++timer )
                {
                    err += timer->first + "\n";
                }
            }
            err                          += "Initializing now.\n";
            EXTRAP_MODELS[ name.c_str() ] = new EXTRAPRealtimeModel();
            char numstr[ 21 ]; // enough to hold all numbers up to 64-bits
            sprintf( numstr, "%lu", ( sizeof( EXTRAPRealtimeModel ) + sizeof EXTRAP_MODELS[ name ] ) );
            err += "This violates the constant memory overhead assumption and increases the memory consumption by ";
            err += numstr;
            err += " bytes.\n";
            err += "//////////////////////////////////////////////////////////////////////////";
            std::cerr << err << std::endl;
        }
        EXTRAP_MODELS[ name.c_str() ]->tryModel( name, params, EXTRAP_TIMER->getTime( name ) );
    }

private:
    std::string                                        name;
    std::vector<double>*                               params;
    static EXTRAPTiming*                               EXTRAP_TIMER;
    static std::map<std::string, EXTRAPRealtimeModel*> EXTRAP_MODELS;
};

#define EXTRAP_INSTRUMENTER( FUNCTION_NAME, ... ) ExtrapTimer XTRP_TIMER_##NAME(#FUNCTION_NAME, sizeof( ( double[] ) {__VA_ARGS__ } ) / sizeof( double ), __VA_ARGS__ );

#endif
