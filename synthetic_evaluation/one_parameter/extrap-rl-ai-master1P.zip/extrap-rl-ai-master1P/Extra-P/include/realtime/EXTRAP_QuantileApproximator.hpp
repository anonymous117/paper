/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_QUANTILE_APPROXIMATOR_HPP
#define EXTRAP_QUANTILE_APPROXIMATOR_HPP

#include <EXTRAP_Parameter.hpp>
#include <EXTRAP_Region.hpp>
#include <EXTRAP_Metric.hpp>

/**
 * Trick the SWIG wrapper generator.
 * If the return value is a const class reference, we can not access
 * methods of the class in python. Thus, we make SWIG think the return
 * values not const via defining an empty CONST. In all other cases
 * we want to have the returned reference of to be const to ensure
 * side-effect free programming.
 */
#ifndef CONST
#define CONST const
#endif

namespace EXTRAP
{
/**
 * This class represents one data point for one metric/callpath pair.
 */
class QuantileApproximator
{
public:
    QuantileApproximator( double quantilePercentage );

    void
    Update( EXTRAP::Value datapoint );

    EXTRAP::Value
    GetQuantileValue();

private:
    double p;

    std::vector<EXTRAP::Value> q;
    std::vector<double>        dn;
    std::vector<int>           n;

    static double
    GetIncrement( int    i,
                  double p );
};
};

#endif
