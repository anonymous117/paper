/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_EXHAUSTIVE_MODELER_HPP
#define EXTRAP_SINGLE_PARAMETER_EXHAUSTIVE_MODELER_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_SingleParameterFunctionModeler.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterFunction.hpp>
#include <EXTRAP_Fraction.hpp>
#include <cassert>
#include <fstream>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
class SingleParameterExhaustiveFunctionModeler : public SingleParameterFunctionModeler
{
    friend class SingleParameterExhaustiveModelGenerator;

public:
    static const std::string SINGLEPARAMETEREXHAUSTIVEFUNCTIONMODELER_PREFIX;

    virtual SingleParameterHypothesis
    createModel( const Experiment*             experiment,
                 const ModelGeneratorOptions&  options,
                 const std::vector<DataPoint>& modeledDataPointList,
                 ModelCommentList&             comments,
                 const Function*               expectationFunction = NULL );

    virtual bool
    initSearchSpace( void );

    virtual bool
    nextHypothesis( void );

    virtual SingleParameterFunction*
    buildCurrentHypothesis( void );

    virtual bool
    compareHypotheses( const SingleParameterHypothesis& first,
                       const SingleParameterHypothesis& second,
                       const std::vector<DataPoint>&    modeledDataPointList );

protected:
    //Start of external state
    // (nothing here)
    //End of external state

    Fraction m_current_poly_exponent;
    Fraction m_current_log_exponent;
    double   m_constantCost;

    std::ofstream m_outputStream;

    std::string m_functionName;

    void
    writeHeader( void );
    void
    writeModel( SingleParameterHypothesis&    hypothesis,
                double                        polyExponent,
                double                        logExponent,
                const std::vector<DataPoint>& modeledDataPointList );
};
bool
equal( const SingleParameterExhaustiveFunctionModeler* lhs,
       const SingleParameterExhaustiveFunctionModeler* rhs );
};

#endif
