/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_REFINING_MODELER_HPP
#define EXTRAP_SINGLE_PARAMETER_REFINING_MODELER_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_SingleParameterFunctionModeler.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterFunction.hpp>
#include <EXTRAP_Fraction.hpp>
#include <cassert>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
class SingleParameterRefiningFunctionModeler : public SingleParameterFunctionModeler
{
public:
    virtual SingleParameterHypothesis
    createModel( const Experiment*             experiment,
                 const ModelGeneratorOptions&  options,
                 const std::vector<DataPoint>& modeledDataPointList,
                 ModelCommentList&             comments,
                 const Function*               expectationFunction = NULL );

    virtual bool
    initSearchSpace( void );

    virtual bool
    nextHypothesis( void );

    virtual SingleParameterFunction*
    buildCurrentHypothesis( void );

    virtual bool
    compareHypotheses( const SingleParameterHypothesis& first,
                       const SingleParameterHypothesis& second,
                       const std::vector<DataPoint>&    modeledDataPointList );

protected:
    enum Step
    {
        REFINING_STEP_INITIAL_POLY,
        REFINING_STEP_REFINEMENT_POLY,
        REFINING_STEP_INITIAL_LOG,
        REFINING_STEP_REFINEMENT_LOG
    };

    struct SearchState
    {
        Fraction                  left;
        Fraction                  center;
        Fraction                  right;
        SingleParameterHypothesis hypothesis;
    };

    virtual SingleParameterHypothesis
    createModelCore( const std::vector<DataPoint>& modeledDataPointList,
                     const Function*               expectationFunction,
                     ModelCommentList&             comments,
                     double*                       constantCost );

    //Start of external state
    // (nothing here)
    //End of external state

    Fraction m_current_best_exponent; // needed to pass hypothesis exponent as fraction out of findBestHypothesis
    Step     m_step;
    Fraction m_current_poly_exponent;
    Fraction m_current_log_exponent;
    Fraction m_left_exponent;
    Fraction m_right_exponent;
    bool     m_left_done;
};
};

#endif
