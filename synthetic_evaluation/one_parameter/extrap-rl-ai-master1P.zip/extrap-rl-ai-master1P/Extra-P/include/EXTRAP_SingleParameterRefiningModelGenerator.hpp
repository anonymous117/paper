/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_REFINING_MODEL_GENERATOR_HPP
#define EXTRAP_SINGLE_PARAMETER_REFINING_MODEL_GENERATOR_HPP


#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterHypothesis.hpp>
#include <EXTRAP_SingleParameterModelGenerator.hpp>
#include <EXTRAP_SingleParameterRefiningFunctionModeler.hpp>

namespace EXTRAP
{
class SingleParameterFunction;

class SingleParameterRefiningModelGenerator : public SingleParameterModelGenerator
{
public:

    static const std::string SINGLEPARAMETERREFININGMODELGENERATOR_PREFIX;
    SingleParameterRefiningModelGenerator();

    virtual bool
    serialize(
        IoHelper* ioHelper ) const;

    static SingleParameterRefiningModelGenerator*
    deserialize(
        IoHelper* ioHelper );

protected:
    virtual SingleParameterFunctionModeler&
    getFunctionModeler() const;

    SingleParameterRefiningFunctionModeler* m_modeler;
};

bool
equal( const SingleParameterRefiningModelGenerator* lhs,
       const SingleParameterRefiningModelGenerator* rhs );
};

#endif
