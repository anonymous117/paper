/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_EXHAUSTIVE_MODEL_GENERATOR_HPP
#define EXTRAP_SINGLE_PARAMETER_EXHAUSTIVE_MODEL_GENERATOR_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterHypothesis.hpp>
#include <EXTRAP_SingleParameterModelGenerator.hpp>
#include <EXTRAP_SingleParameterExhaustiveFunctionModeler.hpp>

namespace EXTRAP
{
class SingleParameterFunction;

class SingleParameterExhaustiveModelGenerator : public SingleParameterModelGenerator
{
public:

    static const std::string SINGLEPARAMETEREXHAUSTIVEMODELGENERATOR_PREFIX;
    SingleParameterExhaustiveModelGenerator();

    void
    openOutputFile(  const std::string& file );
    void
    closeOutputFile( void );
    void
    setFunctionName( const std::string& name );
    SingleParameterExhaustiveModelGenerator*
    deserialize(
        IoHelper* ioHelper );
    bool
    serialize(
        IoHelper* ioHelper ) const;

protected:
    virtual SingleParameterFunctionModeler&
    getFunctionModeler() const;

    SingleParameterExhaustiveFunctionModeler* m_modeler;
};

bool
equal( const SingleParameterExhaustiveModelGenerator* lhs,
       const SingleParameterExhaustiveModelGenerator* rhs );
};

#endif
