/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MULTI_PARAMETER_SIMPLE_MODELER_HPP
#define EXTRAP_MULTI_PARAMETER_SIMPLE_MODELER_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_MultiParameterFunctionModeler.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_MultiParameterFunction.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>
#include <EXTRAP_Fraction.hpp>
#include <cassert>

namespace EXTRAP
{
class MultiParameterSimpleFunctionModeler : public MultiParameterFunctionModeler
{
public:
    virtual MultiParameterHypothesis
    createModel( const Experiment*             experiment,
                 const ModelGeneratorOptions&  options,
                 const std::vector<DataPoint>& modeledDataPointList,
                 ModelCommentList&             comments,
                 const Function*               expectationFunction = NULL );

protected:

    //Start of external state
    // (nothing here)
    //End of external state
};
};

#endif
