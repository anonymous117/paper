/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_ARITHMETICS_HPP
#define EXTRAP_ARITHMETICS_HPP

#include <EXTRAP_Experiment.hpp>

namespace EXTRAP
{
Value
getMaxValueFromDatapoints( const Experiment&         experiment,
                           const Metric&             metric,
                           const Callpath&           callpath,
                           const int                 datapointType,
                           const ParameterValueList& maxParams );
};
#endif
