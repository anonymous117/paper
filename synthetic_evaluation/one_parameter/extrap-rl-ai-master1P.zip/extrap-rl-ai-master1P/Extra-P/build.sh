BASEDIR=$1
#HDF5_HOME=/usr/local/hdf5
CUBE_HOME=/home/marcus/Cube/Cubelib/
INSTALL_DIR=/home/marcus/ExtraP/Builds/synth
PYTHON_DIR=/usr/include/python3.6

check_error()
{
    if [ $? -ne 0 ]; then
	exit 1
    fi
}

set -x

env

echo "change to "$BASEDIR
cd "$BASEDIR"
echo $PWD
./tools/beautifier/beautify
cd tools/python_wrapper
make
cd ../..
./bootstrap
rm -r vpath
mkdir vpath
cd vpath
CPPFLAGS="-I$PYTHON_DIR -g -std=c++98"
export CPPFLAGS
../configure --prefix=/$INSTALL_DIR --with-cube=$CUBE_HOME #--with-hdf5=$HDF5_HOME
check_error

make install
check_error

#make check
#check_error

#make installcheck
#check_error

#$INSTALL_DIR/bin/extrap
