#!/usr/local/bin/python3
##
## This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
##
## Copyright (c) 2016-2018,
## Technische Universitaet Darmstadt, Germany
##
## This software may be modified and distributed under the terms of
## a BSD-style license.  See the COPYING file in the package base
## directory for details.
##

import sys
import os
import EXTRAP

try:
   from PyQt4.QtGui import *
except ImportError:
   from PyQt5.QtWidgets import *
from extrap.MainWidget import MainWidget

app = QApplication(sys.argv)
filename = os.environ['DATADIR'] + '/input.txt'
experiment = EXTRAP.Experiment.openTextInput( filename )

# create modeler here, since it is not a part of the openTextInput() function anymore
modeler = EXTRAP.SingleParameterRefiningModelGenerator()
modeler.setUserName('model')
modeler.thisown = False  # Pass ownership to C++ library, core dumped if omitted...
modeler.setModelOptions(EXTRAP.GENERATE_MODEL_MEAN)
#modeler.setModelOptions(EXTRAP.GENERATE_MODEL_MEDIAN)
experiment.addModelGenerator(modeler)
experiment.modelAll(modeler)

gui_object = MainWidget()
gui_object.setExperiment( experiment )
gui_object.selector_widget.selectLastModel()
gui_object.selector_widget.renameCurrentModel( "Default Model" )
