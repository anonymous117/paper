/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_CubeFileReader.hpp>
#include <EXTRAP_Experiment.hpp>
#include <EXTRAP_IncrementalPoint.hpp>
#include <EXTRAP_SingleParameterRefiningModelGenerator.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <ctime>
#include <fstream>
#include <map>

using namespace std;
using namespace EXTRAP;

struct fn_descriptor
{
    double constant;
    double coefficient;
    double polyexp;
    double logexp;
    double coefficient2;
    double polyexp2;
    double logexp2;
};

// extracts the descriptor of the first compound term in the function
fn_descriptor
extract_fn_descriptor( const SingleParameterFunction* fn )
{
    fn_descriptor result;
    result.constant     = fn->getConstantCoefficient();
    result.coefficient  = 0;
    result.polyexp      = 0;
    result.logexp       = 0;
    result.coefficient2 = 0;
    result.polyexp2     = 0;
    result.logexp2      = 0;

    if ( fn->getCompoundTerms().size() == 0 )
    {
        return result;
    }

    CompoundTerm ct = fn->getCompoundTerms()[ 0 ];
    result.coefficient = ct.getCoefficient();

    for ( int i = 0; i < ct.getSimpleTerms().size(); i++ )
    {
        assert( i < 2 );
        SimpleTerm st = ct.getSimpleTerms()[ i ];
        if ( st.getFunctionType() == polynomial )
        {
            result.polyexp = st.getExponent();
        }
        else if ( st.getFunctionType() == logarithm )
        {
            result.logexp = st.getExponent();
        }
        else
        {
            assert( false );
        }
    }

    if ( fn->getCompoundTerms().size() > 1 )
    {
        CompoundTerm ct = fn->getCompoundTerms()[ 1 ];
        result.coefficient2 = ct.getCoefficient();

        for ( int i = 0; i < ct.getSimpleTerms().size(); i++ )
        {
            assert( i < 2 );
            SimpleTerm st = ct.getSimpleTerms()[ i ];
            if ( st.getFunctionType() == polynomial )
            {
                result.polyexp2 = st.getExponent();
            }
            else if ( st.getFunctionType() == logarithm )
            {
                result.logexp2 = st.getExponent();
            }
            else
            {
                assert( false );
            }
        }
    }
    return result;
}

std::map<int, fn_descriptor> current_expectations;

Experiment*
openExperimentFileWithExpectation( const std::string& filename )
{
    current_expectations.clear();

    std::ifstream dataFile;
    dataFile.open( filename.c_str(), std::ios::in );
    std::string lineString;
    std::string fieldName;
    //  int state=0;
    if ( dataFile.is_open() == false )
    {
        std::cout << "Error: Unable to open the test data file " << filename << std::endl;

        exit( EXIT_FAILURE );
    }
    Experiment* new_experiment = new Experiment();
    Metric*     new_metric     = new Metric( "Test", "unknown" );
    new_experiment->addMetric( new_metric );
    Parameter p( "p" );
    new_experiment->addParameter( p );
    CoordinateList   pointslist;
    Region*          new_region = NULL;
    Region*          old_region = NULL;
    Callpath*        callpath;
    int              defined_param = 0;
    IncrementalPoint data_points;
    double           iterator = 0;
    fn_descriptor    new_expectation;
    bool             new_has_expectation;

    int currentLine = 0;
    while ( !dataFile.eof() )
    {
        /* get a line and store in lineString */
        getline( dataFile, lineString, '\n' );
        currentLine++;

        /* ignore empty lines */
        if ( lineString.empty() )
        {
            continue;
        }
        /* ignore comments */
        if ( lineString.c_str()[ 0 ] == '#' )
        {
            /* but do parse EXPECT */
            std::istringstream iss( lineString.c_str() + 1 );
            iss >> fieldName;
            if ( fieldName == "EXPECT" )
            {
                new_has_expectation = true;
                iss >> new_expectation.constant;
                iss >> new_expectation.coefficient;
                iss >> new_expectation.polyexp;
                iss >> new_expectation.logexp;
                iss >> new_expectation.coefficient2;
                iss >> new_expectation.polyexp2;
                iss >> new_expectation.logexp2;
            }
            continue;
        }

        /* get name of field */
        std::istringstream iss( lineString );
        iss >> fieldName;
        std::string tmp;

        if ( fieldName == "REGION" )
        {
            tmp.clear();
            iss >> tmp;
            new_region = new Region( tmp, filename, 1 );
            new_experiment->addRegion( new_region );
            callpath = new Callpath( new_region, NULL );
            new_experiment->addCallpath( callpath );
            new_has_expectation = false;
        }
        else if ( fieldName == "DATA" )
        {
            if ( new_has_expectation )
            {
                // EXPERIMENT line came before, so the new callpath has been added
                int callpath_id = new_experiment->getAllCallpaths().size() - 1;
                current_expectations[ callpath_id ] = new_expectation;
            }

            data_points.clear();
            //double test;
            //iss >> test;
            while ( !iss.eof() )
            {
                double data_point;
                iss >> data_point;
                data_points.addValue( data_point );
            }
            if ( new_region == NULL )
            {
                std::cout << "Error in line " << currentLine << ": experiment line missing " << std::endl;

                exit( EXIT_FAILURE );
            }
            if ( ( iterator == 0 ) && ( old_region == new_region ) && ( old_region != NULL ) )
            {
                std::cout << "Error in line " << currentLine << ": too many data points lines before new experiment  " << std::endl;

                exit( EXIT_FAILURE );
            }
            if ( ( iterator != 0 ) && ( old_region != new_region ) && ( old_region != NULL ) )
            {
                std::cout << "Error in line " << currentLine << ": too few data points lines before new experiment " << std::endl;

                exit( EXIT_FAILURE );
            }
            if ( iterator >= pointslist.size() )
            {
                std::cout << "Error in line " << currentLine << ": measurement points should be defined " << std::endl;

                exit( EXIT_FAILURE );
            }
            new_experiment->addDataPoint( data_points.getExperimentPoint( pointslist[ iterator ],
                                                                          new_metric,
                                                                          callpath ),
                                          *new_metric, *callpath );
            iterator++;
            if ( iterator == pointslist.size() )
            {
                iterator = 0;
            }
            old_region = new_region;
        }

        else if ( fieldName == "POINTS" )
        {
            double old_value;
            double value;
            bool   first = true;
            while ( !iss.eof() )
            {
                iss >> value;
                if ( first == true )
                {
                    first     = false;
                    old_value = value;
                    Coordinate* pv_list = new Coordinate();
                    //std::cout<<"pvl:"<<value<<std::endl;
                    ( *pv_list )[ Parameter( "p" ) ] = value;
                    pointslist.push_back( pv_list );
                }
                else if ( old_value != value )
                {
                    Coordinate* pv_list = new Coordinate();
                    ( *pv_list )[ Parameter( "p" ) ] = value;
                    pointslist.push_back( pv_list );
                    //std::cout<<"pvl:"<<value<<std::endl;
                    old_value = value;
                }
            }
        }
        else
        {
            std::cout << "Error state: " << fieldName << " not a valid test file row start value (prepare_data.cpp)";

            exit( EXIT_FAILURE );
        }
    }
    dataFile.close();

    return new_experiment;
}

void
logModelCSV( std::ostream& outstream, const std::string& metric, const std::string& callpath, const std::string& algorithm, const std::string& model, int num_terms, fn_descriptor model_desc, double RSS, double SMAPE, double AR2, fn_descriptor* expectation_desc, double validateLastX, double validateLastY, double modelLastY )
{
    outstream << metric << "," << callpath << "," << algorithm << "," << model << "," << num_terms << "," << model_desc.constant << "," << model_desc.coefficient << "," << model_desc.polyexp << "," << model_desc.logexp << "," << model_desc.coefficient2 << "," << model_desc.polyexp2 << "," << model_desc.logexp2 << "," << RSS << "," << SMAPE << "," << AR2;
    if ( expectation_desc == NULL )
    {
        outstream << ",,,,";
    }
    else
    {
        outstream << "," << expectation_desc->constant << "," << expectation_desc->coefficient << "," << expectation_desc->polyexp << "," << expectation_desc->logexp << "," << expectation_desc->coefficient2 << "," << expectation_desc->polyexp2 << "," << expectation_desc->logexp2;
    }
    outstream << "," << validateLastX << "," << validateLastY << "," << modelLastY;
    outstream << std::endl;
    return;
}

void
logModelCSV( std::ostream& outstream, const std::string& metric, const std::string& callpath, const std::string& algorithm, const Model* model, fn_descriptor* expectation_desc, ExperimentPoint* validateLastPoint )
{
    SingleParameterFunction* function      = dynamic_cast<SingleParameterFunction*>( model->getModelFunction() );
    double                   validateLastX = validateLastPoint->getCoordinate().begin()->second;
    double                   validateLastY = validateLastPoint->getMedian();
    double                   modelLastY    = function->evaluate( validateLastPoint->getCoordinate() );
    logModelCSV( outstream, metric, callpath, algorithm, function->getAsString( "p" ), function->getCompoundTerms().size(), extract_fn_descriptor( function ), model->getRSS(), model->getSMAPE(), model->getAR2(), expectation_desc, validateLastX, validateLastY, modelLastY );
    return;
}

void
compareModelsInExperiment( Experiment* experiment, SingleParameterSimpleModelGenerator* oldGenerator1, SingleParameterSimpleModelGenerator* oldGenerator2, SingleParameterRefiningModelGenerator* refiningGenerator, std::ostream& outstream, bool validateLast )
{
    assert( refiningGenerator != NULL );

    MetricList   metrics   = experiment->getMetrics();
    CallpathList callpaths = experiment->getAllCallpaths();

    for ( MetricList::iterator metric_it = metrics.begin();
          metric_it != metrics.end();
          metric_it++ )
    {
        Metric* metric = *metric_it;
        std::cout << "Analysing metric " << metric->getName() << std::endl;
        int c = 0;
        for ( CallpathList::iterator callpath_it = callpaths.begin();
              callpath_it != callpaths.end();
              callpath_it++ )
        {
            Callpath* callpath = *callpath_it;

            // If a given callpath/metric only contains measurements of "0", there actually is no real data
            const ExperimentPointList data_points       = experiment->getPoints( *metric, *callpath );
            bool                      datapoint_nonzero = false;
            for ( ExperimentPointList::const_iterator it = data_points.begin(); it < data_points.end(); ++it )
            {
                if ( ( *it )->getMedian() != 0 )
                {
                    datapoint_nonzero = true;
                    break;
                }
            }
            if ( !datapoint_nonzero )
            {
                // callpath is actually not populated for this metric -> skip it
                continue;
            }

            EXTRAP::ModelGeneratorOptions options = EXTRAP::ModelGeneratorOptions();

            Model* refModel  = refiningGenerator->createModel( experiment, options, data_points );
            Model* oldModel1 = oldGenerator1 != NULL ? oldGenerator1->createModel( experiment, options, data_points ) : NULL;
            Model* oldModel2 = oldGenerator2 != NULL ? oldGenerator2->createModel( experiment, options, data_points ) : NULL;

            fn_descriptor*                         exp = NULL; // NULL means no expectation
            std::map<int, fn_descriptor>::iterator it  = current_expectations.find( callpath->getId() );
            if ( it != current_expectations.end() )
            {
                //outstream << "Has EXPECTATION!" << std::endl;
                exp = &it->second;
            }

            ExperimentPoint* validateLastPoint = *data_points.rbegin();

            if ( oldModel1 != NULL )
            {
                logModelCSV( outstream, metric->getName(), callpath->getFullName(), "old1", oldModel1, exp, validateLastPoint );
            }
            if ( oldModel2 != NULL )
            {
                logModelCSV( outstream, metric->getName(), callpath->getFullName(), "old2", oldModel2, exp, validateLastPoint );
            }
            logModelCSV( outstream, metric->getName(), callpath->getFullName(), "refining", refModel, exp, validateLastPoint );

            delete oldModel1;
            delete oldModel2;
            delete refModel;

            if ( validateLast )
            {
                EXTRAP::ModelGeneratorOptions options              = EXTRAP::ModelGeneratorOptions();
                ExperimentPointList           data_points_skiplast = data_points; // copy list (of pointers)
                data_points_skiplast.pop_back();                                  // remove last point
                Model* refModelSkipLast  = refiningGenerator->createModel( experiment, options, data_points_skiplast );
                Model* oldModel1SkipLast = oldGenerator1 != NULL ? oldGenerator1->createModel( experiment, options, data_points_skiplast ) : NULL;
                Model* oldModel2SkipLast = oldGenerator2 != NULL ? oldGenerator2->createModel( experiment, options, data_points_skiplast ) : NULL;

                if ( oldModel1SkipLast != NULL )
                {
                    logModelCSV( outstream, metric->getName(), callpath->getFullName(), "old1-skiplast", oldModel1SkipLast, exp, validateLastPoint );
                }
                if ( oldModel2SkipLast != NULL )
                {
                    logModelCSV( outstream, metric->getName(), callpath->getFullName(), "old2-skiplast", oldModel2SkipLast, exp, validateLastPoint );
                }
                logModelCSV( outstream, metric->getName(), callpath->getFullName(), "refining-skiplast", refModelSkipLast, exp, validateLastPoint );
                delete refModelSkipLast;
                delete oldModel1SkipLast;
                delete oldModel2SkipLast;
            }

            c++;
        }
    }
}

int
main( int argc, char* argv[] )
{
    std::string  inputPath = EXTRAP_TEST_DIR "/data/experiment.txt";
    std::ostream outstream( std::cout.rdbuf() );

    std::ofstream outfile;

    if ( argc > 1 )
    {
        // command line parameters were given
        inputPath = argv[ 1 ];

        if ( argc > 2 )
        {
            outfile.open( argv[ 2 ], std::ios::out );
            if ( !outfile.is_open() )
            {
                std::cout << "Error: Unable to open output file " << argv[ 2 ] << std::endl;
                exit( EXIT_FAILURE );
            }
            outstream.rdbuf( outfile.rdbuf() );
        }
    }
    std::srand( std::time( 0 ) );

    outstream << "metric,callpath,algorithm,model,num_terms,m_constant,m_coefficient,m_polyexp,m_logexp,m_coefficient2,m_polyexp2,m_logexp2,RSS,SMAPE,AR2,expect_constant,expect_coefficient,expect_polyexp,expect_logexp,expect_coefficient2,expect_polyexp2,expect_logexp2,validatelast_x,validatelast_y,validatelast_y_model" << std::endl;

    SingleParameterRefiningModelGenerator refiningGenerator;
    refiningGenerator.setEpsilon( 0.05 );
    //refiningGenerator.setModelOptions( GENERATE_MODEL_MEDIAN );


    std::vector<double> poly_exponents;
    for ( int n = 1; n <= 12; n++ )
    {
        poly_exponents.push_back( n / 4.0 );
    }

    std::vector<double> log_exponents;
    log_exponents.push_back( 1.0 );
    log_exponents.push_back( 2.0 );

    SingleParameterSimpleModelGenerator oldGenerator1;
    SingleParameterSimpleModelGenerator oldGenerator2;

    oldGenerator1.generateHypothesisBuildingBlockSet( poly_exponents, log_exponents );
    oldGenerator1.setMaxTermCount( 1 );
    oldGenerator1.setEpsilon( 0.05 );
    oldGenerator1.printHypothesisBuildingBlocks();
    //oldGenerator1.setModelOptions( GENERATE_MODEL_MEDIAN );

    oldGenerator2.generateHypothesisBuildingBlockSet( poly_exponents, log_exponents );
    oldGenerator2.setMaxTermCount( 2 );
    oldGenerator2.setEpsilon( 0.05 );
    oldGenerator2.printHypothesisBuildingBlocks();
    //oldGenerator2.setModelOptions( GENERATE_MODEL_MEDIAN );

#if 0
    // Code path for reading CUBE experiment
    EXTRAP::CubeFileReader reader = CubeFileReader();

    // Uncomment one of the following blocks (and adjust paths) to read case study data as used for the paper

//    reader.prepareCubeFileReader( 1, "/home/reisert/Desktop/cube-data/sweep3D", "scorep_scorep_weak.", "", "profile.cubex", 4 );
//    vector<int> v;
//    v.push_back( 32 );
//    v.push_back( 64 );
//    v.push_back( 128 );
//    v.push_back( 256 );
//    v.push_back( 512 );
//    v.push_back( 1024 );
//    v.push_back( 2048 );

//    reader.prepareCubeFileReader( 1, "/home/reisert/Desktop/cube-data/blast", "blast.", "", "profile.cubex", 5 );
//    vector<int> v;
//    v.push_back( 64 );
//    v.push_back( 256 );
//    v.push_back( 1024 );
//    v.push_back( 4096 );
//    v.push_back( 16384 );

//    reader.prepareCubeFileReader( 1, "/home/reisert/Desktop/cube-data/kripke-results2/", "kripke.", "d2", "profile.cubex", 5 );
//    vector<int> v;
//    v.push_back( 8 );
//    v.push_back( 64 );
//    v.push_back( 512 );
//    v.push_back( 4096 );
//    v.push_back( 32768 );

//    reader.prepareCubeFileReader( 1, "/home/reisert/Desktop/cube-data/milc/", "scorep_milc_weak.", "", "profile.cubex", 5 );
//    vector<int> v;
//    v.push_back( 256 );
//    v.push_back( 512 );
//    v.push_back( 1024 );
//    v.push_back( 2048 );
//    v.push_back( 4096 );
//    v.push_back( 8192 );
//    v.push_back( 16384 );

    reader.addParameter( EXTRAP::Parameter( "p" ), "p", v );
    Experiment* cubeExperiment = reader.readCubeFiles( 1 );
    compareModelsInExperiment( cubeExperiment, NULL, &oldGenerator2, &refiningGenerator, outstream, true );

    delete cubeExperiment;
#else
    EXTRAP::Experiment* experiment = openExperimentFileWithExpectation( inputPath );
    // set last parameter to true to evaluate case studies (loaded from experiment files) as in the paper!
    compareModelsInExperiment( experiment, &oldGenerator1, &oldGenerator2, &refiningGenerator, outstream, false /*true*/ );
    delete experiment;
#endif

    if ( outfile.is_open() )
    {
        outfile.close();
    }

    return 0;
}
