/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stdio.h>
#include <iostream>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <cassert>
#include <EXTRAP_IncrementalPoint.hpp>

using namespace std;

void
test( void ( * f )( void ) )
{
    ( *f )();
}

void
testOpenTextIntegrity( void )
{
    //create experiment object to check against
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();

    EXTRAP::Region* region = new EXTRAP::Region( "reg", EXTRAP_TEST_DIR "/data/input/input_data_1p.txt", 1 );
    experiment->addRegion( region );

    EXTRAP::Callpath* callpath = new EXTRAP::Callpath( region, NULL );
    experiment->addCallpath( callpath );

    EXTRAP::Metric* metric = new EXTRAP::Metric( "metr", "unknown" );
    experiment->addMetric( metric );

    EXTRAP::Parameter parameter = EXTRAP::Parameter( "x" );
    experiment->addParameter( parameter );

    EXTRAP::Coordinate* c1 = new EXTRAP::Coordinate();
    c1->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    experiment->addCoordinate( c1 );
    EXTRAP::Coordinate* c2 = new EXTRAP::Coordinate();
    c2->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    experiment->addCoordinate( c2 );
    EXTRAP::Coordinate* c3 = new EXTRAP::Coordinate();
    c3->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    experiment->addCoordinate( c3 );
    EXTRAP::Coordinate* c4 = new EXTRAP::Coordinate();
    c4->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    experiment->addCoordinate( c4 );
    EXTRAP::Coordinate* c5 = new EXTRAP::Coordinate();
    c5->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    experiment->addCoordinate( c5 );

    EXTRAP::IncrementalPoint data_point1;
    data_point1.addValue( 82.00848518948744 );
    data_point1.addValue( 81.42023198759563 );
    data_point1.addValue( 81.98984501217201 );
    data_point1.addValue( 80.76019835580321 );
    data_point1.addValue( 82.54252892405795 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c1, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 184.5140079299443 );
    data_point1.addValue( 177.46069577925178 );
    data_point1.addValue( 179.12260901809867 );
    data_point1.addValue( 178.9221229310546 );
    data_point1.addValue( 177.93461023001083 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c2, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 315.26845992523744 );
    data_point1.addValue( 314.8769218843138 );
    data_point1.addValue( 315.7165660477195 );
    data_point1.addValue( 324.22329944880516 );
    data_point1.addValue( 323.2719163782126 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c3, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 509.81064352081336 );
    data_point1.addValue( 495.74457198852593 );
    data_point1.addValue( 501.0059487282256 );
    data_point1.addValue( 502.5272204028191 );
    data_point1.addValue( 509.6665018646357 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c4, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 725.3886983183301 );
    data_point1.addValue( 727.8628493044997 );
    data_point1.addValue( 727.0517005284136 );
    data_point1.addValue( 729.5284355624206 );
    data_point1.addValue( 721.0616186790007 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c5, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    //load experiment from openText()
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/input/input_data_1p.txt" );

    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
}

void
testOpenTextIntegrityMultiParam( void )
{
    //create experiment object to check against
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();

    EXTRAP::Region* region = new EXTRAP::Region( "reg", EXTRAP_TEST_DIR "/data/input/input_data_2p.txt", 1 );
    experiment->addRegion( region );

    EXTRAP::Callpath* callpath = new EXTRAP::Callpath( region, NULL );
    experiment->addCallpath( callpath );

    EXTRAP::Metric* metric = new EXTRAP::Metric( "metr", "unknown" );
    experiment->addMetric( metric );

    EXTRAP::Parameter parameter  = EXTRAP::Parameter( "x" );
    EXTRAP::Parameter parameter2 = EXTRAP::Parameter( "y" );
    experiment->addParameter( parameter );
    experiment->addParameter( parameter2 );

    EXTRAP::Coordinate* c11 = new EXTRAP::Coordinate();
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c11 );
    EXTRAP::Coordinate* c12 = new EXTRAP::Coordinate();
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c12 );
    EXTRAP::Coordinate* c13 = new EXTRAP::Coordinate();
    c13->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c13->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c13 );
    EXTRAP::Coordinate* c14 = new EXTRAP::Coordinate();
    c14->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c14->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c14 );
    EXTRAP::Coordinate* c15 = new EXTRAP::Coordinate();
    c15->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c15->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c15 );

    EXTRAP::Coordinate* c21 = new EXTRAP::Coordinate();
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c21 );
    EXTRAP::Coordinate* c22 = new EXTRAP::Coordinate();
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c22 );
    EXTRAP::Coordinate* c23 = new EXTRAP::Coordinate();
    c23->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c23->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c23 );
    EXTRAP::Coordinate* c24 = new EXTRAP::Coordinate();
    c24->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c24->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c24 );
    EXTRAP::Coordinate* c25 = new EXTRAP::Coordinate();
    c25->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c25->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c25 );

    EXTRAP::Coordinate* c31 = new EXTRAP::Coordinate();
    c31->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c31->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c31 );
    EXTRAP::Coordinate* c32 = new EXTRAP::Coordinate();
    c32->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c32->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c32 );
    EXTRAP::Coordinate* c33 = new EXTRAP::Coordinate();
    c33->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c33->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c33 );
    EXTRAP::Coordinate* c34 = new EXTRAP::Coordinate();
    c34->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c34->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c34 );
    EXTRAP::Coordinate* c35 = new EXTRAP::Coordinate();
    c35->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c35->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c35 );

    EXTRAP::Coordinate* c41 = new EXTRAP::Coordinate();
    c41->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c41->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c41 );
    EXTRAP::Coordinate* c42 = new EXTRAP::Coordinate();
    c42->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c42->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c42 );
    EXTRAP::Coordinate* c43 = new EXTRAP::Coordinate();
    c43->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c43->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c43 );
    EXTRAP::Coordinate* c44 = new EXTRAP::Coordinate();
    c44->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c44->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c44 );
    EXTRAP::Coordinate* c45 = new EXTRAP::Coordinate();
    c45->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c45->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c45 );

    EXTRAP::Coordinate* c51 = new EXTRAP::Coordinate();
    c51->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c51->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c51 );
    EXTRAP::Coordinate* c52 = new EXTRAP::Coordinate();
    c52->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c52->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c52 );
    EXTRAP::Coordinate* c53 = new EXTRAP::Coordinate();
    c53->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c53->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c53 );
    EXTRAP::Coordinate* c54 = new EXTRAP::Coordinate();
    c54->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c54->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c54 );
    EXTRAP::Coordinate* c55 = new EXTRAP::Coordinate();
    c55->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c55->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c55 );

    EXTRAP::IncrementalPoint data_point;

    data_point.addValue( 1.007912824061828 );
    data_point.addValue( 1.0003031166379763 );
    data_point.addValue( 1.0146314163801136 );
    data_point.addValue( 0.9888371709656842 );
    data_point.addValue( 0.9814784961141532 );
    experiment->addDataPoint( data_point.getExperimentPoint( c11, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 82.31483486850328 );
    data_point.addValue( 80.77055829825096 );
    data_point.addValue( 81.65028667288966 );
    data_point.addValue( 79.84894914331908 );
    data_point.addValue( 80.69133265056031 );
    experiment->addDataPoint( data_point.getExperimentPoint( c12, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 127.0982588521472 );
    data_point.addValue( 129.97720256124214 );
    data_point.addValue( 126.37233644578495 );
    data_point.addValue( 129.95328527792617 );
    data_point.addValue( 128.79143884701386 );
    experiment->addDataPoint( data_point.getExperimentPoint( c13, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 163.761116922403 );
    data_point.addValue( 160.64424490477055 );
    data_point.addValue( 163.15711078980416 );
    data_point.addValue( 159.9466809220868 );
    data_point.addValue( 161.16513023758068 );
    experiment->addDataPoint( data_point.getExperimentPoint( c14, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 186.84836895674908 );
    data_point.addValue( 186.88261474927117 );
    data_point.addValue( 189.29212868834847 );
    data_point.addValue( 187.00694904185926 );
    data_point.addValue( 183.26480034190746 );
    experiment->addDataPoint( data_point.getExperimentPoint( c15, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 1.0195866920777528 );
    data_point.addValue( 0.9965626548891021 );
    data_point.addValue( 1.0181840262519737 );
    data_point.addValue( 0.9863362890535387 );
    data_point.addValue( 0.9893290137007527 );
    experiment->addDataPoint( data_point.getExperimentPoint( c21, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 179.55463831422327 );
    data_point.addValue( 180.74821882024628 );
    data_point.addValue( 183.8728518616761 );
    data_point.addValue( 182.54443671884627 );
    data_point.addValue( 182.24933579588313 );
    experiment->addDataPoint( data_point.getExperimentPoint( c22, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 280.6908234409108 );
    data_point.addValue( 281.788263615464 );
    data_point.addValue( 283.863933677854 );
    data_point.addValue( 283.8298464032916 );
    data_point.addValue( 288.8773066881149 );
    experiment->addDataPoint( data_point.getExperimentPoint( c23, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 366.23299595860806 );
    data_point.addValue( 361.4313754663896 );
    data_point.addValue( 364.474908755492 );
    data_point.addValue( 367.28360995699853 );
    data_point.addValue( 359.8692941474022 );
    experiment->addDataPoint( data_point.getExperimentPoint( c24, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 424.1140021695517 );
    data_point.addValue( 416.5453483049455 );
    data_point.addValue( 425.49863768871654 );
    data_point.addValue( 419.9658709243348 );
    data_point.addValue( 418.9048409420776 );
    experiment->addDataPoint( data_point.getExperimentPoint( c25, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 0.9832332399984872 );
    data_point.addValue( 0.9815834670845136 );
    data_point.addValue( 1.0003806927451324 );
    data_point.addValue( 0.9968558578424265 );
    data_point.addValue( 0.9820664393235233 );
    experiment->addDataPoint( data_point.getExperimentPoint( c31, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 317.0754172371989 );
    data_point.addValue( 317.36884825095814 );
    data_point.addValue( 315.9495390075145 );
    data_point.addValue( 320.4995994903179 );
    data_point.addValue( 318.6762830447799 );
    experiment->addDataPoint( data_point.getExperimentPoint( c32, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 504.63767808259195 );
    data_point.addValue( 516.0708239589679 );
    data_point.addValue( 507.81689745670286 );
    data_point.addValue( 511.8768307930591 );
    data_point.addValue( 506.2807943653508 );
    experiment->addDataPoint( data_point.getExperimentPoint( c33, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 644.8143141699127 );
    data_point.addValue( 637.3099257201826 );
    data_point.addValue( 649.9174626712269 );
    data_point.addValue( 647.3368427699369 );
    data_point.addValue( 633.2245986830611 );
    experiment->addDataPoint( data_point.getExperimentPoint( c34, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 744.9220213789664 );
    data_point.addValue( 743.3804480439476 );
    data_point.addValue( 741.3314847916288 );
    data_point.addValue( 749.8014199318746 );
    data_point.addValue( 739.8083987550706 );
    experiment->addDataPoint( data_point.getExperimentPoint( c35, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 1.0072335327043695 );
    data_point.addValue( 1.005198595503928 );
    data_point.addValue( 1.0076803056588366 );
    data_point.addValue( 1.003963391133719 );
    data_point.addValue( 0.9931552405725348 );
    experiment->addDataPoint( data_point.getExperimentPoint( c41, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 495.8101061967628 );
    data_point.addValue( 501.64162008360864 );
    data_point.addValue( 507.00077184697335 );
    data_point.addValue( 498.83459734803967 );
    data_point.addValue( 507.88731718138513 );
    experiment->addDataPoint( data_point.getExperimentPoint( c42, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 793.4292405511786 );
    data_point.addValue( 808.4271169186493 );
    data_point.addValue( 794.4488419240894 );
    data_point.addValue( 792.3783818373039 );
    data_point.addValue( 786.1581110613066 );
    experiment->addDataPoint( data_point.getExperimentPoint( c43, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 986.8778797337357 );
    data_point.addValue( 1007.0264271966056 );
    data_point.addValue( 1012.1774356734794 );
    data_point.addValue( 1012.8234104247143 );
    data_point.addValue( 994.8558593224009 );
    experiment->addDataPoint( data_point.getExperimentPoint( c44, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1168.925970055696 );
    data_point.addValue( 1152.305843765793 );
    data_point.addValue( 1163.3320257986136 );
    data_point.addValue( 1181.721114617381 );
    data_point.addValue( 1174.9194990604099 );
    experiment->addDataPoint( data_point.getExperimentPoint( c45, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 1.0123953645414927 );
    data_point.addValue( 0.9808925858487914 );
    data_point.addValue( 0.9883957051154446 );
    data_point.addValue( 1.0097027886766448 );
    data_point.addValue( 1.0160649467948064 );
    experiment->addDataPoint( data_point.getExperimentPoint( c51, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 732.9718870349534 );
    data_point.addValue( 713.5887652750822 );
    data_point.addValue( 731.5598226968582 );
    data_point.addValue( 727.8160069274114 );
    data_point.addValue( 721.843240633473 );
    experiment->addDataPoint( data_point.getExperimentPoint( c52, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1139.5493742034544 );
    data_point.addValue( 1151.1355124340896 );
    data_point.addValue( 1136.4341443870837 );
    data_point.addValue( 1123.1009473444153 );
    data_point.addValue( 1139.5682409322808 );
    experiment->addDataPoint( data_point.getExperimentPoint( c53, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1461.1663792149404 );
    data_point.addValue( 1456.927809881706 );
    data_point.addValue( 1468.5789635626325 );
    data_point.addValue( 1425.7927730830347 );
    data_point.addValue( 1412.4260646792911 );
    experiment->addDataPoint( data_point.getExperimentPoint( c54, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1644.9469847409239 );
    data_point.addValue( 1687.8899020378108 );
    data_point.addValue( 1659.733621973487 );
    data_point.addValue( 1646.4234125252788 );
    data_point.addValue( 1641.8554614544396 );
    experiment->addDataPoint( data_point.getExperimentPoint( c55, metric, callpath ), *metric, *callpath );
    data_point.clear();

    //load experiment from openText()
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/input/input_data_2p.txt" );

    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
}

void
testOpenJsonIntegrityMultiParam( void )
{
    //create experiment object to check against
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();

    EXTRAP::Region* region = new EXTRAP::Region( "reg", EXTRAP_TEST_DIR "/data/input/json_test_input2.txt", 1 );
    experiment->addRegion( region );

    EXTRAP::Callpath* callpath = new EXTRAP::Callpath( region, NULL );
    experiment->addCallpath( callpath );

    EXTRAP::Metric* metric = new EXTRAP::Metric( "metr", "unknown" );
    experiment->addMetric( metric );

    EXTRAP::Parameter parameter  = EXTRAP::Parameter( "x" );
    EXTRAP::Parameter parameter2 = EXTRAP::Parameter( "y" );
    experiment->addParameter( parameter );
    experiment->addParameter( parameter2 );

    EXTRAP::Coordinate* c11 = new EXTRAP::Coordinate();
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c11 );
    EXTRAP::Coordinate* c12 = new EXTRAP::Coordinate();
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c12 );
    EXTRAP::Coordinate* c13 = new EXTRAP::Coordinate();
    c13->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c13->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c13 );
    EXTRAP::Coordinate* c14 = new EXTRAP::Coordinate();
    c14->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c14->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c14 );
    EXTRAP::Coordinate* c15 = new EXTRAP::Coordinate();
    c15->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    c15->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c15 );

    EXTRAP::Coordinate* c21 = new EXTRAP::Coordinate();
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c21 );
    EXTRAP::Coordinate* c22 = new EXTRAP::Coordinate();
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c22 );
    EXTRAP::Coordinate* c23 = new EXTRAP::Coordinate();
    c23->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c23->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c23 );
    EXTRAP::Coordinate* c24 = new EXTRAP::Coordinate();
    c24->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c24->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c24 );
    EXTRAP::Coordinate* c25 = new EXTRAP::Coordinate();
    c25->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    c25->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c25 );

    EXTRAP::Coordinate* c31 = new EXTRAP::Coordinate();
    c31->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c31->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c31 );
    EXTRAP::Coordinate* c32 = new EXTRAP::Coordinate();
    c32->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c32->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c32 );
    EXTRAP::Coordinate* c33 = new EXTRAP::Coordinate();
    c33->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c33->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c33 );
    EXTRAP::Coordinate* c34 = new EXTRAP::Coordinate();
    c34->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c34->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c34 );
    EXTRAP::Coordinate* c35 = new EXTRAP::Coordinate();
    c35->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    c35->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c35 );

    EXTRAP::Coordinate* c41 = new EXTRAP::Coordinate();
    c41->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c41->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c41 );
    EXTRAP::Coordinate* c42 = new EXTRAP::Coordinate();
    c42->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c42->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c42 );
    EXTRAP::Coordinate* c43 = new EXTRAP::Coordinate();
    c43->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c43->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c43 );
    EXTRAP::Coordinate* c44 = new EXTRAP::Coordinate();
    c44->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c44->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c44 );
    EXTRAP::Coordinate* c45 = new EXTRAP::Coordinate();
    c45->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    c45->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c45 );

    EXTRAP::Coordinate* c51 = new EXTRAP::Coordinate();
    c51->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c51->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 1 ) );
    experiment->addCoordinate( c51 );
    EXTRAP::Coordinate* c52 = new EXTRAP::Coordinate();
    c52->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c52->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 2 ) );
    experiment->addCoordinate( c52 );
    EXTRAP::Coordinate* c53 = new EXTRAP::Coordinate();
    c53->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c53->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 3 ) );
    experiment->addCoordinate( c53 );
    EXTRAP::Coordinate* c54 = new EXTRAP::Coordinate();
    c54->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c54->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 4 ) );
    experiment->addCoordinate( c54 );
    EXTRAP::Coordinate* c55 = new EXTRAP::Coordinate();
    c55->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    c55->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter2, 5 ) );
    experiment->addCoordinate( c55 );

    EXTRAP::IncrementalPoint data_point;

    data_point.addValue( 1.007912824061828 );
    data_point.addValue( 1.0003031166379763 );
    data_point.addValue( 1.0146314163801136 );
    data_point.addValue( 0.9888371709656842 );
    data_point.addValue( 0.9814784961141532 );
    experiment->addDataPoint( data_point.getExperimentPoint( c11, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 82.31483486850328 );
    data_point.addValue( 80.77055829825096 );
    data_point.addValue( 81.65028667288966 );
    data_point.addValue( 79.84894914331908 );
    data_point.addValue( 80.69133265056031 );
    experiment->addDataPoint( data_point.getExperimentPoint( c12, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 127.0982588521472 );
    data_point.addValue( 129.97720256124214 );
    data_point.addValue( 126.37233644578495 );
    data_point.addValue( 129.95328527792617 );
    data_point.addValue( 128.79143884701386 );
    experiment->addDataPoint( data_point.getExperimentPoint( c13, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 163.761116922403 );
    data_point.addValue( 160.64424490477055 );
    data_point.addValue( 163.15711078980416 );
    data_point.addValue( 159.9466809220868 );
    data_point.addValue( 161.16513023758068 );
    experiment->addDataPoint( data_point.getExperimentPoint( c14, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 186.84836895674908 );
    data_point.addValue( 186.88261474927117 );
    data_point.addValue( 189.29212868834847 );
    data_point.addValue( 187.00694904185926 );
    data_point.addValue( 183.26480034190746 );
    experiment->addDataPoint( data_point.getExperimentPoint( c15, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 1.0195866920777528 );
    data_point.addValue( 0.9965626548891021 );
    data_point.addValue( 1.0181840262519737 );
    data_point.addValue( 0.9863362890535387 );
    data_point.addValue( 0.9893290137007527 );
    experiment->addDataPoint( data_point.getExperimentPoint( c21, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 179.55463831422327 );
    data_point.addValue( 180.74821882024628 );
    data_point.addValue( 183.8728518616761 );
    data_point.addValue( 182.54443671884627 );
    data_point.addValue( 182.24933579588313 );
    experiment->addDataPoint( data_point.getExperimentPoint( c22, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 280.6908234409108 );
    data_point.addValue( 281.788263615464 );
    data_point.addValue( 283.863933677854 );
    data_point.addValue( 283.8298464032916 );
    data_point.addValue( 288.8773066881149 );
    experiment->addDataPoint( data_point.getExperimentPoint( c23, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 366.23299595860806 );
    data_point.addValue( 361.4313754663896 );
    data_point.addValue( 364.474908755492 );
    data_point.addValue( 367.28360995699853 );
    data_point.addValue( 359.8692941474022 );
    experiment->addDataPoint( data_point.getExperimentPoint( c24, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 424.1140021695517 );
    data_point.addValue( 416.5453483049455 );
    data_point.addValue( 425.49863768871654 );
    data_point.addValue( 419.9658709243348 );
    data_point.addValue( 418.9048409420776 );
    experiment->addDataPoint( data_point.getExperimentPoint( c25, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 0.9832332399984872 );
    data_point.addValue( 0.9815834670845136 );
    data_point.addValue( 1.0003806927451324 );
    data_point.addValue( 0.9968558578424265 );
    data_point.addValue( 0.9820664393235233 );
    experiment->addDataPoint( data_point.getExperimentPoint( c31, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 317.0754172371989 );
    data_point.addValue( 317.36884825095814 );
    data_point.addValue( 315.9495390075145 );
    data_point.addValue( 320.4995994903179 );
    data_point.addValue( 318.6762830447799 );
    experiment->addDataPoint( data_point.getExperimentPoint( c32, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 504.63767808259195 );
    data_point.addValue( 516.0708239589679 );
    data_point.addValue( 507.81689745670286 );
    data_point.addValue( 511.8768307930591 );
    data_point.addValue( 506.2807943653508 );
    experiment->addDataPoint( data_point.getExperimentPoint( c33, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 644.8143141699127 );
    data_point.addValue( 637.3099257201826 );
    data_point.addValue( 649.9174626712269 );
    data_point.addValue( 647.3368427699369 );
    data_point.addValue( 633.2245986830611 );
    experiment->addDataPoint( data_point.getExperimentPoint( c34, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 744.9220213789664 );
    data_point.addValue( 743.3804480439476 );
    data_point.addValue( 741.3314847916288 );
    data_point.addValue( 749.8014199318746 );
    data_point.addValue( 739.8083987550706 );
    experiment->addDataPoint( data_point.getExperimentPoint( c35, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 1.0072335327043695 );
    data_point.addValue( 1.005198595503928 );
    data_point.addValue( 1.0076803056588366 );
    data_point.addValue( 1.003963391133719 );
    data_point.addValue( 0.9931552405725348 );
    experiment->addDataPoint( data_point.getExperimentPoint( c41, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 495.8101061967628 );
    data_point.addValue( 501.64162008360864 );
    data_point.addValue( 507.00077184697335 );
    data_point.addValue( 498.83459734803967 );
    data_point.addValue( 507.88731718138513 );
    experiment->addDataPoint( data_point.getExperimentPoint( c42, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 793.4292405511786 );
    data_point.addValue( 808.4271169186493 );
    data_point.addValue( 794.4488419240894 );
    data_point.addValue( 792.3783818373039 );
    data_point.addValue( 786.1581110613066 );
    experiment->addDataPoint( data_point.getExperimentPoint( c43, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 986.8778797337357 );
    data_point.addValue( 1007.0264271966056 );
    data_point.addValue( 1012.1774356734794 );
    data_point.addValue( 1012.8234104247143 );
    data_point.addValue( 994.8558593224009 );
    experiment->addDataPoint( data_point.getExperimentPoint( c44, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1168.925970055696 );
    data_point.addValue( 1152.305843765793 );
    data_point.addValue( 1163.3320257986136 );
    data_point.addValue( 1181.721114617381 );
    data_point.addValue( 1174.9194990604099 );
    experiment->addDataPoint( data_point.getExperimentPoint( c45, metric, callpath ), *metric, *callpath );
    data_point.clear();

    data_point.addValue( 1.0123953645414927 );
    data_point.addValue( 0.9808925858487914 );
    data_point.addValue( 0.9883957051154446 );
    data_point.addValue( 1.0097027886766448 );
    data_point.addValue( 1.0160649467948064 );
    experiment->addDataPoint( data_point.getExperimentPoint( c51, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 732.9718870349534 );
    data_point.addValue( 713.5887652750822 );
    data_point.addValue( 731.5598226968582 );
    data_point.addValue( 727.8160069274114 );
    data_point.addValue( 721.843240633473 );
    experiment->addDataPoint( data_point.getExperimentPoint( c52, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1139.5493742034544 );
    data_point.addValue( 1151.1355124340896 );
    data_point.addValue( 1136.4341443870837 );
    data_point.addValue( 1123.1009473444153 );
    data_point.addValue( 1139.5682409322808 );
    experiment->addDataPoint( data_point.getExperimentPoint( c53, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1461.1663792149404 );
    data_point.addValue( 1456.927809881706 );
    data_point.addValue( 1468.5789635626325 );
    data_point.addValue( 1425.7927730830347 );
    data_point.addValue( 1412.4260646792911 );
    experiment->addDataPoint( data_point.getExperimentPoint( c54, metric, callpath ), *metric, *callpath );
    data_point.clear();
    data_point.addValue( 1644.9469847409239 );
    data_point.addValue( 1687.8899020378108 );
    data_point.addValue( 1659.733621973487 );
    data_point.addValue( 1646.4234125252788 );
    data_point.addValue( 1641.8554614544396 );
    experiment->addDataPoint( data_point.getExperimentPoint( c55, metric, callpath ), *metric, *callpath );
    data_point.clear();

    //load experiment from openText()
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input2.txt" );

    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
}

void
testOpenJsonIntegrity( void )
{
    //create experiment object to check against
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();

    EXTRAP::Region* region = new EXTRAP::Region( "reg", EXTRAP_TEST_DIR "/data/input/json_test_input.txt", 1 );
    experiment->addRegion( region );

    EXTRAP::Callpath* callpath = new EXTRAP::Callpath( region, NULL );
    experiment->addCallpath( callpath );

    EXTRAP::Metric* metric = new EXTRAP::Metric( "metr", "unknown" );
    experiment->addMetric( metric );

    EXTRAP::Parameter parameter = EXTRAP::Parameter( "x" );
    experiment->addParameter( parameter );

    EXTRAP::Coordinate* c1 = new EXTRAP::Coordinate();
    c1->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 20 ) );
    experiment->addCoordinate( c1 );
    EXTRAP::Coordinate* c2 = new EXTRAP::Coordinate();
    c2->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 30 ) );
    experiment->addCoordinate( c2 );
    EXTRAP::Coordinate* c3 = new EXTRAP::Coordinate();
    c3->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 40 ) );
    experiment->addCoordinate( c3 );
    EXTRAP::Coordinate* c4 = new EXTRAP::Coordinate();
    c4->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 50 ) );
    experiment->addCoordinate( c4 );
    EXTRAP::Coordinate* c5 = new EXTRAP::Coordinate();
    c5->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( parameter, 60 ) );
    experiment->addCoordinate( c5 );

    EXTRAP::IncrementalPoint data_point1;
    data_point1.addValue( 82.00848518948744 );
    data_point1.addValue( 81.42023198759563 );
    data_point1.addValue( 81.98984501217201 );
    data_point1.addValue( 80.76019835580321 );
    data_point1.addValue( 82.54252892405795 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c1, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 184.5140079299443 );
    data_point1.addValue( 177.46069577925178 );
    data_point1.addValue( 179.12260901809867 );
    data_point1.addValue( 178.9221229310546 );
    data_point1.addValue( 177.93461023001083 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c2, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 315.26845992523744 );
    data_point1.addValue( 314.8769218843138 );
    data_point1.addValue( 315.7165660477195 );
    data_point1.addValue( 324.22329944880516 );
    data_point1.addValue( 323.2719163782126 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c3, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 509.81064352081336 );
    data_point1.addValue( 495.74457198852593 );
    data_point1.addValue( 501.0059487282256 );
    data_point1.addValue( 502.5272204028191 );
    data_point1.addValue( 509.6665018646357 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c4, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    data_point1.addValue( 725.3886983183301 );
    data_point1.addValue( 727.8628493044997 );
    data_point1.addValue( 727.0517005284136 );
    data_point1.addValue( 729.5284355624206 );
    data_point1.addValue( 721.0616186790007 );
    experiment->addDataPoint( data_point1.getExperimentPoint( c5, metric, callpath ), *metric, *callpath );
    data_point1.clear();

    //load experiment from openText()
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input.txt" );

    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
}

void
testOpenTextSingleParameter( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/input/input_data_1p.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenTextMultiParameter( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/input/input_data_2p.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenTextMultiParameter2( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/input/input_data_3p.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenJsonSingleParameter( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenJsonMultiParameter( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input2.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenJsonMultiParameter2( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input3.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenJsonMultiParameter3( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input4.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

void
testOpenJsonMultiParameter4( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openJsonInput( EXTRAP_TEST_DIR "/data/input/json_test_input5.txt" );
    assert( experiment != NULL );
    delete( experiment );
}

int
main()
{
    std::cout << "Starting input method tests..." << std::endl;


    std::cout << "\nTesting openTextInput() method." << std::endl;

    test( &testOpenTextSingleParameter );
    std::cout << "openTextInput() single parameter test successfull" << std::endl;

    test( &testOpenTextMultiParameter );
    std::cout << "openTextInput() multi (2) parameter test successfull" << std::endl;

    test( &testOpenTextMultiParameter2 );
    std::cout << "openTextInput() multi (3) parameter test successfull" << std::endl;

    test( &testOpenTextIntegrity );
    std::cout << "openTextInput() single parameter integrity test successfull" << std::endl;

    test( &testOpenTextIntegrityMultiParam );
    std::cout << "openTextInput() multi parameter integrity test successfull" << std::endl;

    std::cout << "openTextInput() method all tests successfull." << std::endl;


    std::cout << "\nTesting openJsonInput() method." << std::endl;

    test( &testOpenJsonSingleParameter );
    std::cout << "openJsonInput() single parameter test successfull" << std::endl;

    test( &testOpenJsonMultiParameter );
    std::cout << "openJsonInput() 2 parameter test successfull" << std::endl;

    //f(x,y,z) = x^3*y^2+z
    test( &testOpenJsonMultiParameter2 );
    std::cout << "openJsonInput() 3 parameter test successfull" << std::endl;

    test( &testOpenJsonMultiParameter3 );
    std::cout << "openJsonInput() 3 random parameter names test successfull" << std::endl;

    test( &testOpenJsonMultiParameter4 );
    std::cout << "openJsonInput() 3 random parameter names with random length test successfull" << std::endl;

    test( &testOpenJsonIntegrity );
    std::cout << "openJsonInput() single parameter integrity test successfull" << std::endl;

    test( &testOpenJsonIntegrityMultiParam );
    std::cout << "openJsonInput() multi parameter integrity test successfull" << std::endl;

    std::cout << "openJsonInput() method all tests successfull." << std::endl;


    std::cout << "\nAll input method tests successfull." << std::endl;
    return 0;
}
