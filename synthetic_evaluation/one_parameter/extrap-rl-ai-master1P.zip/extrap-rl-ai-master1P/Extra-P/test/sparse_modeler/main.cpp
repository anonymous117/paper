/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <EXTRAP_IoHelper.hpp>
#include <stdio.h>
#include <string.h>
#include <EXTRAP_MultiParameterSparseModelGenerator.hpp>
#include <EXTRAP_MultiParameterSparseFunctionModeler.hpp>
#include <EXTRAP_MultiParamFunctionGenerator.hpp>
#include <EXTRAP_MultiParameterSimpleModelGenerator.hpp>
#include <sstream>
#include <dirent.h>
#include <sys/stat.h>

int
main()
{
    //Modeler Options
    EXTRAP::ModelGeneratorOptions               options;
    options.setGenerateModelOptions( EXTRAP::GENERATE_MODEL_MEAN );
    options.setMinNumberPoints( 5 );
    options.setSinglePointsStrategy( EXTRAP::CHEAPEST_POINTS );
    options.setMultiPointsStrategy( EXTRAP::INCREASING_COST );
    options.setUseAddPoints( true );
    options.setNumberAddPoints( 1 );

    //Testfile Path
    std::string path = "/home/marcus/Desktop/test.txt";

    //Standard Modeler    
    EXTRAP::Experiment*                         standard_experiment       = EXTRAP::Experiment::openJsonInput( path );
    EXTRAP::MetricList                          standard_metrics          = standard_experiment->getMetrics();
    EXTRAP::CallpathList                        standard_callpaths        = standard_experiment->getAllCallpaths();
    const EXTRAP::ParameterList&                standard_parameterNames   = standard_experiment->getParameters();
    EXTRAP::ModelGenerator*                     standard_model_generator  = NULL;
    EXTRAP::MultiParameterSimpleModelGenerator* standard_mparam_generator = new EXTRAP::MultiParameterSimpleModelGenerator();
    standard_model_generator = standard_mparam_generator;
    standard_experiment->addModelGenerator( standard_model_generator );
    standard_experiment->modelAll( *standard_model_generator, standard_experiment, options );
    const EXTRAP::ModelList&        standard_model_list             = standard_experiment->getModels( *standard_metrics[ 0 ], *standard_callpaths[ 0 ] );
    EXTRAP::MultiParameterFunction* standard_function        = dynamic_cast<EXTRAP::MultiParameterFunction*>( standard_model_list[ 0 ]->getModelFunction() );
    std::string                     standard_function_string = standard_function->getAsString( standard_parameterNames );
    std::cout << "Normal Modeler Function: " << standard_function_string << "\n";

    //Sparse Modeler
    EXTRAP::ModelGenerator*                     sparse_model_generator = NULL;
    EXTRAP::MultiParameterSparseModelGenerator* sparse_modeler  = new EXTRAP::MultiParameterSparseModelGenerator();
    sparse_model_generator = sparse_modeler;
    EXTRAP::Experiment*          sparse_experiment     = EXTRAP::Experiment::openJsonInput( path );
    EXTRAP::MetricList           sparse_metrics        = sparse_experiment->getMetrics();
    EXTRAP::CallpathList         sparse_callpaths      = sparse_experiment->getAllCallpaths();
    const EXTRAP::ParameterList& parameterNames = sparse_experiment->getParameters();
    sparse_experiment->addModelGenerator( sparse_model_generator );
    sparse_experiment->modelAll( *sparse_model_generator, sparse_experiment, options );
    const EXTRAP::ModelList&        sparse_model_list      = sparse_experiment->getModels( *sparse_metrics[ 0 ], *sparse_callpaths[ 0 ] );
    EXTRAP::MultiParameterFunction* sparse_function        = dynamic_cast<EXTRAP::MultiParameterFunction*>( sparse_model_list[ 0 ]->getModelFunction() );
    std::string                     sparse_function_string = sparse_function->getAsString( parameterNames );
    std::cout << "Sparse Modeler Function: " << sparse_function_string << "\n";

    return 0;
}
