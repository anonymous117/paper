/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <H5Cpp.h>
#include <EXTRAP_Experiment.hpp>
#include <EXTRAP_CubeFileReader.hpp>
#include <cassert>
#include <EXTRAP_HDF5Reader.hpp>
#include <EXTRAP_Visitor.hpp>
#include <queue>

using namespace H5;
using namespace EXTRAP;
class CallpathToHDF5Visitor : public Visitor
{
public:
    CallpathToHDF5Visitor( H5File*     f,
                           Experiment* experiment );
    ~CallpathToHDF5Visitor();
    void
    visit( Callpath* cp );
    void
    writeParameterAndCoordinateAttributes( Group& group );

private:
    std::queue<Group*>                         m_groups;
    H5File*                                    m_file;
    DataSpace                                  m_dataspace_dataset;
    DataSpace                                  m_dataspace_parameters;
    DataSpace                                  m_dataspace_parameterValues;
    DataSpace                                  m_dataspace_region;
    hsize_t*                                   m_dimensions;
    Experiment*                                m_experiment;
    std::map<Parameter, std::map<Value, int> > m_parameterValueToIndex;
    void
    write_unit_attribute( Group&        group,
                          const Metric& metric );
    void
    write_region_attributes( Group&          group,
                             const Callpath& cp );
    void
    prepare_parameter_value_to_index();
    void
    prepare_data_space();
};

CallpathToHDF5Visitor::CallpathToHDF5Visitor( H5File* f, Experiment* experiment ) : m_file( f ), m_experiment( experiment )
{
};

CallpathToHDF5Visitor::~CallpathToHDF5Visitor()
{
    while ( !m_groups.empty() )
    {
        Group* g = m_groups.front();
        m_groups.pop();
        delete( g );
    }
    delete m_dimensions;
}

void
CallpathToHDF5Visitor::prepare_parameter_value_to_index()
{
    for ( int i = 0; i < this->m_experiment->getParameters().size(); i++ )
    {
        std::set<Value>           valuesForParam = this->m_experiment->getValuesForParameter( this->m_experiment->getParameters()[ i ] );
        std::map<Value, int>      valuesToIndex  = std::map<Value, int>();
        std::set<Value>::iterator it             = valuesForParam.begin();
        for ( int j = 0; j < valuesForParam.size(); j++ )
        {
            valuesToIndex.insert( std::pair<Value, int>( *it, j ) );
            it++;
        }
        this->m_parameterValueToIndex.insert( std::pair<Parameter, std::map<Value, int> >( m_experiment->getParameters()[ i ], valuesToIndex ) );
    }
}

void
CallpathToHDF5Visitor::prepare_data_space()
{
    const ParameterList params = this->m_experiment->getParameters();
    this->m_dimensions = new hsize_t[ params.size() ];
    for ( int i = 0; i < params.size(); i++ )
    {
        if ( this->m_parameterValueToIndex.find( params[ i ] ) != this->m_parameterValueToIndex.end() )
        {
            m_dimensions[ i ] = this->m_parameterValueToIndex.find( params[ i ] )->second.size();
            //TODO: push the values as annotation
        }
    }
    //End
    this->m_dataspace_dataset = DataSpace( params.size(), m_dimensions );
}

void
CallpathToHDF5Visitor::visit( Callpath* cp )
{
    //Basic Setup shared across all datasets
    this->prepare_parameter_value_to_index();
    this->prepare_data_space();
    const ParameterList                             params = m_experiment->getParameters();
    std::vector<Value>*                             data1D = NULL;
    std::vector<std::vector<Value> >*               data2D = NULL;
    std::vector<std::vector<std::vector<Value> > >* data3D = NULL;
    //Initialization of vectors
    if ( params.size() == 1 )
    {
        data1D = new std::vector<Value>();
        data1D->resize( m_dimensions[ 0 ] );
    }
    else if ( params.size() == 2 )
    {
        data2D = new std::vector<std::vector<Value> >();
        for ( int i = 0; i < m_dimensions[ 0 ]; i++ )
        {
            std::vector<Value> row;
            row.resize( m_dimensions[ 1 ] );
            data2D->push_back( row );
        }
    }
    else if ( params.size() == 3 )
    {
        data3D = new std::vector<std::vector<std::vector<Value> > >();
        for ( int i = 0; i < m_dimensions[ 0 ]; i++ )
        {
            std::vector<std::vector<Value> > row;
            for ( int j = 0; j < m_dimensions[ 1 ]; j++ )
            {
                std::vector<Value> row3D;
                row3D.resize( m_dimensions[ 2 ] );
                row.push_back( row3D );
            }
            data3D->push_back( row );
        }
    }
    else
    {
        ErrorStream << "Dimension must be between 1 and 3, given Dimension: " << params.size() << std::endl;
        exit( -1 );
    }
    //End Vector initialization
    //End basic Setup
    std::string groupName  = std::string( "/" ).append( cp->getFullName( "/" ) );
    Group*      this_group = new Group( m_file->createGroup( groupName ) );
    write_region_attributes( *this_group, *cp );
    m_groups.push( this_group );
    const MetricList metrics = this->m_experiment->getMetrics();
    //Store metrics as datasets
    for ( MetricList::const_iterator it = metrics.begin(); it != metrics.end(); it++ )
    {
        std::string metricGroupName = groupName;
        metricGroupName += std::string( "/" ).append( ( *it )->getName() );
        Group* metric_group = new Group( m_file->createGroup( metricGroupName ) );
        //Write Unit Attribute
        write_unit_attribute( *metric_group, *( *it ) );
        m_groups.push( metric_group );
        //create a new dataset, we use r1 as an indicator for the first repetition. as this is only an example no other repetitions are used.
        std::string datasetName = metricGroupName;
        datasetName += std::string( "/" ).append( "r1" );
        DataSet*                  dataset = new DataSet( this->m_file->createDataSet( datasetName, PredType::NATIVE_DOUBLE, this->m_dataspace_dataset ) );
        const ExperimentPointList points  = this->m_experiment->getPoints( *( *it ), *cp );
        for ( ExperimentPointList::const_iterator point = points.begin(); point != points.end(); point++ )
        {
            Coordinate c = ( *point )->getCoordinate();
            //Stores the indexes that this experiment point needs to be stored it E.g. X=2, Y=4, Z=1
            std::vector<int> indexes;
            //This loop determines the indizes for the experiment point in the dataset array
            for ( int i = 0; i < params.size(); i++ )
            {
                Parameter param = params[ i ];
                if ( c.find( param ) != c.end() )
                {
                    if ( m_parameterValueToIndex.find( param ) != m_parameterValueToIndex.end() )
                    {
                        std::map<Value, int> valuesToIndex = m_parameterValueToIndex.find( param )->second;
                        if ( valuesToIndex.find( c.find( param )->second ) != valuesToIndex.end() )
                        {
                            indexes.push_back( valuesToIndex.find( c.find( param )->second )->second );
                        }
                    }
                }
            }
            assert( indexes.size() == this->m_experiment->getParameters().size() );
            //Fill in data
            if ( params.size() == 1 )
            {
                ( *data1D )[ indexes[ 0 ] ] = ( *point )->getMean();
            }
            else if ( params.size() == 2 )
            {
                ( *data2D )[ indexes[ 0 ] ][ indexes[ 1 ] ] = ( *point )->getMean();
            }
            else if ( params.size() == 3 )
            {
                ( *data3D )[ indexes[ 0 ] ][ indexes[ 1 ] ][ indexes[ 2 ] ] = ( *point )->getMean();
            }
            else
            {
                ErrorStream << "Dimension must be between 1 and 3, given Dimension: " << params.size() << std::endl;
                exit( -1 );
            }
        }
        if ( params.size() == 1 )
        {
            dataset->write( data1D->data(), PredType::NATIVE_DOUBLE );
            //delete( data1D );
        }
        else if ( params.size() == 2 )
        {
            Value datasetarray[ m_dimensions[ 0 ] ][ m_dimensions[ 1 ] ];
            for ( int i = 0; i < data2D->size(); i++ )
            {
                for ( int j = 0; j < ( *data2D )[ 0 ].size(); j++ )
                {
                    datasetarray[ i ][ j ] = ( *data2D )[ i ][ j ];
                }
            }
            dataset->write( datasetarray, PredType::NATIVE_DOUBLE );
            //delete( data2D );
        }
        else if ( params.size() == 3 )
        {
            Value datasetarray[ m_dimensions[ 0 ] ][ m_dimensions[ 1 ] ][ m_dimensions[ 2 ] ];
            for ( int i = 0; i < data3D->size(); i++ )
            {
                for ( int j = 0; j < ( *data3D )[ 0 ].size(); j++ )
                {
                    for ( int k = 0; k < ( *data3D )[ 0 ][ 0 ].size(); k++ )
                    {
                        datasetarray[ i ][ j ][ k ] = ( *data3D )[ i ][ j ][ k ];
                    }
                }
            }
            dataset->write( datasetarray, PredType::NATIVE_DOUBLE );
            //delete( data3D );
        }
        else
        {
            ErrorStream << "Dimension must be between 1 and 3, given Dimension: " << params.size() << std::endl;
            exit( -1 );
        }
        delete( dataset );
    }
    //Traverse
    CallpathList children = cp->getChildren();
    for ( CallpathList::const_iterator it = children.begin(); it != children.end(); it++ )
    {
        ( *it )->accept( *this );
    }
}
void
CallpathToHDF5Visitor::write_unit_attribute( Group& group, const Metric& metric )
{
    hsize_t           dimension[ 1 ] = { 1 };
    const std::string writeBufferUnit( metric.getUnit() );
    Attribute         sourceAttr = group.createAttribute( HDF5Reader::H5_UNIT_ATTRIBUTE, HDF5Reader::H5_STR_TYPE, DataSpace( 1, dimension ) );
    sourceAttr.write( HDF5Reader::H5_STR_TYPE, writeBufferUnit );
    return;
}

void
CallpathToHDF5Visitor::write_region_attributes( Group& group, const Callpath& cp )
{
    hsize_t           dimension[ 1 ] = { 1 };
    const std::string writeBufferSourceFile( cp.getRegion()->getSourceFileName() );
    Attribute         sourceAttr = group.createAttribute( HDF5Reader::H5_SOURCE_ATTRIBUTE, HDF5Reader::H5_STR_TYPE, DataSpace( 1, dimension ) );
    sourceAttr.write( HDF5Reader::H5_STR_TYPE, writeBufferSourceFile );
    Attribute sourceLine = group.createAttribute( HDF5Reader::H5_SOURCELINE_ATTRIBUTE, PredType::NATIVE_INT64, DataSpace( 1, dimension ) );
    int       line       = cp.getRegion()->getSourceFileBeginLine();
    sourceLine.write( PredType::NATIVE_INT64, &line );
}

void
CallpathToHDF5Visitor::writeParameterAndCoordinateAttributes( Group& group )
{
    std::vector<std::string> paramNames;
    std::vector<const char*> paramNamesChar;
    ParameterList            params = this->m_experiment->getParameters();
    //Setup for param names
    hsize_t   dims[ 1 ]          = { params.size() };
    DataSpace parameterDataSpace = DataSpace( 1, dims );
    Attribute paramAttribute( group.createAttribute( HDF5Reader::H5_PARAMETER_ATTRIBUTE, HDF5Reader::H5_STR_TYPE, parameterDataSpace ) );
    //Setup for paramValues

    std::vector<std::vector<Value> >paramValues;
    for ( int i = 0; i < params.size(); i++ )
    {
        paramNames.push_back( params[ i ].getName() );
        std::set<Value>    values = this->m_experiment->getValuesForParameter( params[ i ] );
        std::vector<Value> valuesVector;
        for ( std::set<Value>::const_iterator val = values.begin(); val != values.end(); val++ )
        {
            valuesVector.push_back( *val );
        }
        paramValues.push_back( valuesVector );
    }
    for ( std::vector<std::string>::const_iterator it2 = paramNames.begin(); it2 != paramNames.end(); it2++ )
    {
        paramNamesChar.push_back( it2->c_str() );
    }
    //write out attributes
    paramAttribute.write( HDF5Reader::H5_STR_TYPE, paramNamesChar.data() );
    //do this iterating
    for ( int i = 0; i < params.size(); i++ )
    {
        hsize_t   dimsValues[ 1 ] = { paramValues[ i ].size() };
        DataSpace valuesDataSpace = DataSpace( 1, dimsValues );
        Attribute valuesAttribute( group.createAttribute( params[ i ].getName(), PredType::NATIVE_DOUBLE, valuesDataSpace ) );
        valuesAttribute.write( PredType::NATIVE_DOUBLE, paramValues[ i ].data() );
    }
}

Experiment*
readHDF5File( std::string& filename )
{
    HDF5Reader reader = HDF5Reader( filename );
    return reader.read();
}

void
createHDF5FileFromExperiment( Experiment* experiment, std::string& filename )
{
    H5File*      f         = new H5File( filename, H5F_ACC_TRUNC );
    Group        rootGroup = Group( f->openGroup( "/" ) );
    CallpathList callpaths = experiment->getAllCallpaths();
    //Find Root
    Callpath* root;
    for ( CallpathList::const_iterator it = callpaths.begin(); it != callpaths.end(); it++ )
    {
        if ( ( *it )->getParent() != NULL )
        {
            continue;
        }
        else
        {
            root = ( *it );
        }
    }
    CallpathToHDF5Visitor visitor = CallpathToHDF5Visitor( f, experiment );
    visitor.writeParameterAndCoordinateAttributes( rootGroup );
    root->accept( visitor );
    f->close();
    delete( f );
}

void
testOneDim()
{
    std::vector<int> values;
    values.push_back( 1 );
    values.push_back( 10 );
    values.push_back( 25 );
    Parameter       parX = EXTRAP::Parameter( "p" );
    CubeFileReader* cfr  = new EXTRAP::CubeFileReader();
    cfr->prepareCubeFileReader( 1, EXTRAP_TEST_DIR "/data", "mm.", "y1z1", "profile.cubex", 1 );
    cfr->addParameter( parX, "x", values );
    Experiment* experiment = cfr->readCubeFiles( 1 );
    std::cout << "Read onedimensional experiment" << std::endl;
    std::string filename = "test.h5";
    createHDF5FileFromExperiment( experiment, filename );
    std::cout << "Created HDF5 File from experiment" << std::endl;
    Experiment* experiment2 = readHDF5File( filename );
    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
    delete( cfr );
}

void
testTwoDim()
{
    std::vector<int> values;
    values.push_back( 1 );
    values.push_back( 10 );
    values.push_back( 25 );
    Parameter       parX = EXTRAP::Parameter( "p" );
    Parameter       parY = EXTRAP::Parameter( "size" );
    CubeFileReader* cfr  = new EXTRAP::CubeFileReader();
    cfr->prepareCubeFileReader( 1, EXTRAP_TEST_DIR "/data", "mm.", "z1", "profile.cubex", 1 );
    cfr->addParameter( parX, "x", values );
    cfr->addParameter( parY, "y", values );
    Experiment* experiment = cfr->readCubeFiles( 2 );
    std::cout << "Read twodimensional experiment" << std::endl;
    std::string filename = "test.h5";
    createHDF5FileFromExperiment( experiment, filename );
    std::cout << "Created HDF5 File from experiment" << std::endl;
    Experiment* experiment2 = readHDF5File( filename );
    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
    delete( cfr );
}

void
testThreeDim()
{
    std::vector<int> values;
    values.push_back( 1 );
    values.push_back( 10 );
    values.push_back( 25 );
    Parameter       parX = EXTRAP::Parameter( "p" );
    Parameter       parY = EXTRAP::Parameter( "size" );
    Parameter       parZ = EXTRAP::Parameter( "z" );
    CubeFileReader* cfr  = new EXTRAP::CubeFileReader();
    cfr->prepareCubeFileReader( 1, EXTRAP_TEST_DIR "/data", "mm.", "", "profile.cubex", 1 );
    cfr->addParameter( parX, "x", values );
    cfr->addParameter( parY, "y", values );
    cfr->addParameter( parZ, "z", values );
    Experiment* experiment = cfr->readCubeFiles( 3 );
    std::cout << "Read threedimensional experiment" << std::endl;
    std::string filename = "test.h5";
    createHDF5FileFromExperiment( experiment, filename );
    std::cout << "Created HDF5 File from experiment" << std::endl;
    Experiment* experiment2 = readHDF5File( filename );
    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
    delete( cfr );
}

int
main()
{
    std::cout << "Started HDF5 Test" << std::endl;
    testOneDim();
    std::cout << "HDF5 Test for one dimension successfull" << std::endl;
    testTwoDim();
    std::cout << "HDF5 Test for two dimensions successfull" << std::endl;
    testThreeDim();
    std::cout << "HDF5 Test for three dimensions successfull" << std::endl;
    return 0;
}
