# EXTRAP Modeler

Command Line Tool for Extra-P (<http://www.scalasca.org/software/extra-p/download.html>)

## Usage & Examples

For usage & examples see `documentation.md`

generate documentation with [pandoc](http://pandoc.org).

`pandoc documentation.md metadata.yaml -s -o documentation.pdf`


## Dependencies

* docopt (command line parsing <https://github.com/docopt/docopt>)
* Extra-P (<http://www.scalasca.org/software/extra-p/download.html>)
