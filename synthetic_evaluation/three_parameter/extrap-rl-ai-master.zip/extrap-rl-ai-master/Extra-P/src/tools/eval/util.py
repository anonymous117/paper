##/*
## * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
## *
## * Copyright (c) 2018,
## * Technische Universitaet Darmstadt, Germany
## *
## * This software may be modified and distributed under the terms of
## * a BSD-style license.  See the COPYING file in the package base
## * directory for details.
## *
## */


import sys
import os


class BaselineFunction():

    def __init__(self, function, function_string):
        self.function = function
        self.function_string = function_string
    
    def getFunction(self):
        return self.function

    def getFunctionString(self):
        return self.function_string


class ModelerResult():
    
    def __init__(self, function, function_string, rss, smape, ar2):
        self.function = function    #ExtraP MultiParameterFunction
        self.function_string = function_string
        self.rss = rss
        self.smape = smape
        self.ar2 = ar2
    
    def getFunction(self):
        return self.function

    def getFunctionString(self):
        return self.function_string
    
    def getRSS(self):
        return self.rss
    
    def getSMAPE(self):
        return self.smape

    def getAR2(self):
        return self.ar2


class InputFile():

    def __init__(self, parameters, metric, measurement_points, measurements):
        self.parameters = parameters
        self.metric = metric
        self.measurement_points = measurement_points
        self.measurements = measurements

    def getParameters(self):
        return self.parameters
    
    def getMetric(self):
        return self.metric

    def getMeasurementPoints(self):
        return self.measurement_points

    def getMeasurements(self):
        return self.measurements

    def writeToFile(self, path):
        file = open(path, "a+")

        for i in range(len(self.measurements)):
            measurement = self.measurements[i]
            measurement_point = measurement.getMeasurementPoint()
            parameter_values = measurement_point.getValues()
            value = measurement.getValue()
            value_string = str(value)
            metric = measurement.getMetric()
            metric_string = metric.getValue()

            line = "{\"params\":{"

            for j in range(len(self.parameters)):
                parameter = self.parameters[j]
                parameter_string = parameter.getValue()
                line = line + "\"" + parameter_string + "\":" + str(parameter_values[j]) + ","

            line = line[:-1]
            line = line + "},\"metric\":\"" + metric_string + "\",\"value\":" + value_string + "}\n"

            file.write(line)

    
class Parameter():

    def __init__(self, value):
        self.value = value

    def getValue(self):
        return self.value


class Metric():

    def __init__(self, value):
        self.value = value

    def getValue(self):
        return self.value


class MeasurementPoint():

    def __init__(self, parameters, values):
        self.parameters = parameters
        self.values = values

    def getParameters(self):
        return self.parameters

    def getValues(self):
        return self.values


class Measurement():

    def __init__(self, measurement_point, value, metric):
        self.measurement_point = measurement_point
        self.value = value
        self.metric = metric
    
    def getValue(self):
        return self.value
    
    def getMeasurementPoint(self):
        return self.measurement_point

    def getMetric(self):
        return self.metric