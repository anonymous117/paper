from extrap.Coordinate import Coordinate
from extrap.DataPoint import DataPoint
from extrap.DataSet import DataSet
from extrap.Function import Function
from extrap.Parameter import Parameter
import numpy as np

class DataSetGenerator():

    def __init__(self, repetitions, noise, epsilon, params, parameter_values):
        self.repetitions = repetitions
        self.noise = noise
        self.epsilon = epsilon
        self.params = params
        self.parameters = self.init_parameter()
        self.parameter_values = parameter_values

    def init_parameter(self):
        temp = []
        for i in range(len(self.params)):
            temp.append(Parameter(self.params[i]))
        return temp
    
    def calculate_measurement(self, function, coordinate):
        if len(self.parameter_values)==3:
            return function.evaluate(coordinate.get_value(0), coordinate.get_value(1), coordinate.get_value(2))
        else:
            return function.evaluate(coordinate.get_value(0), coordinate.get_value(1), 0)
    
    def create_measurement_repetitions(self, measurement):        
        measurements = []
        for _ in range(self.repetitions):
            measurements.append(measurement)
        return measurements
    
    def add_noise(self, measurements):
        mean = 0
        sigma = 0
        for i in range(self.repetitions):
            value = measurements[i]
            sigma = (value * (self.noise/100))/2
            noise_value = np.random.normal(mean, sigma, 1)
            value = value + noise_value
            value = value[0]
            measurements[i] = value
        return measurements
    
    def calculate_mean(self, measurements):
        mean = 0
        for i in range(self.repetitions):
            mean = mean + measurements[i]
        return mean/self.repetitions
        
    def create_data_point(self, coordinate, measurement):
        return DataPoint(coordinate, measurement)
    
    def generate_data_points(self, coordinates, function):
        data_points = []
        for i in range(len(coordinates)):
            measurement = self.calculate_measurement(function, coordinates[i])
            measurements = self.create_measurement_repetitions(measurement)
            measurements = self.add_noise(measurements)
            measurement = self.calculate_mean(measurements)
            data_point = self.create_data_point(coordinates[i], measurement)
            data_points.append(data_point)
        return data_points
    
    def generate_data_set(self):
        function = Function(self.epsilon, self.parameter_values)
        coordinates = []
        if len(self.parameter_values)==2:
            p1v = self.parameter_values[0]
            p2v = self.parameter_values[1]
            for i in range(len(p1v)):
                for j in range(len(p2v)):
                    values = []
                    values.append(p1v[i])
                    values.append(p2v[j])
                    coordinates.append(Coordinate(self.parameters, values))
        elif len(self.parameter_values)==3:
            p1v = self.parameter_values[0]
            p2v = self.parameter_values[1]
            p3v = self.parameter_values[2]
            for i in range(len(p1v)):
                for j in range(len(p2v)):
                    for z in range(len(p3v)):
                        values = []
                        values.append(p1v[i])
                        values.append(p2v[j])
                        values.append(p3v[z])
                        coordinates.append(Coordinate(self.parameters, values))
        data_points = self.generate_data_points(coordinates, function)
        data_set = DataSet(function, self.parameters, coordinates, data_points)
        return data_set