class Parameter():
    
    def __init__(self, name):
        self.name = name
    
    def get_name(self):
        return self.name
    
    def out(self):
        print(self.name)