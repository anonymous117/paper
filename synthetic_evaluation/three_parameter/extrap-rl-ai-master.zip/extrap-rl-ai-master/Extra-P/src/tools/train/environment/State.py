class State():

    def __init__(self, selected_points):
        # selected measurement points in the n-dimensional search space with history
        # each [] of selected_points represents a state at a point in time t
        # [0] is the current state, [1] is t-1 and so on...
        self.selected_points = selected_points
        self.observation = []
        for i in range(len(self.selected_points)):
            for j in range(len(self.selected_points[i])):
                self.observation.append(self.selected_points[i][j])

    def update(self, selected_points):
        '''
        Update the State
        '''
        self.selected_points = selected_points
        self.observation.clear()
        self.observation = []
        for i in range(len(self.selected_points)):
            for j in range(len(self.selected_points[i])):
                self.observation.append(self.selected_points[i][j])

    def get_observation(self):
        '''
        Return the current state as observation vector
        '''
        return self.observation
