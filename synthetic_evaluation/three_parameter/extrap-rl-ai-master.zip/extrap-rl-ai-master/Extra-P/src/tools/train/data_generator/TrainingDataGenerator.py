import random
from extrap.DataSetGenerator import DataSetGenerator

class TrainingDataGenerator():
    
    def __init__(self, use_seed=False, seed=0, noise=0, epsilon=1, repetitions=5, parameters=["p","size"], parameter_values=[[4,8,16,32,64],[10,20,30,40,50]]):
        self.repetitions = repetitions
        self.noise = noise
        self.seed = seed
        self.use_seed = use_seed
        self.epsilon = epsilon
        if self.use_seed == True:
            random.seed(self.seed)
        self.parameters = parameters
        self.parameter_values = parameter_values
        self.data_set_generator = DataSetGenerator(self.repetitions, self.noise, self.epsilon, self.parameters, self.parameter_values)
        
    def set_use_random_seed(self, use_seed):
        self.use_seed = use_seed
        self.update_seed()
        
    def set_random_seed(self, seed):
        self.seed = seed
        
    def update_seed(self):
        if self.use_seed == True:
            random.seed(self.seed)

    def create_training_data_set(self, size):
        training_data = []
        for _ in range(size):
            training_data.append(self.data_set_generator.generate_data_set())
        return training_data