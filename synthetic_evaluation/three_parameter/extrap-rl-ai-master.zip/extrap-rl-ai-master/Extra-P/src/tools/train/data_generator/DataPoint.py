class DataPoint():
   
    def __init__(self, coordinate, value):
        self.coordinate = coordinate
        self.value = value
        
    def get_coordinate(self):
        return self.coordinate
    
    def get_value(self):
        return self.value