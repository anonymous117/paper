import EXTRAP
import os
import shutil
import copy
from math import *
from extrap.State import State

class Environment():

    def __init__(self, data_set, n_actions, debug, parameter_values):
        # input data
        self.data_set = data_set
        self.baseline_function = data_set.get_function()
        self.parameters = data_set.get_parameters()
        self.coordinates = data_set.get_coordinates()
        self.data_points = data_set.get_data_points()

        # action space
        self.n_actions = n_actions
        self.parameter_values = parameter_values
        self.p_values = []
        self.size_values = []
        self.n_values = []
        self.init_action_space()

        # state space
        self.history = 8
        self.n_points = n_actions
        self.measurements = self.init_measurements()
        self.predictions = self.init_predictions()
        self.selected_points = self.init_selected_points()

        # number of the current step in the episode
        self.step_number = 0

        # selected point costs in percent relative to the maximum cost
        self.cost = 0

        # state
        self.state = State(self.selected_points)

        # episode finished
        self.done = False

        # reward given to the agent
        self.reward = 0

        # number selected points
        self.n_selected_points = 0

        # mean percentage error over all measurements
        self.mpe = 100

        # function estimated by the modeler
        self.modeler_function = ""

        # flag for checking if the baseline and modeler function are identical
        self.check_terms = False

        # maximum allowed % error for model to temrinate the episode, depends on the noise level
        self.max_mpe = 1

        # minimum number of points per parameter for the sparse modeler
        self.min_points_per_parameter = 5

        # info regarding the epsiode
        self.info = None

        # debug flag to print the step information
        self.debug = debug

    def init_action_space(self):
        '''
        Initializes the action spaceselected_points
        '''
        if len(self.parameter_values)==2:
            for i in range(len(self.parameter_values[0])):
                self.p_values.append(self.parameter_values[0][i])
            for i in range(len(self.parameter_values[1])):
                self.size_values.append(self.parameter_values[1][i])
        elif len(self.parameter_values)==3:
            for i in range(len(self.parameter_values[0])):
                self.p_values.append(self.parameter_values[0][i])
            for i in range(len(self.parameter_values[1])):
                self.size_values.append(self.parameter_values[1][i])
            for i in range(len(self.parameter_values[2])):
                self.n_values.append(self.parameter_values[2][i])

    def step(self, action):
        '''
        update selected points and search space history
        '''
        self.selected_points[7] = copy.deepcopy(self.selected_points[6])
        self.selected_points[6] = copy.deepcopy(self.selected_points[5])
        self.selected_points[5] = copy.deepcopy(self.selected_points[4])
        self.selected_points[4] = copy.deepcopy(self.selected_points[3])
        self.selected_points[3] = copy.deepcopy(self.selected_points[2])
        self.selected_points[2] = copy.deepcopy(self.selected_points[1])
        self.selected_points[1] = copy.deepcopy(self.selected_points[0])
        self.selected_points[0][action] = 1
        self.n_selected_points += 1

        '''
        update selected point costs
        '''
        self.cost = self.calc_selected_point_cost()

        '''
        update modeler function
        '''
        # check if there are enough points available to start modeling
        enough_points, points_x, points_y = self.analyze_selected_points()

        if enough_points == True:
            # create the experiment from the environment data
            experiment = self.create_experiment()
            extra_points = self.analyze_extra_points(points_x, points_y)
            # model the function
            function = self.run_sparse_modeler(experiment, extra_points)
            self.modeler_function = self.parse_function(function)
            # calculate the mpe over all points
            self.mpe = self.calculate_mpe()
            # check terms from now on
            self.check_terms = True

        '''
        update state
        '''
        self.step_number += 1
        self.state.update(self.selected_points)
        S_ = copy.deepcopy(self.state)

        '''
        terminate episode?
        '''
        # terminate when all points have been selected
        if self.n_selected_points == self.n_points:
            self.done = True
        # terminate when the function is correct (or n-terms)
        if self.check_terms == True:
            if self.analyze_function_terms() == True:
                self.done = True

        '''
        update reward
        '''
        if self.done == True:
            # reward for used budget
            self.reward = self.calc_reward_cost()
            # in case model is incorrect
            if self.check_terms == True:
                if self.analyze_function_terms() == False:
                    self.reward = 0

        '''
        print step info
        '''
        if self.debug == True:
            print("Step: "+str(self.step_number))
            print("Number selected points: "+str(self.n_selected_points))
            print("Selected points: "+str(self.selected_points))
            print("MPE: "+str(self.mpe))
            print("Baseline function: "+str(self.baseline_function.get_function()))
            print("Modeler function: "+str(self.modeler_function))
            print("Action performed: "+str(action))
            print("Measurements: "+str(self.measurements))
            print("Predictions: "+str(self.predictions))
            #print("Observation: "+str(self.state.get_observation()))
            print("\n")

        return S_, self.reward, self.done

    def init_measurements(self):
        '''
        Initialize the measurements vector from the data_points
        '''
        measurements = []
        for i in range(len(self.data_points)):
            measurements.append(self.data_points[i].get_value())
        return measurements

    def init_predictions(self):
        '''
        Initialize the predictions vector
        '''
        predictions = []
        for _ in range(self.n_points):
            predictions.append(0)
        return predictions

    def init_selected_points(self):
        '''
        Initialize the selected points vector
        '''
        selected_points = []
        for _ in range(self.history):
            tmp = []
            for _ in range(self.n_points):
                tmp.append(0)
            selected_points.append(tmp)
        return selected_points

    def get_state(self):
        '''
        Return the current state of the environment
        '''
        S = copy.deepcopy(self.state)
        return S

    def analyze_selected_points(self):
        '''
        Analyzed the selected points and decides if they satisfy the requirements to run the sparse modeler
        '''
        points_x = []
        points_y = []

        selected_data_points = []
        for i in range(len(self.selected_points[0])):
            if self.selected_points[0][i] == 1:
                selected_data_points.append(self.data_points[i])

        # search for point row for parameter p
        p_list_exists = False
        for i in range(len(selected_data_points)):
            cord = selected_data_points[i].get_coordinate()
            p_value = cord.get_value(0)
            point_row = []
            point_row.append(selected_data_points[i])
            # search for similar points with same p and different size
            for j in range(len(selected_data_points)):
                cord2 = selected_data_points[j].get_coordinate()
                p_value2 = cord2.get_value(0)
                size_value = cord2.get_value(1)
                if p_value2 == p_value:
                    # check if this point is already in the list
                    in_list = False
                    for z in range(len(point_row)):
                        cord3 = point_row[z].get_coordinate()
                        size_value2 = cord3.get_value(1)
                        if size_value2 == size_value:
                            in_list = True
                            break
                    if in_list == False and len(point_row) < self.min_points_per_parameter:
                        point_row.append(selected_data_points[j])
            if len(point_row) >= self.min_points_per_parameter:
                p_list_exists = True
                points_x = point_row
                break

        # search for point row for parameter size
        size_list_exists = False
        for i in range(len(selected_data_points)):
            cord = selected_data_points[i].get_coordinate()
            size_value = cord.get_value(1)
            point_row = []
            point_row.append(selected_data_points[i])
            # search for similar points with same p and different size
            for j in range(len(selected_data_points)):
                cord2 = selected_data_points[j].get_coordinate()
                size_value2 = cord2.get_value(1)
                p_value = cord2.get_value(0)
                if size_value2 == size_value:
                    # check if this point is already in the list
                    in_list = False
                    for z in range(len(point_row)):
                        cord3 = point_row[z].get_coordinate()
                        p_value2 = cord3.get_value(0)
                        if p_value == p_value2:
                            in_list = True
                            break
                    if in_list == False and len(point_row) < self.min_points_per_parameter:
                        point_row.append(selected_data_points[j])
            if len(point_row) >= self.min_points_per_parameter:
                size_list_exists = True
                points_y = point_row
                break

        if p_list_exists == True and size_list_exists == True:
            return True, points_x, points_y
        else:
            return False, points_x, points_y

    def create_experiment(self):
        '''
        Create an extrap experiment from the python data objects
        '''
        if os.path.exists("tmp/"):
            shutil.rmtree("tmp/")
        os.mkdir("tmp/")
        input_file = open("tmp/input.txt", "w")
        for i in range(len(self.coordinates)):
            p_value = self.coordinates[i].get_value(0)
            size_value = self.coordinates[i].get_value(1)
            value = self.measurements[i]
            output = "{\"params\":{\"p\":" + str(p_value) + "," + "\"size\":" + str(size_value) + "},\"metric\":\"" + "metr" + "\",\"value\":" + str(value) + "}\n"
            if self.selected_points[0][i] == 1:
                input_file.write(output)
        input_file.close()
        experiment = EXTRAP.Experiment.openJsonInput( "tmp/input.txt" )
        return experiment

    def run_sparse_modeler(self, experiment, additional_points):
        '''
        Executes the sparse modeler based on the created experiment and produces an estimated function
        '''
        sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
        model_generator = sparse_modeler
        model_generator.thisown = False
        generate_option   = EXTRAP.GENERATE_MODEL_MEAN
        single_option     = EXTRAP.CHEAPEST_POINTS
        multi_option      = EXTRAP.INCREASING_COST
        min_number_points = 5
        options = EXTRAP.ModelGeneratorOptions()
        options.setGenerateModelOptions( generate_option )
        options.setMinNumberPoints( min_number_points )
        options.setSinglePointsStrategy( single_option )
        options.setMultiPointsStrategy( multi_option )
        if additional_points == 0:
            options.setUseAddPoints( False )
            options.setNumberAddPoints( 0 )
        else:
            options.setUseAddPoints( True )
            options.setNumberAddPoints( additional_points )
            #print("number extra points: "+str(additional_points))
        metrics        = experiment.getMetrics()
        callpaths      = experiment.getAllCallpaths()
        metric = metrics[0]
        call_path = callpaths[0]
        experiment.addModelGenerator( model_generator )
        experiment.modelAll( model_generator, experiment, options )
        models = experiment.getModels(metric, call_path)
        model = models[0]
        sparse_function = model.getModelFunction()
        sparse_function_string = sparse_function.getAsString(experiment.getParameters())
        return sparse_function_string

    def analyze_extra_points(self, points_x, points_y):
        '''
        Analyzes the extra points available for modeling
        '''
        base_points = []

        for i in range(len(points_x)):
            if len(base_points)==0:
                base_points.append(points_x[i])
            else:
                p1 = points_x[i].get_coordinate().get_value(0)
                size1 = points_x[i].get_coordinate().get_value(1)
                in_list = False
                for j in range(len(base_points)):
                    p2 = base_points[j].get_coordinate().get_value(0)
                    size2 = base_points[j].get_coordinate().get_value(1)
                    if p1==p2 and size1==size2:
                        in_list = True
                        break
                if in_list==False:
                    base_points.append(points_x[i])

        for i in range(len(points_y)):
            if len(base_points)==0:
                base_points.append(points_y[i])
            else:
                p1 = points_y[i].get_coordinate().get_value(0)
                size1 = points_y[i].get_coordinate().get_value(1)
                in_list = False
                for j in range(len(base_points)):
                    p2 = base_points[j].get_coordinate().get_value(0)
                    size2 = base_points[j].get_coordinate().get_value(1)
                    if p1==p2 and size1==size2:
                        in_list = True
                        break
                if in_list==False:
                    base_points.append(points_y[i])

        all_points = 0
        for i in range(len(self.selected_points[0])):
            if self.selected_points[0][i] == 1:
                all_points = all_points + 1

        extra_points = all_points - len(base_points)
        return extra_points

    def parse_function(self, function):
        '''
        Parses the extrap to a python interpretable function
        '''
        # remove leading + for the first coefficient
        if function[0] == ' ':
            function = function[1:]
        if function[0] == '+':
            function = function[1:]
        if function[0] == ' ':
            function = function[1:]
        # replace power operator ^ with **
        while True:
            id = 0
            complete = True
            for i in range(0,len(function)):
                if function[i] == '^':
                    id = i
                    complete = False
                    break
            if complete == True:
                break
            temp = function[:id]
            temp2 = function[id+2:]
            exponent = function[id+1]
            temp2 = '**' + exponent + temp2
            function = temp + temp2
        # replace log operator log2(x) with log(x,2)
        while True:
            id = function.find('log2')
            if id == -1:
                break
            else:
                temp = function[:id]
                temp2 = function[id+4:]
                bracket1 = temp2.find('(')
                bracket2 = temp2.find(')')
                parameter = temp2
                parameter = parameter[bracket1+1:]
                idd = parameter.find(')')
                parameter = parameter[:idd]
                temp3 = temp2[:bracket1]
                temp4 = temp2[bracket2+1:]
                temp2 = temp3 + temp4
                function = temp + 'log(' + parameter + ',2)' + temp2
        return function

    def calculate_mpe(self):
        '''
        Calculates the mpe over all points
        '''
        predictions = []
        mpe = 0
        sum_relative_error = 0
        if len(self.parameter_values) == 2:
            for i in range(len(self.p_values)):
                for j in range(len(self.size_values)):
                    p = self.p_values[i]
                    size = self.size_values[j]
                    n = 0
                    result_baseline = self.baseline_function.evaluate(p, size, n)
                    result_modeler = eval(self.modeler_function)
                    # to update predictions vector later
                    predictions.append(result_modeler)
                    absolute_error = abs(result_modeler - result_baseline)
                    relative_error = absolute_error / result_baseline
                    sum_relative_error = sum_relative_error + relative_error
        elif len(self.parameter_values) == 3:
            for i in range(len(self.p_values)):
                for j in range(len(self.size_values)):
                    for z in range(len(self.n_values)):
                        p = self.p_values[i]
                        size = self.size_values[j]
                        n = self.n_values[z]
                        result_baseline = self.baseline_function.evaluate(p, size, n)
                        result_modeler = eval(self.modeler_function)
                        # to update predictions vector later
                        predictions.append(result_modeler)
                        absolute_error = abs(result_modeler - result_baseline)
                        relative_error = absolute_error / result_baseline
                        sum_relative_error = sum_relative_error + relative_error
        # update predictions
        for i in range(len(predictions)):
            self.predictions[i] = predictions[i]
        if sum_relative_error!=0:
            mpe = sum_relative_error / len(self.predictions)
            mpe = mpe * 100
        else:
            mpe = 0
        return mpe

    def validate_action(self, action):
        '''
        Checks if the given action is valid to be performed in the current state
        '''
        if self.selected_points[0][action] == 0:
            return True
        else:
            return False

    def get_number_selected_points(self):
        '''
        Returns the number of points selected during the modeling process
        '''
        return self.n_selected_points

    def get_mpe(self):
        '''
        Returns the mpe after the episode finished
        '''
        return self.mpe

    def get_selected_points(self):
        '''
        Returns the selected points after the episode finished
        '''
        return self.selected_points

    def get_step_number(self):
        '''
        Returns the current number of steps, actions taken in the environment
        '''
        return self.step_number

    def calc_selected_point_cost(self):
        '''
        Calculates the cost of the measurement points slected by the agent
        in percent relative to the maximum cost (all points selected)
        '''
        costs = []
        tmp_p = []
        for i in range(len(self.p_values)):
            for _ in range(len(self.size_values)):
                tmp_p.append(self.p_values[i])
        for i in range(len(self.measurements)):
            p = tmp_p[i]
            time = self.measurements[i]
            point_cost = p * time
            costs.append(point_cost)
        total_cost = 0
        for i in range(len(costs)):
            total_cost += costs[i]
        selected_cost = 0
        for i in range(len(costs)):
            if self.selected_points[0][i] == 1:
                selected_cost += costs[i]
        one_percent = total_cost / 100
        percent = selected_cost / one_percent
        # necessary for the network, as it works better with values between 0-1
        percent = percent / 100
        return percent

    def calc_reward_cost(self):
        '''
        Calculates the reward for the costs
        '''
        reward = -self.cost + 1
        if reward < 0:
            reward = 0
        return reward

    def check_for_parameters(self, function_term):
        '''
        Checks if a function has at least 2 parameters
        '''
        pos1 = function_term.find("p")
        pos2 = function_term.find("size")
        #in this case there is no parameter in the term
        if pos1==-1 and pos2==-1:
            return False
        else:
            return True

    def parse_terms(self, functions_terms):
        '''
        Parses all terms of a function and returns them in a vector
        '''
        terms = functions_terms
        for j in range(len(terms)):
            terms[j] = terms[j].replace(" ", "")
        terms_copy = []
        for j in range(len(terms)):
            has_parameter = self.check_for_parameters(terms[j])
            if has_parameter==True:
                terms_copy.append(terms[j])
        for j in range(len(terms_copy)):
            temp = terms_copy[j]
            pos = temp.find("*")
            temp = temp[pos+1:]
            terms_copy[j] = temp
        return terms_copy

    def search_term(self, base_terms, term):
        '''
        Checks if a specific term is existing in a list of terms
        '''
        is_existing = False
        for i in range(len(base_terms)):
            if base_terms[i] == term:
                is_existing = True
                break
        return is_existing

    def analyze_function_terms(self):
        '''
        Analyzes the basline and modeler function and returns true if both are identical
        '''
        baseline_function = self.parse_function(self.baseline_function.get_function())
        modeler_function = self.modeler_function
        baseline_function_terms = baseline_function.split("+")
        modeler_function_terms = modeler_function.split("+")
        baseline_function_terms = self.parse_terms(baseline_function_terms)
        modeler_function_terms = self.parse_terms(modeler_function_terms)

        correct_terms = 0
        for i in range(len(modeler_function_terms)):
            string_term = modeler_function_terms[i]
            is_existing = self.search_term(baseline_function_terms, string_term)
            if is_existing == True:
                correct_terms += 1

        # check if function is identical
        if len(baseline_function_terms) == correct_terms:
            return True
        else:
            return False

    def get_cost(self):
        '''
        Returns the current cost of the selected points
        '''
        return self.cost
