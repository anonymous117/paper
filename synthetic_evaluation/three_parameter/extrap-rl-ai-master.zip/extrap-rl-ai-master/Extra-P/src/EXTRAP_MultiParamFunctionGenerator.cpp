/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_MultiParameterFunction.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_MultiParamFunctionGenerator.hpp>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <iostream>

namespace EXTRAP
{
MultiParamFunctionGenerator::MultiParamFunctionGenerator( const FunctionCategory       functionCat,
                                                          const int                    terms,
                                                          const EXTRAP::ParameterList& parameterNames,
                                                          const double                 epsilon,
                                                          const int seed )
    : FunctionGenerator( functionCat, terms ), m_paramList( parameterNames )
{
    m_epsilon = epsilon;
    srand( seed );
}

EXTRAP::Function*
MultiParamFunctionGenerator::getFunction()
{
    //needed to evaluate the term contributions
    const int        p_min    = 4;
    const int        p_max    = 64;
    const int        size_min = 10;
    const int        size_max = 50;
    const int n_min = 2;
    const int n_max = 10;
    std::vector<int> mins;
    mins.push_back( p_min );
    mins.push_back( size_min );
    mins.push_back( n_min );
    std::vector<int> maxs;
    maxs.push_back( p_max );
    maxs.push_back( size_max );
    maxs.push_back( n_max );

    EXTRAP::MultiParameterFunction* function = new EXTRAP::MultiParameterFunction();

    function->setConstantCoefficient( getRandomCoeff() );
    if ( m_functionCat == EXTRAP::CONST_CAT )
    {
        return function;
    }

    function->getMultiParameterTerms().clear();

    int choice = randomSwitch( 1, 2 );

    //a+b+c
    if ( choice == 1 )
    {
        while ( true )
        {
            EXTRAP::MultiParameterFunction* temp_func = new EXTRAP::MultiParameterFunction();
            ParameterValueList              min_pvl   = ParameterValueList();
            std::vector<double>             term_results_minimum;
            double                          function_result_minimum;
            ParameterValueList              max_pvl = ParameterValueList();
            std::vector<double>             term_results_maximum;
            double                          function_result_maximum;
            for ( int i = 0; i < m_terms; ++i )
            {
                EXTRAP::MultiParameterTerm multi_term = EXTRAP::MultiParameterTerm();
                FunctionCategory           ac_cat[ m_paramList.size() ];
                bool                       is_triv[ m_paramList.size() ];
                EXTRAP::CompoundTerm       comp_term;
                generateCompoundTerm( comp_term, ac_cat[ i ], is_triv[ i ] );
                multi_term.addCompoundTermParameterPair( comp_term, m_paramList[ i ] );
                double rand_coeff = getRandomCoeff();
                multi_term.setCoefficient( rand_coeff );

                //compute term contribution
                ParameterValueList temp_min_pvl = ParameterValueList();
                ParameterValueList temp_max_pvl = ParameterValueList();
                temp_min_pvl.insert( std::make_pair( m_paramList[ i ], mins[ i ] ) );
                temp_max_pvl.insert( std::make_pair( m_paramList[ i ], maxs[ i ] ) );
                min_pvl.insert( std::make_pair( m_paramList[ i ], mins[ i ] ) );
                max_pvl.insert( std::make_pair( m_paramList[ i ], maxs[ i ] ) );
                term_results_minimum.push_back( multi_term.evaluate( temp_min_pvl ) );
                term_results_maximum.push_back( multi_term.evaluate( temp_max_pvl ) );
                temp_func->addMultiParameterTerm( multi_term );

                //std::cout << "parameter value min: " << mins[ i ] << std::endl;
                //std::cout << "parameter value max: " << maxs[ i ] << std::endl;
            }
            function_result_minimum = temp_func->evaluate( min_pvl );
            function_result_maximum = temp_func->evaluate( max_pvl );

            //evaluate the function
            //std::cout << "total min: " << function_result_minimum << std::endl;
            //std::cout << "total max: " << function_result_maximum << std::endl;
            for ( int i = 0; i < term_results_minimum.size(); i++ )
            {
                //std::cout << "term min" << i << " : " << term_results_minimum.at( i ) << std::endl;
                //std::cout << "term max" << i << " : " << term_results_maximum.at( i ) << std::endl;
            }
            double one_percent_min = function_result_minimum / 100;
            double one_percent_max = function_result_maximum / 100;

            std::vector<double> percent_terms_min;
            std::vector<double> percent_terms_max;
            for ( int i = 0; i < term_results_minimum.size(); i++ )
            {
                double percent_min = term_results_minimum.at( i ) / one_percent_min;
                double percent_max = term_results_maximum.at( i ) / one_percent_max;
                //std::cout << "term " << i << " contribution percent min: " << percent_min << std::endl;
                //std::cout << "term " << i << " contribution percent max: " << percent_max << std::endl;
                percent_terms_min.push_back( percent_min );
                percent_terms_max.push_back( percent_max );
            }
            bool is_valid = true;
            for ( int i = 0; i < percent_terms_min.size(); i++ )
            {
                if ( percent_terms_min.at( i ) < m_epsilon || percent_terms_max.at( i ) < m_epsilon )
                {
                    is_valid = false;
                    break;
                }
            }
            if ( is_valid == true )
            {
                function = temp_func;
                break;
            }
        }
        return function;
    }
    //a*b*c
    else if ( choice == 2 )
    {
        EXTRAP::MultiParameterTerm multi_term;
        FunctionCategory           ac_cat[ m_paramList.size() ];
        bool                       is_triv[ m_paramList.size() ];
        for ( int j = 0; j < m_paramList.size(); ++j )
        {
            EXTRAP::CompoundTerm comp_term;
            generateCompoundTerm( comp_term, ac_cat[ j ], is_triv[ j ] );
            multi_term.addCompoundTermParameterPair( comp_term, m_paramList[ j ] );
        }
        double rand_coeff = getRandomCoeff();
        multi_term.setCoefficient( rand_coeff );
        function->addMultiParameterTerm( multi_term );
        return function;
    }
    else
    {
        return NULL;
    }
}

bool
MultiParamFunctionGenerator::flipCoin()
{
    double u = drand48();
    return u >= 0.5;
}

int
MultiParamFunctionGenerator::randomSwitch( int min, int max )
{
    int output = min + ( rand() % static_cast<int>( max - min + 1 ) );
    return output;
}
}
