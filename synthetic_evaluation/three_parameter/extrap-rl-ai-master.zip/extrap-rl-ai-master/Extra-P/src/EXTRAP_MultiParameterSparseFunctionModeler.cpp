/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stdio.h>
#include <string.h>
#include <sstream>
#include <iostream>
#include <cassert>
#include <ctime>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <map>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_MultiParameterSparseFunctionModeler.hpp>
#include <EXTRAP_IncrementalPoint.hpp>
#include <EXTRAP_MultiParameterHypothesis.hpp>
#include <EXTRAP_Experiment.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <EXTRAP_Utilities.hpp>
#include <EXTRAP_IoHelper.hpp>
#include <EXTRAP_Coordinate.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
MultiParameterHypothesis
MultiParameterSparseFunctionModeler::createModel( const Experiment* experiment, const ModelGeneratorOptions& options, const std::vector<DataPoint>& modeledDataPointList,
                                                  ModelCommentList&             comments,
                                                  const Function*               expectationFunction )
{
    
    //// DEBUG ////
    //analyze the measurement points
    //std::cout << "1.) available points for modeling:" << std::endl;
    //std::cout << "Number of Data Points: " << modeledDataPointList.size() << std::endl;
    ParameterList plist = experiment->getParameters();
    Parameter     p1    = plist.at( 0 );
    Parameter     p2    = plist.at( 1 );
    Parameter     p3    = plist.at( 2 );
    /*
    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        DataPoint dp  = modeledDataPointList.at( i );
        double    v   = dp.getValue();
        double    p1v = dp.getParameterValue( p1 );
        double    p2v = dp.getParameterValue( p2 );
        double    p3v = dp.getParameterValue( p3 );
        std::cout << "(" << p1.getName() << "," << p1v << ")(" << p2.getName() << "," << p2v << ")(" << p3.getName() << "," << p3v << ") = " << v << std::endl;
    }
    */
    //analyze coordinates
    /*
    CoordinateList cordlist = experiment->getCoordinates();
    std::cout << "Number of Coordinates: " << cordlist.size() << std::endl;
    for ( int i = 0; i < cordlist.size(); i++ )
    {
        std::cout << "Coordinate " << i << ": " << cordlist.at( i )->toString() << std::endl;
    }
    */
    
    double constantCost = 0;
    double meanModel = 0;
    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        meanModel += modeledDataPointList[ i ].getValue() / ( double )modeledDataPointList.size();
    }
    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        constantCost += ( modeledDataPointList[ i ].getValue() - meanModel ) * ( modeledDataPointList[ i ].getValue() - meanModel );
    }
    this->m_params = experiment->getParameters();
    this->m_options = options;
    std::vector<CoordinateList> coordinate_container_list;  //coordinates for each single parameter experiment
    coordinate_container_list = findCheapestMeasurementPoints( experiment, this->m_options.getMinNumberPoints(), modeledDataPointList );
    std::vector<Experiment*>              experiments          = createAllExperiments( coordinate_container_list, experiment, modeledDataPointList );
    std::vector<Experiment*>              experiments2         = modelAllExperiments( experiments, m_options );
    getSingleParameterExperimentFunctions( experiments2 );

    //////////////////////////////////////////////////////////////////

    //TODO: Think about how to select the points for the single parameter experiment. In the end might not matter.
    // But for modeling we want to use all points / best points we have not necessarily the cheapest when we already
    // payed the money to measured them in the first place.

    //////////////////////////////////////////////////////////////////

    /*

    if ( this->m_paramsToDelete.size() == this->m_params.size() )
    {
        MultiParameterFunction* constantFunction = new MultiParameterFunction();
        constantFunction->setConstantCoefficient( meanModel );
        MultiParameterHypothesis constantHypothesis( constantFunction );
        constantHypothesis.setRSS( constantCost );
        constantHypothesis.setAR2( 0 );
        constantHypothesis.setrRSS( 0 );
        constantHypothesis.setSMAPE( 0 );
        return constantHypothesis;
    }
    else if ( ( this->m_params.size() - this->m_paramsToDelete.size() ) == 1 )
    {
        MultiParameterFunction* simpleFunction = new MultiParameterFunction();
        MultiParameterTerm      t;
        t.addCompoundTermParameterPair( this->m_single_parameter_functions[ 0 ]->getCompoundTerms()[ 0 ], this->m_params[ this->m_paramsToKeep[ 0 ] ] );
        t.setCoefficient( this->m_single_parameter_functions[ 0 ]->getCompoundTerms()[ 0 ].getCoefficient() );
        simpleFunction->addMultiParameterTerm( t );
        MultiParameterHypothesis simpleHypothesis( simpleFunction );
        simpleHypothesis.getFunction()->setConstantCoefficient( this->m_single_parameter_functions[ 0 ]->getConstantCoefficient() );
        simpleHypothesis.computeCost( modeledDataPointList );
        return simpleHypothesis;
    }

    for ( int i = this->m_paramsToDelete.size() - 1; i >= 0; i-- )
    {
        this->m_params.erase( this->m_params.begin() + this->m_paramsToDelete[ i ] );
    }
    */

    //////////////////////////////////////////////////////////////////

    //TODO: automatically use all available points for modeling
    // then the selection strategy for the additional points does not matter anymore
    // as well as the flag for use_add_points

    //////////////////////////////////////////////////////////////////


    CoordinateList                        base_cord_list       = getBaseCoordinates( coordinate_container_list );
    std::vector<DataPoint>                base_data_point_list = getBaseDataPoints( base_cord_list, experiment, modeledDataPointList );
    int                                 number_base_data_points      = base_cord_list.size();
    int                                 number_available_data_points = modeledDataPointList.size();
    int                                 max_add_data_points          = number_available_data_points - number_base_data_points;
    int                                 number_add_data_points       = m_options.getNumberAddPoints();
    bool                                use_add_data_points          = m_options.getUseAddPoints();

    //std::cout << "using additional points?: " << use_add_data_points << std::endl;
    //std::cout << "number of data points to add: " << number_add_data_points << std::endl;
    //std::cout << "number of base points: " << base_data_point_list.size() << std::endl;

    if ( number_add_data_points < 0 || number_add_data_points > max_add_data_points )
    {
        //ErrorStream << "The number of data points you choose to add is invalid. Maximum possible is " << max_add_data_points << ". Minimum required is 1. Using only baseline points instead." << std::endl;
        //use_add_data_points = false;
        number_add_data_points = max_add_data_points;
    }
    if ( use_add_data_points == false )
    {
        //std::cout << "using no additional points!" << std::endl;
        //std::cout << "3.) points used for modeling:" << std::endl;
        /*
        for ( int i = 0; i < base_data_point_list.size(); i++ )
        {
            DataPoint dp  = base_data_point_list.at( i );
            double    v   = dp.getValue();
            double    p1v = dp.getParameterValue( p1 );
            double    p2v = dp.getParameterValue( p2 );
            double    p3v = dp.getParameterValue( p3 );
            std::cout << "(" << p1.getName() << "," << p1v << ")(" << p2.getName() << "," << p2v << ")(" << p3.getName() << "," << p3v << ") = " << v << std::endl;
        }
        */

        MultiParameterHypothesis bestHypothesis = findBestMultiParameterHypothesis( base_data_point_list, experiment, this->m_single_parameter_functions );
        return bestHypothesis;
    }
    else
    {
        std::vector<DataPoint>   additional_data_point_list = getAdditionalDataPoints( base_cord_list, experiment, modeledDataPointList );
        std::vector<DataPoint>   sorted_data_points         = sortByCostInc( experiment, additional_data_point_list );
        std::vector<DataPoint>   data_points                = addAdditionalDataPoints( base_data_point_list, sorted_data_points, number_add_data_points );
        
        //std::cout << "using additional points!" << std::endl;
        //std::cout << "using these base points for modeling: " << std::endl;
        /*
        for ( int i = 0; i < base_data_point_list.size(); i++ )
        {
            DataPoint dp  = base_data_point_list.at( i );
            double    v   = dp.getValue();
            double    p1v = dp.getParameterValue( p1 );
            double    p2v = dp.getParameterValue( p2 );
            double    p3v = dp.getParameterValue( p3 );
            std::cout << "(" << p1.getName() << "," << p1v << ")(" << p2.getName() << "," << p2v << ")(" << p3.getName() << "," << p3v << ") = " << v << std::endl;
        }
        */
        
        MultiParameterHypothesis bestHypothesis             = findBestMultiParameterHypothesis( data_points, experiment, this->m_single_parameter_functions );
        return bestHypothesis;
    }
}

std::vector<DataPoint>
MultiParameterSparseFunctionModeler::addAdditionalDataPoints( std::vector<DataPoint>& data_points, const std::vector<DataPoint>& modeledDataPointList, int number_add_data_points )
{
    for ( int i = 0; i < number_add_data_points; i++ )
    {
        DataPoint dp = modeledDataPointList.at( i );
        data_points.push_back( dp );
    }
    return data_points;
}

std::vector<DataPoint>
MultiParameterSparseFunctionModeler::sortByCostDec( const Experiment* experiment, const std::vector<DataPoint>& modeledDataPointList )
{
    std::vector<DataPoint> modeledDataPointList_copy = modeledDataPointList;
    std::vector<DataPoint> sorted_data_points;
    ParameterList          plist       = experiment->getParameters();
    Parameter              p1          = plist.at( 0 );

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        double cost = 0;
        int    id   = 0;
        for ( int j = 0; j < modeledDataPointList_copy.size(); j++ )
        {
            DataPoint dp        = modeledDataPointList_copy.at( j );
            double    processes = dp.getParameterValue( p1 );
            double    time      = dp.getValue();
            if ( j == 0 )
            {
                cost = processes * time;
            }
            double cost_n = processes * time;
            if ( cost_n >= cost )
            {
                cost = cost_n;
                id   = j;
            }
        }
        DataPoint point_to_add = modeledDataPointList_copy.at( id );
        modeledDataPointList_copy.erase( modeledDataPointList_copy.begin() + id );
        sorted_data_points.push_back( point_to_add );
    }
    return sorted_data_points;
}

std::vector<DataPoint>
MultiParameterSparseFunctionModeler::sortByCostInc( const Experiment* experiment, const std::vector<DataPoint>& modeledDataPointList )
{
    std::vector<DataPoint> modeledDataPointList_copy = modeledDataPointList;
    std::vector<DataPoint> sorted_data_points;
    ParameterList          plist       = experiment->getParameters();
    Parameter              p1          = plist.at( 0 );

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        double cost = 0;
        int    id   = 0;
        for ( int j = 0; j < modeledDataPointList_copy.size(); j++ )
        {
            DataPoint dp        = modeledDataPointList_copy.at( j );
            double    processes = dp.getParameterValue( p1 );
            double    time      = dp.getValue();
            if ( j == 0 )
            {
                cost = processes * time;
            }
            double cost_n = processes * time;
            if ( cost_n < cost )
            {
                cost = cost_n;
                id   = j;
            }
        }
        DataPoint point_to_add = modeledDataPointList_copy.at( id );
        modeledDataPointList_copy.erase( modeledDataPointList_copy.begin() + id );
        sorted_data_points.push_back( point_to_add );
    }
    return sorted_data_points;
}

std::vector<DataPoint>
MultiParameterSparseFunctionModeler::getAdditionalDataPoints( CoordinateList base_cord_list, const Experiment* experiment, const std::vector<DataPoint>& modeledDataPointList )
{
    std::vector<DataPoint> additional_data_point_list;
    ParameterList          plist = experiment->getParameters();

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        DataPoint          dp  = modeledDataPointList.at( i );
        std::string cord_string = "";

        for (int j = 0; j < plist.size(); j++)
        {
            Parameter              parameter    = plist.at( j );
            double             parameter_value = dp.getParameterValue( parameter );
            std::ostringstream strs;
            strs << parameter_value;
            std::string        parameter_value_string = strs.str();
            cord_string = cord_string + "(" + parameter.getName() + "," + parameter_value_string + ")";
        }

        bool        is_existing = false;
        for ( int j = 0; j < base_cord_list.size(); j++ )
        {
            Coordinate* c        = base_cord_list.at( j );
            std::string c_string = c->toString();

            //bring the coordinate string in the right order
            //since someone thought it is a good idea to use a map that sorts alpabetically...
            std::vector<std::string> string_parts;
            std::string working_copy = c_string;

            for (int k = 0; k < plist.size(); k++)
            {
                Parameter parameter = plist.at( k );
                std::string parameter_string = parameter.getName();
                int pos = working_copy.find(parameter_string);
                std::string temp = working_copy.substr(pos-1,working_copy.size());
                pos = temp.find(")");
                temp = temp.substr(0,pos+1);
                string_parts.push_back(temp);
            }

            std::string sorted_coordinate_string = "";

            for (int k = 0; k < plist.size(); k++)
            {
                sorted_coordinate_string = sorted_coordinate_string + string_parts[k];
            }

            if ( cord_string == sorted_coordinate_string )
            {
                is_existing = true;
                break;
            }
        }
        if ( is_existing == false )
        {
            additional_data_point_list.push_back( dp );
        }
    }
    return additional_data_point_list;
}

std::vector<DataPoint>
MultiParameterSparseFunctionModeler::getBaseDataPoints( CoordinateList base_cord_list, const Experiment* experiment, const std::vector<DataPoint>& modeledDataPointList )
{
    std::vector<DataPoint> base_data_point_list;
    ParameterList          plist = experiment->getParameters();

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        DataPoint          dp  = modeledDataPointList.at( i );
        std::string cord_string = "";

        for (int j = 0; j < plist.size(); j++)
        {
            Parameter              parameter    = plist.at( j );
            double             parameter_value = dp.getParameterValue( parameter );
            std::ostringstream strs;
            strs << parameter_value;
            std::string        parameter_value_string = strs.str();
            cord_string = cord_string + "(" + parameter.getName() + "," + parameter_value_string + ")";
        }

        bool        is_existing = false;
        for ( int j = 0; j < base_cord_list.size(); j++ )
        {
            Coordinate* c        = base_cord_list.at( j );
            std::string c_string = c->toString();

            //bring the coordinate string in the right order
            //since someone thought it is a good idea to use a map that sorts alpabetically...
            std::vector<std::string> string_parts;
            std::string working_copy = c_string;

            for (int k = 0; k < plist.size(); k++)
            {
                Parameter parameter = plist.at( k );
                std::string parameter_string = parameter.getName();
                int pos = working_copy.find(parameter_string);
                std::string temp = working_copy.substr(pos-1,working_copy.size());
                pos = temp.find(")");
                temp = temp.substr(0,pos+1);
                string_parts.push_back(temp);
            }

            std::string sorted_coordinate_string = "";

            for (int k = 0; k < plist.size(); k++)
            {
                sorted_coordinate_string = sorted_coordinate_string + string_parts[k];
            }

            if ( cord_string == sorted_coordinate_string )
            {
                is_existing = true;
                break;
            }
        }
        if ( is_existing == true )
        {
            base_data_point_list.push_back( dp );
        }
    }
    return base_data_point_list;
}

CoordinateList
MultiParameterSparseFunctionModeler::getBaseCoordinates( std::vector<CoordinateList> coordinate_container_list )
{
    CoordinateList base_cord_list;
    for ( int i = 0; i < coordinate_container_list.size(); i++ )
    {
        CoordinateList temp = coordinate_container_list.at( i );
        for ( int j = 0; j < temp.size(); j++ )
        {
            Coordinate* c = temp.at( j );
            if ( base_cord_list.size() == 0 )
            {
                base_cord_list.push_back( c );
            }
            else
            {
                std::string c_string    = c->toString();
                bool        is_existing = false;
                for ( int z = 0; z < base_cord_list.size(); z++ )
                {
                    Coordinate* c2        = base_cord_list.at( z );
                    std::string c2_string = c2->toString();
                    if ( c_string == c2_string )
                    {
                        is_existing = true;
                        break;
                    }
                }
                if ( is_existing == false )
                {
                    base_cord_list.push_back( c );
                }
            }
        }
    }
    return base_cord_list;
}

MultiParameterHypothesis
MultiParameterSparseFunctionModeler::findBestMultiParameterHypothesis( const std::vector<DataPoint>& modeledDataPointList, const Experiment* parent_experiment, std::vector<SingleParameterFunction*> functions )
{
    bool DEBUG = false;

    double constantCost = 0;
    double meanModel    = 0;

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        meanModel += modeledDataPointList[ i ].getValue() / ( double )modeledDataPointList.size();
    }
    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        constantCost += ( modeledDataPointList[ i ].getValue() - meanModel ) * ( modeledDataPointList[ i ].getValue() - meanModel );
    }

    std::vector<EXTRAP::MultiParameterTerm>      term_vec;
    std::vector<EXTRAP::MultiParameterTerm>      mult_term_vec;
    std::vector<EXTRAP::MultiParameterFunction*> multi_parameter_functions;

    //////////////////////////////////////////////////////////////////

    //TODO: Build the correct functions for the case studies

    //////////////////////////////////////////////////////////////////

    //function1: a + b(+c)
    MultiParameterFunction*                 function1 = new MultiParameterFunction();
    std::vector<std::vector<CompoundTerm> > compound_terms_list;
    ParameterList                           param_list;
    for ( int i = 0; i < functions.size(); i++ )
    {
        std::vector<CompoundTerm> ct_list = functions[ i ]->getCompoundTerms();
        if ( ct_list.size() > 0 )
        {
            param_list.push_back( this->m_params.at( i ) );
            compound_terms_list.push_back( ct_list );
        }
    }
    std::vector<EXTRAP::MultiParameterTerm> add;
    for ( int i = 0; i < compound_terms_list.size(); i++ )
    {
        EXTRAP::MultiParameterTerm tmp;
        std::vector<CompoundTerm>  c_terms = compound_terms_list.at( i );
        for ( int j = 0; j < c_terms.size(); j++ )
        {
            EXTRAP::CompoundTerm ct;
            ct = c_terms.at( j );
            ct.setCoefficient( 1 );
            tmp.addCompoundTermParameterPair( ct, this->m_params[ i ] );
        }
        tmp.setCoefficient( 1 );
        add.push_back( tmp );
    }
    for ( int i = 0; i < add.size(); i++ )
    {
        function1->addMultiParameterTerm( add.at( i ) );
    }
    function1->setConstantCoefficient( 1 );
    if ( DEBUG == true )
    {
        std::string mpf = function1->getAsString( param_list );
        std::cout << "Multi parameter function 1: " << mpf << "\n";
    }

    //function2: a * b(*c)
    MultiParameterFunction*    function2 = new MultiParameterFunction();
    EXTRAP::MultiParameterTerm mult;
    for ( int i = 0; i < compound_terms_list.size(); i++ )
    {
        std::vector<CompoundTerm> c_terms = compound_terms_list.at( i );
        for ( int j = 0; j < c_terms.size(); j++ )
        {
            EXTRAP::CompoundTerm ct;
            ct = c_terms.at( j );
            ct.setCoefficient( 1 );
            mult.addCompoundTermParameterPair( ct, this->m_params[ i ] );
        }
    }
    mult.setCoefficient( 1 );
    function2->addMultiParameterTerm( mult );
    function2->setConstantCoefficient( 1 );
    if ( DEBUG == true )
    {
        std::string mpf2 = function2->getAsString( param_list );
        std::cout << "Multi parameter function 2: " << mpf2 << "\n";
    }

    //function3: a * b + a
    MultiParameterFunction*   function3 = new MultiParameterFunction();
    std::vector<CompoundTerm> ct_list   = functions[ 0 ]->getCompoundTerms();
    if ( ct_list.size() > 0 )
    {
        EXTRAP::MultiParameterTerm add_0;
        for ( int i = 0; i < ct_list.size(); i++ )
        {
            EXTRAP::CompoundTerm ct;
            ct = ct_list.at( i );
            ct.setCoefficient( 1 );
            add_0.addCompoundTermParameterPair( ct, this->m_params[ 0 ] );
        }
        add_0.setCoefficient( 1 );
        function3->addMultiParameterTerm( add_0 );
    }
    function3->addMultiParameterTerm( mult );
    function3->setConstantCoefficient( 1 );
    if ( DEBUG == true )
    {
        //std::string mpf3 = function3->getAsString( param_list );
        //std::cout << "Multi parameter function3: " << mpf3 << "\n";
    }

    //function4: a * b + b
    MultiParameterFunction* function4 = new MultiParameterFunction();
    ct_list = functions[ 1 ]->getCompoundTerms();
    if ( ct_list.size() > 0 )
    {
        EXTRAP::MultiParameterTerm add_1;
        for ( int i = 0; i < ct_list.size(); i++ )
        {
            EXTRAP::CompoundTerm ct;
            ct = ct_list.at( i );
            ct.setCoefficient( 1 );
            add_1.addCompoundTermParameterPair( ct, this->m_params[ 1 ] );
        }
        add_1.setCoefficient( 1 );
        function4->addMultiParameterTerm( add_1 );
    }
    function4->addMultiParameterTerm( mult );
    function4->setConstantCoefficient( 1 );
    if ( DEBUG == true )
    {
        //std::string mpf4 = function4->getAsString( param_list );
        //std::cout << "Multi parameter function4: " << mpf4 << "\n";
    }

    //add function combinations to multiparameter function vector
    if ( this->m_params.size() == 2 )
    {
        multi_parameter_functions.push_back( function1 );   //a+b
        multi_parameter_functions.push_back( function2 );   //a*b
        //multi_parameter_functions.push_back( function3 ); //a*b+a
        //multi_parameter_functions.push_back( function4 ); //a*b+a
    }

    //add Hypotheses for 3 parameter models
    if ( this->m_params.size() == 3 )
    {
        multi_parameter_functions.push_back( function1 );   //a+b+c
        multi_parameter_functions.push_back( function2 );   //a*b*c
    }

    // Convert functions to hypotheses
    std::vector<MultiParameterHypothesis> hypotheses;
    for ( int i = 0; i < multi_parameter_functions.size(); ++i )
    {
        MultiParameterHypothesis mph( multi_parameter_functions[ i ] );
        hypotheses.push_back( mph );
    }

    if ( DEBUG == true )
    {
        for (int i = 0; i < hypotheses.size(); i++)
        {
            std::cout << "Hypotheses " << i << ": " << hypotheses.at(i).getFunction()->getAsString( this->m_params ) << std::endl;
        }
    }

    //select one function as the bestHypothesis for the start
    MultiParameterHypothesis bestHypothesis = hypotheses[ 0 ];


    /**
    //DEBUG
    //analyze the measurement points
    std::cout << "Number of Data Points: " << modeledDataPointList.size() << std::endl;
    ParameterList plist = this->m_params;
    Parameter     p1    = plist.at( 0 );
    Parameter     p2    = plist.at( 1 );
    Parameter     p3    = plist.at( 2 );
    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        DataPoint dp  = modeledDataPointList.at( i );
        double    v   = dp.getValue();
        double    p1v = dp.getParameterValue( p1 );
        double    p2v = dp.getParameterValue( p2 );
        double    p3v = dp.getParameterValue( p3 );
        std::cout << "(" << p1.getName() << "," << p1v << ")(" << p2.getName() << "," << p2v << ")(" << p3.getName() << "," << p3v << ") = " << v << std::endl;
    }
    **/


    //std::cout << "Taylor : " << bestHypothesis.getFunction()->getAsString( this->m_params ) << " --- smape: " << bestHypothesis.getSMAPE() << " --- ar2: " << bestHypothesis.getAR2() << " --- rss: " << bestHypothesis.getRSS() << " --- rrss: " << bestHypothesis.getrRSS() << " --- re: " << bestHypothesis.getRE() << std::endl;


    bestHypothesis.estimateParameters( modeledDataPointList );

    //std::cout << "Selena : " << bestHypothesis.getFunction()->getAsString( this->m_params ) << " --- smape: " << bestHypothesis.getSMAPE() << " --- ar2: " << bestHypothesis.getAR2() << " --- rss: " << bestHypothesis.getRSS() << " --- rrss: " << bestHypothesis.getrRSS() << " --- re: " << bestHypothesis.getRE() << std::endl;



    bestHypothesis.computeCost( modeledDataPointList );
    bestHypothesis.computeAdjustedRSquared( constantCost, modeledDataPointList );

    //debug print out for the hypothesis
    if ( DEBUG == true )
    {
        std::cout << "hypothesis 0 : " << bestHypothesis.getFunction()->getAsString( this->m_params ) << " --- smape: " << bestHypothesis.getSMAPE() << " --- ar2: " << bestHypothesis.getAR2() << " --- rss: " << bestHypothesis.getRSS() << " --- rrss: " << bestHypothesis.getrRSS() << " --- re: " << bestHypothesis.getRE() << std::endl;
    }

    //find the best hypothesis
    for ( int i = 1; i < hypotheses.size(); i++ )
    {
        //std::cout << hypotheses[ i ].getFunction()->getAsString( this->m_params ) << std::endl;

        hypotheses[ i ].estimateParameters( modeledDataPointList );

        //std::cout << hypotheses[ i ].getFunction()->getAsString( this->m_params ) << std::endl;

        hypotheses[ i ].computeCost( modeledDataPointList );
        hypotheses[ i ].computeAdjustedRSquared( constantCost, modeledDataPointList );

        //debug print out for the hypothesis
        if ( DEBUG == true )
        {
            std::cout << "hypothesis " << i << " : " << hypotheses[ i ].getFunction()->getAsString( this->m_params ) << " --- smape: " << hypotheses[ i ].getSMAPE() << " --- ar2: " << hypotheses[ i ].getAR2() << " --- rss: " << hypotheses[ i ].getRSS() << " --- rrss: " << hypotheses[ i ].getrRSS() << " --- re: " << hypotheses[ i ].getRE() << std::endl;
        }

        if ( hypotheses[ i ].getSMAPE() < bestHypothesis.getSMAPE() )
        {
            delete ( bestHypothesis.getFunction() );
            bestHypothesis = hypotheses[ i ];
        }
        else
        {
            delete ( hypotheses[ i ].getFunction() );
        }
        /**
         * alternative selection with relative error
           if ( hypotheses[ i ].getRE() < bestHypothesis.getRE() )
           {
            delete ( bestHypothesis.getFunction() );
            bestHypothesis = hypotheses[ i ];
           }
           else
           {
            delete ( hypotheses[ i ].getFunction() );
           }
         **/
    }
    return bestHypothesis;
}

void
MultiParameterSparseFunctionModeler::getSingleParameterExperimentFunctions( std::vector<Experiment*> experiments )
{
    for ( int i = 0; i < experiments.size(); i++ )
    {
        Experiment*              experiment     = experiments.at( i );
        const ParameterList&     parameterNames = experiment->getParameters();
        Callpath*                callpath       = experiment->getCallpath( 0 );
        Metric*                  metric         = experiment->getMetric( 0 );
        const ModelList&         model_list     = experiment->getModels( *metric, *callpath );
        SingleParameterFunction* function       = dynamic_cast<SingleParameterFunction*>( model_list[ 0 ]->getModelFunction() );
        if ( function->getCompoundTerms().size() > 0 )
        {
            this->m_single_parameter_functions.push_back( function );
            this->m_paramsToKeep.push_back( i );
        }
        else
        {
            this->m_paramsToDelete.push_back( i );
        }
    }
}

std::vector<Experiment*>
MultiParameterSparseFunctionModeler::modelAllExperiments( std::vector<Experiment*> experiments, ModelGeneratorOptions options )
{
    std::vector<Experiment*> exps;
    for ( int i = 0; i < experiments.size(); i++ )
    {
        Experiment* exp = experiments.at( i );
        exp = addSingleParameterModeler( exp, options );
        exps.push_back( exp );
    }
    return exps;
}

Experiment*
MultiParameterSparseFunctionModeler::addSingleParameterModeler( Experiment* exp, ModelGeneratorOptions options )
{
    Experiment*                          experiment       = exp;
    MetricList                           metrics          = experiment->getMetrics();
    CallpathList                         callpaths        = experiment->getAllCallpaths();
    ModelGenerator*                      model_generator  = NULL;
    SingleParameterSimpleModelGenerator* single_generator = new SingleParameterSimpleModelGenerator();
    model_generator = single_generator;
    experiment->addModelGenerator( model_generator );
    experiment->modelAll( *model_generator, experiment, options );
    return experiment;
}

std::vector<Experiment*>
MultiParameterSparseFunctionModeler::createAllExperiments( std::vector<CoordinateList> coordinate_container_list, const Experiment* parent_experiment, const std::vector<DataPoint>& modeledDataPointList )
{
    std::vector<Experiment*> experiments;
    if ( coordinate_container_list.size() > 0 )
    {
        CoordinateList coordinate_container;
        Parameter      parameter;
        Metric*        metric = NULL;
        Region*        region = NULL;
        Callpath*      callpath;
        Experiment*    single_param_exp;
        for ( int i = 0; i < coordinate_container_list.size(); i++ )
        {
            coordinate_container = coordinate_container_list.at( i );
            parameter            = parent_experiment->getParameter( i );
            metric               = parent_experiment->getMetric( 0 );
            region               = parent_experiment->getRegion( 0 );
            callpath             = parent_experiment->getCallpath( 0 );
            single_param_exp     = createSingleParameterExperiment( parent_experiment, coordinate_container, parameter, metric, region, callpath, modeledDataPointList );
            experiments.push_back( single_param_exp );
        }
    }
    else
    {
        ErrorStream << "List of measurement points is empty. Can not create experiments for parameters." << std::endl;
    }
    return experiments;
}

Experiment*
MultiParameterSparseFunctionModeler::createSingleParameterExperiment( const Experiment* original_experiment, CoordinateList coordinate_container, Parameter parameter, Metric* metric, Region* region, Callpath* callpath, const std::vector<DataPoint>& modeledDataPointList )
{
    bool DEBUG = false;

    //add experiment objects
    Experiment* single_param_exp = new Experiment();
    single_param_exp->addParameter( parameter );
    single_param_exp->addMetric( metric );
    single_param_exp->addRegion( region );
    single_param_exp->addCallpath( callpath );
    if ( DEBUG == true )
    {
        std::cout << "Measurement Points for Single Parameter Experiment: " << parameter.getName() << "\n";
    }

    /**
     * add coordinates to the experiment
     * must be casted from n parameter cords to 1 parameter cords
     * keep a copy of them for later to add the data values
     **/
    std::vector<std::string> save_cords;
    for ( int i = 0; i < coordinate_container.size(); i++ )
    {
        Coordinate* cord        = coordinate_container.at( i );
        std::string cord_string = cord->toString();
        save_cords.push_back( cord_string );
        int pos = 0;
        pos = cord_string.find( parameter.getName() );
        std::string parameter_value = "";
        parameter_value = cord_string.substr( pos, cord_string.size() );
        pos             = parameter_value.find( ")" );
        parameter_value = parameter_value.substr( 0, pos );
        pos             = parameter_value.find( "," );
        parameter_value = parameter_value.substr( pos + 1, parameter_value.size() );
        char buffer[ parameter_value.length() + 1 ];
        strcpy( buffer, parameter_value.c_str() );
        double      x = atof( buffer );
        Coordinate* c = new Coordinate();
        c->insert( std::pair<Parameter, Value>( parameter, x ) );
        single_param_exp->addCoordinate( c );
        if ( DEBUG == true )
        {
            std::cout << c->toString() << "\n";
        }
    }
    if ( DEBUG == true )
    {
        std::cout << "\n";
    }

    CoordinateList pointslist = single_param_exp->getCoordinates();
    // array that keeps all the data points, separated by the measurement point id of the point list which stores the measurement points
    IncrementalPoint data_points[ pointslist.size() ];

    //do the same thing, but with the modelDataPoints and not with line passing from the file...

    for ( int j = 0; j < save_cords.size(); j++ )
    {
        std::string coordinate_string = save_cords.at( j );

        //bring the coordinate string in the right order
        //since someone thought it is a good idea to use a map that sorts alpabetically...
        std::vector<std::string> string_parts;
        ParameterList p_list =  original_experiment->getParameters();
        std::string working_copy = coordinate_string;

        for (int k = 0; k < p_list.size(); k++)
        {
            Parameter parameter = p_list.at( k );
            std::string parameter_string = parameter.getName();
            int pos = working_copy.find(parameter_string);
            std::string temp = working_copy.substr(pos-1,working_copy.size());
            pos = temp.find(")");
            temp = temp.substr(0,pos+1);
            string_parts.push_back(temp);
        }

        std::string sorted_coordinate_string = "";

        for (int k = 0; k < p_list.size(); k++)
        {
            sorted_coordinate_string = sorted_coordinate_string + string_parts[k];
        }

        for ( int i = 0; i < modeledDataPointList.size(); i++ )
        {
            DataPoint data_point = modeledDataPointList.at( i );
            ParameterList param_list =  original_experiment->getParameters();
            double    x   = data_point.getValue();
            std::string p = "";

            for (int k = 0; k < param_list.size(); k++)
            {
                Parameter parameter  = param_list.at( k );
                double parameter_value = data_point.getParameterValue( parameter );
                std::ostringstream strs1;
                strs1 << parameter_value;
                std::string parameter_value_string = strs1.str();
                p = p + "(" + parameter.getName() + "," + parameter_value_string + ")";
            }

            if ( sorted_coordinate_string == p )
            {
                data_points[ j ].addValue( x );
            }
        }
    }

    // add all the collected measurements in form of the data points to the experiment
    for ( int i = 0; i < pointslist.size(); i++ )
    {
        single_param_exp->addDataPoint( data_points[ i ].getExperimentPoint( pointslist[ i ],
                                                                             metric,
                                                                             callpath ),
                                        *metric,
                                        *callpath );
    }

    return single_param_exp;
}

std::vector<CoordinateList>
MultiParameterSparseFunctionModeler::findFirstMeasurementPoints( const Experiment* parent_experiment, int min_measurement_points )
{
    bool DEBUG = false;

    std::vector<CoordinateList> coordinate_container_list;

    // check the number of parameters
    ParameterList parameters = parent_experiment->getParameters();

    if ( DEBUG == true )
    {
        std::cout << "Number of parameters: " << parameters.size() << ".\n";
        for ( int i = 0; i < parameters.size(); i++ )
        {
            std::cout << "parameter " << i << ": " << parameters.at( i ).getName() << std::endl;
        }
    }

    if ( parameters.size() == 1 )
    {
        ErrorStream << "Experiment contains not enough parameters. Minimum for this modeling approach is 2." << std::endl;
    }

    //Sparse Modeler only support 2 parameters
    else if ( parameters.size() == 2 || parameters.size() == 3 )
    {
        CoordinateList coordinates_tmp = parent_experiment->getCoordinates();
        CoordinateList coordinates;

        //analyze the coordinate list, to filter duplicates in case there are some
        for ( int i = 0; i < coordinates_tmp.size(); i++ )
        {
            if ( i == 0 )
            {
                coordinates.push_back( coordinates_tmp.at( i ) );
            }
            else
            {
                bool found = false;
                for ( int j = 0; j < coordinates.size(); j++ )
                {
                    if ( coordinates.at( j )->toString() == coordinates_tmp.at( i )->toString() )
                    {
                        found = true;
                        break;
                    }
                }
                if ( found == false )
                {
                    coordinates.push_back( coordinates_tmp.at( i ) );
                }
            }
        }

        // debug print for the coordinates input
        if ( DEBUG == true )
        {
            std::cout << "Number of Coordinates: " << coordinates.size() << ".\n";
            for ( int i = 0; i < coordinates.size(); i++ )
            {
                std::cout << "Coordinate " << i << ": " << coordinates.at( i )->toString() << std::endl;
            }
        }

        for ( int i = 0; i < parameters.size(); i++ )
        {
            Parameter      parameter = parameters[ i ];
            CoordinateList coordinate_container;
            bool           done = false;
            for ( int j = 0; j < coordinates.size(); j++ )
            {
                Coordinate*         reference_coordinate = coordinates[ j ];
                std::vector<double> parameter_value_list = getParameterValues( parameters, reference_coordinate, i );
                bool                nice                 = analyzeMeasurementPoint( parameters, parameter_value_list );
                if ( nice == true )
                {
                    for ( int z = 0; z < coordinates.size(); z++ )
                    {
                        Coordinate*         coordinate            = coordinates[ z ];
                        std::vector<double> parameter_value_list2 = getParameterValues( parameters, coordinate, i );
                        bool                equal                 = compareParameterValues( parameter_value_list, parameter_value_list2 );
                        if ( equal == true )
                        {
                            coordinate_container.push_back( coordinate );
                        }
                    }
                    if ( coordinate_container.size() < min_measurement_points )
                    {
                        coordinate_container.clear();
                    }
                    else
                    {
                        done = true;
                        break;
                    }
                }
            }
            if ( done == true )
            {
                coordinate_container_list.push_back( coordinate_container );
            }
            else
            {
                ErrorStream << "Not enough measurement points for parameter " << parameter.getName() << "." << std::endl;
            }
        }

        // print the result of the search
        if ( DEBUG == true )
        {
            for ( int i = 0; i < coordinate_container_list.size(); i++ )
            {
                Parameter parameter = parameters[ i ];
                std::cout << "Measurement Points for parameter: " << parameter.getName() << ".\n";
                CoordinateList cord_list = coordinate_container_list.at( i );
                for ( int j = 0; j < cord_list.size(); j++ )
                {
                    Coordinate* reference_coordinate = cord_list[ j ];
                    std::string temp                 = reference_coordinate->toString();
                    std::cout << temp << "\n";
                }
                std::cout << "\n";
            }
        }
    }
    else
    {
        ErrorStream << "Experiment contains a number of parameters that is currently not supported." << std::endl;
    }
    return coordinate_container_list;
}

std::vector<CoordinateList>
MultiParameterSparseFunctionModeler::findMaxMeasurementPoints( const Experiment* parent_experiment, int min_measurement_points )
{
    bool DEBUG = false;

    //the output list, will contain the final selected coordinates
    std::vector<CoordinateList> coordinate_container_list;

    //check the number of parameters
    ParameterList parameters = parent_experiment->getParameters();

    //create empty lists for the coordinate selection process
    std::vector<std::vector<CoordinateList> > container;
    for ( int i = 0; i < parameters.size(); i++ )
    {
        std::vector<CoordinateList> tmp_container_list;
        container.push_back( tmp_container_list );
    }

    if ( DEBUG == true )
    {
        std::cout << "Number of parameters: " << parameters.size() << ".\n";
        for ( int i = 0; i < parameters.size(); i++ )
        {
            std::cout << "parameter " << i << ": " << parameters.at( i ).getName() << std::endl;
        }
    }

    if ( parameters.size() == 1 )
    {
        ErrorStream << "Experiment contains not enough parameters. Minimum for this modeling approach is 2." << std::endl;
    }

    //Sparse Modeler only support 2 parameters
    else if ( parameters.size() == 2 || parameters.size() == 3 )
    {
        CoordinateList coordinates_tmp = parent_experiment->getCoordinates();
        CoordinateList coordinates;

        //analyze the coordinate list, to filter duplicates in case there are some
        for ( int i = 0; i < coordinates_tmp.size(); i++ )
        {
            if ( i == 0 )
            {
                coordinates.push_back( coordinates_tmp.at( i ) );
            }
            else
            {
                bool found = false;
                for ( int j = 0; j < coordinates.size(); j++ )
                {
                    if ( coordinates.at( j )->toString() == coordinates_tmp.at( i )->toString() )
                    {
                        found = true;
                        break;
                    }
                }
                if ( found == false )
                {
                    coordinates.push_back( coordinates_tmp.at( i ) );
                }
            }
        }

        // debug print for the coordinates input
        if ( DEBUG == true )
        {
            std::cout << "Number of Coordinates: " << coordinates.size() << ".\n";
            for ( int i = 0; i < coordinates.size(); i++ )
            {
                std::cout << "Coordinate " << i << ": " << coordinates.at( i )->toString() << std::endl;
            }
        }

        //find point rows that have at least min points
        for ( int i = 0; i < parameters.size(); i++ )
        {
            Parameter      parameter = parameters[ i ];
            CoordinateList coordinate_container;
            for ( int j = 0; j < coordinates.size(); j++ )
            {
                Coordinate*         reference_coordinate = coordinates[ j ];
                std::vector<double> parameter_value_list = getParameterValues( parameters, reference_coordinate, i );
                bool                nice                 = analyzeMeasurementPoint( parameters, parameter_value_list );
                if ( nice == true )
                {
                    for ( int z = 0; z < coordinates.size(); z++ )
                    {
                        Coordinate*         coordinate            = coordinates[ z ];
                        std::vector<double> parameter_value_list2 = getParameterValues( parameters, coordinate, i );
                        bool                equal                 = compareParameterValues( parameter_value_list, parameter_value_list2 );
                        if ( equal == true )
                        {
                            coordinate_container.push_back( coordinate );
                        }
                    }
                    if ( coordinate_container.size() < min_measurement_points )
                    {
                        coordinate_container.clear();
                    }
                    else
                    {
                        //save the point row that was found
                        container.at( i ).push_back( coordinate_container );
                        coordinate_container.clear();
                    }
                }
            }
        }

        //remove the duplicates in the list
        std::vector<std::vector<CoordinateList> > copy_container;
        for ( int i = 0; i < container.size(); i++ )
        {
            std::vector<CoordinateList> tmp_container_list = container.at( i );
            std::vector<CoordinateList> copy_container_list;
            for ( int j = 0; j < tmp_container_list.size(); j++ )
            {
                if ( copy_container_list.size() == 0 )
                {
                    copy_container_list.push_back( tmp_container_list.at( j ) );
                }
                else
                {
                    bool           in_list   = false;
                    CoordinateList cord_list = tmp_container_list.at( j );
                    for ( int k = 0; k < copy_container_list.size(); k++ )
                    {
                        bool           are_equal  = true;
                        CoordinateList cord_list2 = copy_container_list.at( k );
                        for ( int l = 0; l < cord_list2.size(); l++ )
                        {
                            Coordinate* c1 = cord_list.at( l );
                            Coordinate* c2 = cord_list2.at( l );
                            if ( c1->toString() != c2->toString() )
                            {
                                are_equal = false;
                                break;
                            }
                        }
                        if ( are_equal == true )
                        {
                            in_list = true;
                            break;
                        }
                    }
                    if ( in_list == false )
                    {
                        copy_container_list.push_back( tmp_container_list.at( j ) );
                    }
                }
            }
            copy_container.push_back( copy_container_list );
        }

        //find the longest row for each parameter
        for ( int i = 0; i < copy_container.size(); i++ )
        {
            int                         id                 = 0;
            int                         list_size          = 0;
            std::vector<CoordinateList> tmp_container_list = copy_container.at( i );
            for ( int j = 0; j < tmp_container_list.size(); j++ )
            {
                CoordinateList tmp_list = tmp_container_list.at( j );
                if ( tmp_list.size() >= list_size )
                {
                    list_size = tmp_list.size();
                    id        = j;
                }
            }
            coordinate_container_list.push_back( tmp_container_list.at( id ) );
        }

        // print the result of the search
        if ( DEBUG == true )
        {
            for ( int i = 0; i < coordinate_container_list.size(); i++ )
            {
                Parameter parameter = parameters[ i ];
                std::cout << "Measurement Points for parameter: " << parameter.getName() << ".\n";
                CoordinateList cord_list = coordinate_container_list.at( i );
                for ( int j = 0; j < cord_list.size(); j++ )
                {
                    Coordinate* reference_coordinate = cord_list[ j ];
                    std::string temp                 = reference_coordinate->toString();
                    std::cout << temp << "\n";
                }
                std::cout << "\n";
            }
        }
    }
    else
    {
        ErrorStream << "Experiment contains a number of parameters that is currently not supported." << std::endl;
    }
    return coordinate_container_list;
}

std::vector<CoordinateList>
MultiParameterSparseFunctionModeler::findCheapestMeasurementPoints( const Experiment* parent_experiment, int min_measurement_points, const std::vector<DataPoint>& modeledDataPointList )
{
    bool DEBUG = false;

    //working copy of the data points list
    std::vector<DataPoint> copy_modeledDataPointList = modeledDataPointList;

    //the output list, will contain the final selected coordinates
    std::vector<CoordinateList> coordinate_container_list;

    //check the number of parameters
    ParameterList parameters = parent_experiment->getParameters();

    //create empty lists for the coordinate selection process
    std::vector<std::vector<CoordinateList> > container;
    for ( int i = 0; i < parameters.size(); i++ )
    {
        std::vector<CoordinateList> tmp_container_list;
        container.push_back( tmp_container_list );
    }

    if ( DEBUG == true )
    {
        //std::cout << "Number of parameters: " << parameters.size() << ".\n";
        for ( int i = 0; i < parameters.size(); i++ )
        {
            //std::cout << "parameter " << i << ": " << parameters.at( i ).getName() << std::endl;
        }
    }

    if ( parameters.size() == 1 )
    {
        ErrorStream << "Experiment contains not enough parameters. Minimum for this modeling approach is 2." << std::endl;
    }

    else if ( parameters.size() == 2 || parameters.size() == 3 )
    {
        CoordinateList coordinates_tmp = parent_experiment->getCoordinates();
        CoordinateList coordinates;

        //analyze the coordinate list, to filter duplicates in case there are some
        for ( int i = 0; i < coordinates_tmp.size(); i++ )
        {
            if ( i == 0 )
            {
                coordinates.push_back( coordinates_tmp.at( i ) );
            }
            else
            {
                bool found = false;
                for ( int j = 0; j < coordinates.size(); j++ )
                {
                    if ( coordinates.at( j )->toString() == coordinates_tmp.at( i )->toString() )
                    {
                        found = true;
                        break;
                    }
                }
                if ( found == false )
                {
                    coordinates.push_back( coordinates_tmp.at( i ) );
                }
            }
        }

        // debug print for the coordinates input
        if ( DEBUG == true )
        {
            //std::cout << "Number of Coordinates: " << coordinates.size() << ".\n";
            for ( int i = 0; i < coordinates.size(); i++ )
            {
                //std::cout << "Coordinate " << i << ": " << coordinates.at( i )->toString() << std::endl;
            }
        }

        //find point rows that have at least min points
        for ( int i = 0; i < parameters.size(); i++ )
        {
            Parameter      parameter = parameters[ i ];
            CoordinateList coordinate_container;
            for ( int j = 0; j < coordinates.size(); j++ )
            {
                Coordinate*         reference_coordinate = coordinates[ j ];
                std::vector<double> parameter_value_list = getParameterValues( parameters, reference_coordinate, i );
                bool                nice                 = analyzeMeasurementPoint( parameters, parameter_value_list );
                if ( nice == true )
                {
                    for ( int z = 0; z < coordinates.size(); z++ )
                    {
                        Coordinate*         coordinate            = coordinates[ z ];
                        std::vector<double> parameter_value_list2 = getParameterValues( parameters, coordinate, i );
                        bool                equal                 = compareParameterValues( parameter_value_list, parameter_value_list2 );
                        if ( equal == true )
                        {
                            coordinate_container.push_back( coordinate );
                        }
                    }
                    if ( coordinate_container.size() < min_measurement_points )
                    {
                        coordinate_container.clear();
                    }
                    else
                    {
                        //save the point row that was found
                        container.at( i ).push_back( coordinate_container );
                        coordinate_container.clear();
                    }
                }
            }
        }

        //remove the duplicates in the list
        std::vector<std::vector<CoordinateList> > copy_container;
        for ( int i = 0; i < container.size(); i++ )
        {
            std::vector<CoordinateList> tmp_container_list = container.at( i );
            std::vector<CoordinateList> copy_container_list;
            for ( int j = 0; j < tmp_container_list.size(); j++ )
            {
                if ( copy_container_list.size() == 0 )
                {
                    copy_container_list.push_back( tmp_container_list.at( j ) );
                }
                else
                {
                    bool           in_list   = false;
                    CoordinateList cord_list = tmp_container_list.at( j );
                    for ( int k = 0; k < copy_container_list.size(); k++ )
                    {
                        bool           are_equal  = true;
                        CoordinateList cord_list2 = copy_container_list.at( k );
                        for ( int l = 0; l < cord_list2.size(); l++ )
                        {
                            Coordinate* c1 = cord_list.at( l );
                            Coordinate* c2 = cord_list2.at( l );
                            if ( c1->toString() != c2->toString() )
                            {
                                are_equal = false;
                                break;
                            }
                        }
                        if ( are_equal == true )
                        {
                            in_list = true;
                            break;
                        }
                    }
                    if ( in_list == false )
                    {
                        copy_container_list.push_back( tmp_container_list.at( j ) );
                    }
                }
            }
            copy_container.push_back( copy_container_list );
        }

        //find the cheapest points for each parameter
        for ( int i = 0; i < copy_container.size(); i++ )
        {
            int                         id                 = 0;
            std::vector<CoordinateList> tmp_container_list = copy_container.at( i );
            double                      min_sum_cost       = 0;
            for ( int j = 0; j < tmp_container_list.size(); j++ )
            {
                double         sum_cost = 0;
                CoordinateList tmp_list = tmp_container_list.at( j );
                for ( int k = 0; k < tmp_list.size(); k++ )
                {
                    Coordinate* c        = tmp_list.at( k );
                    std::string c_string = c->toString();

                    std::vector<std::string> cord_parts;
                    std::string working_copy = c_string;
                    int pos = working_copy.find(")");
                    std::string tmp = working_copy.substr(0,pos+1);
                    cord_parts.push_back(tmp);
                    working_copy = working_copy.substr(pos+1,working_copy.length());
                    pos = working_copy.find(")");
                    tmp = working_copy.substr(0,pos+1);
                    cord_parts.push_back(tmp);
                    working_copy = working_copy.substr(pos+1,working_copy.length());
                    cord_parts.push_back(working_copy);

                    c_string = "";

                    for (int l = 0; l < parameters.size(); l++)
                    {
                        Parameter param = parameters.at(l);
                        std::string param_string = param.getName();
                        int paramid = -1;
                        int id = -1;
                        for (int o = 0; o < cord_parts.size(); o++)
                        {
                            paramid = cord_parts.at(o).find(param_string);
                            if (paramid!=-1){
                                id = o;
                            }
                        }
                        c_string = c_string + cord_parts.at(id);
                    }

                    //find the data point for this coordinate
                    double time = 0;
                    double p    = 0;
                    for ( int l = 0; l < copy_modeledDataPointList.size(); l++ )
                    {
                        DataPoint          dp  = copy_modeledDataPointList.at( l );
                        double             v   = dp.getValue();
                        std::string cord_string = "";
                        Parameter parameter0 = parameters.at( 0 );
                        double processes = dp.getParameterValue( parameter0 );

                        for (int o = 0; o < parameters.size(); o++)
                        {
                            Parameter parameter = parameters.at( o );
                            double parameter_value = dp.getParameterValue( parameter );
                            std::ostringstream strs;
                            strs << parameter_value;
                            std::string parameter_value_string = strs.str();
                            cord_string = cord_string + "(" + parameter.getName() + "," + parameter_value_string + ")";
                        }

                        if ( c_string == cord_string )
                        {
                            p    = processes;
                            time = v;
                            break;
                        }
                    }
                    //calculate cost for this coordinate
                    double cost = p * time;
                    sum_cost = sum_cost + cost;
                }
                //for the first iteration
                if (min_sum_cost == 0) {
                    min_sum_cost = sum_cost;
                    id           = j;
                }
                //check if the current sum_cost is lower, higher than the previous one
                //CHANGE THIS TO <,> TO USE CHEAP OR EXPENSIVE POINTS!!!
                else if ( sum_cost < min_sum_cost )
                {
                    min_sum_cost = sum_cost;
                    id           = j;
                }
            }
            //add the best solution found
            coordinate_container_list.push_back( tmp_container_list.at( id ) );
        }

        // print the result of the search
        if ( DEBUG == true )
        {
            for ( int i = 0; i < coordinate_container_list.size(); i++ )
            {
                Parameter parameter = parameters[ i ];
                std::cout << "Measurement Points for parameter: " << parameter.getName() << ".\n";
                CoordinateList cord_list = coordinate_container_list.at( i );
                for ( int j = 0; j < cord_list.size(); j++ )
                {
                    Coordinate* reference_coordinate = cord_list[ j ];
                    std::string temp                 = reference_coordinate->toString();
                    std::cout << temp << "\n";
                }
                std::cout << "\n";
            }
        }
    }
    else
    {
        ErrorStream << "Experiment contains a number of parameters that is currently not supported." << std::endl;
    }
    return coordinate_container_list;
}

std::vector<double>
MultiParameterSparseFunctionModeler::getParameterValues( ParameterList parameters, Coordinate* reference_coordinate, int parameter_id )
{
    std::vector<double> parameter_value_list;
    for ( int i = 0; i < parameters.size(); i++ )
    {
        if ( i != parameter_id )
        {
            Parameter parameter       = parameters[ i ];
            Value     parameter_value = reference_coordinate->at( parameter.getName() );
            parameter_value_list.push_back( parameter_value );
        }
    }
    return parameter_value_list;
}

bool
MultiParameterSparseFunctionModeler::compareParameterValues( std::vector<double> parameter_value_list1, std::vector<double> parameter_value_list2 )
{
    if ( parameter_value_list1.size() != parameter_value_list2.size() )
    {
        return false;
    }
    for ( int i = 0; i < parameter_value_list1.size(); i++ )
    {
        if ( parameter_value_list1.at( i ) != parameter_value_list2.at( i ) )
        {
            return false;
        }
    }
    return true;
}

bool
MultiParameterSparseFunctionModeler::analyzeMeasurementPoint( ParameterList parameters, std::vector<double> parameter_value_list )
{
    int n = parameters.size() - 1;
    if ( n == 2 )
    {
        if ( parameter_value_list.at( 0 ) == parameter_value_list.at( 1 ) )
        {
            return true;
        }
    }
    else
    {
        double value = parameter_value_list.at( 0 );
        for ( int i = 1; i < n; i++ )
        {
            if ( value != parameter_value_list.at( i ) )
            {
                return false;
            }
        }
    }
    return true;
}
}; // Close namespace
