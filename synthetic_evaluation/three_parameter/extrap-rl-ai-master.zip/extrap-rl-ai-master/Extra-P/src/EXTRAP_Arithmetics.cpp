/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <string.h>
#include <EXTRAP_Arithmetics.hpp>

namespace EXTRAP
{
Value
getMaxValueFromDatapoints( const Experiment&         experiment,
                           const Metric&             metric,
                           const Callpath&           callpath,
                           const int                 datapointType,
                           const ParameterValueList& maxParams )
{
    Value                     max    = 0;
    const ExperimentPointList points = experiment.getPoints( metric, callpath );
    for ( ExperimentPointList::const_iterator i = points.begin();
          i != points.end();
          i++ )
    {
        bool             in      = true;
        ExperimentPoint* current = *i;
        for ( ParameterValueList::const_iterator j = maxParams.begin();
              j != maxParams.end();
              j++ )
        {
            const Parameter param = j->first;
            Value           limit = j->second;
            if ( current->getParameterValue( param ) > limit )
            {
                in = false;
                break;
            }
        }

        if ( in && ( datapointType == 3 || datapointType == 6 ) )
        {
            max = current->getMaximum() > max ? current->getMaximum() : max;
        }

        else if ( in && datapointType == 1 )
        {
            max = current->getMinimum() > max ? current->getMinimum() : max;
        }

        else if ( in && datapointType == 2 )
        {
            max = current->getMean() > max ? current->getMean() : max;
        }

        else if ( in && datapointType == 4 )
        {
            max = current->getMedian() > max ? current->getMedian() : max;
        }

        else if ( in && datapointType == 5 )
        {
            max = current->getStandardDeviation() > max ? current->getStandardDeviation() : max;
        }
    }
    return max;
}
};
