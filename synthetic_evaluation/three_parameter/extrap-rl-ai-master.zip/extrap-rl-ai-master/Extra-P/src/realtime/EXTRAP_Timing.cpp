/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <realtime/EXTRAP_Timing.hpp>
#include <algorithm>
#include <sstream>
#include <mpi.h>
#include <fstream>

#ifdef USE_PAPI
#include <papi.h>
#endif

EXTRAPTiming::~EXTRAPTiming()
{
#ifdef USE_PAPI
    long long tmp[ 16 ];
    PAPI_stop( papi_set, tmp );
#endif
}

void
EXTRAPTiming::start( std::string const& name )
{
    // get or create timer
    EXTRAPTimingData& timer = timers[ name ];

    if ( !timer.started )
    {
        timer.started    = true;
        timer.start_time = MPI_Wtime();
        timer.prev_time  = timer.total_time;

#ifdef USE_PAPI
        int num_papi = papi_event.size();
        if ( num_papi > 0 )
        {
            if ( timer.papi_total.size() == 0 )
            {
                timer.papi_start_values.resize( num_papi, 0 );
                timer.papi_total.resize( num_papi, 0 );
            }

            /*
               // start timers
               PAPI_start_counters(&papi_event[0], num_papi);

               // clear timers
               long long tmp[16];
               PAPI_read_counters(tmp, num_papi);
             */

            // read initial values
            PAPI_read( papi_set, &timer.papi_start_values[ 0 ] );
        }
#endif
    }
}

void
EXTRAPTiming::stop( std::string const& name )
{
    // get or create timer
    EXTRAPTimingData& timer = timers[ name ];

    if ( timer.started )
    {
#ifdef USE_PAPI
        int num_papi = papi_event.size();
        if ( num_papi > 0 )
        {
            // read timers
            long long tmp[ 16 ];
            //PAPI_stop_counters(tmp, num_papi);
            PAPI_read( papi_set, tmp );

            // accumulate to all started timers (since this clears the PAPI values)
            for ( int i = 0; i < num_papi; ++i )
            {
                timer.papi_total[ i ] += tmp[ i ] - timer.papi_start_values[ i ];
            }
        }
#endif

        // Stop the timer
        timer.started     = false;
        timer.total_time += MPI_Wtime() - timer.start_time;
        timer.count++;
    }
}

void
EXTRAPTiming::stopAll( void )
{
    for ( TimerMap::iterator i = timers.begin(); i != timers.end(); ++i )
    {
        stop( ( *i ).first );
    }
}

void
EXTRAPTiming::clear( void )
{
    timers.clear();
}

const std::string
currentDateTime()
{
    time_t    now = time( 0 );
    struct tm tstruct;
    char      buf[ 80 ];
    tstruct = *localtime( &now );
    // Visit http://en.cppreference.com/w/cpp/chrono/c/strftime
    // for more information about date/time format
    strftime( buf, sizeof( buf ), "%Y-%m-%d.%X", &tstruct );

    return buf;
}

namespace
{
void
printTabVector( FILE* fp, std::vector<std::string> const& values )
{
    int len = values.size();
    for ( int i = 0; i < len; ++i )
    {
        if ( i > 0 )
        {
            fprintf( fp, "\t" );
        }
        fprintf( fp, "%s", values[ i ].c_str() );
    }
    fprintf( fp, "\n" );
}

template<typename T>
std::string
toString( T const& val )
{
    std::stringstream ss;
    ss << val;
    return ss.str();
}
}

double
EXTRAPTiming::getTime( std::string const& name ) const
{
    TimerMap::const_iterator i = timers.find( name );
    if ( i == timers.end() )
    {
        return 0.0;
    }
    return ( *i ).second.total_time - ( *i ).second.prev_time;
}

void
EXTRAPTiming::setPapiEvents( std::vector<std::string> names )
{
#ifdef USE_PAPI

    static bool papi_initialized = false;
    if ( !papi_initialized )
    {
        //printf("PAPI INIT\n");
        int retval = PAPI_library_init( PAPI_VER_CURRENT );
        papi_initialized = true;

        if ( retval != PAPI_VER_CURRENT )
        {
            fprintf( stderr, "ERROR INITIALIZING PAPI\n" );
            exit( 1 );
        }
    }

    //printf("PAPI VERSION=%x\n",
    //    PAPI_VERSION);

    papi_set = PAPI_NULL;
    PAPI_create_eventset( &papi_set );

    for ( int i = 0; i < names.size(); ++i )
    {
        // Convert text string to PAPI id
        int event_code;
        PAPI_event_name_to_code(
            const_cast<char*>( names[ i ].c_str() ),
            &event_code );

        // TODO: error checking?

        // Add to our list of PAPI events
        papi_names.push_back( names[ i ] );
        papi_event.push_back( event_code );

        int retval = PAPI_add_event( papi_set, event_code );
        if ( retval != PAPI_OK )
        {
            fprintf( stderr, "ERROR ADDING %s, retval=%d, ID=0x%-10x\n", names[ i ].c_str(), retval, event_code );
        }

        //printf("EVT=%s, ID=0x%-10x\n", names[i].c_str(), event_code);
    }
    PAPI_start( papi_set );
#else
    if ( names.size() > 0 )
    {
        fprintf( stderr, "WARNING: PAPI NOT ENABLED, IGNORING PAPI EVENTS\n" );
    }
#endif
}

EXTRAPTiming*                               ExtrapTimer::EXTRAP_TIMER = new EXTRAPTiming();
std::map<std::string, EXTRAPRealtimeModel*> ExtrapTimer::EXTRAP_MODELS;
