/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2016,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Fraction.hpp>
#include <iostream>
#include <cassert>

using namespace std;
using namespace EXTRAP;

string
toString( const Fraction& frac )
{
    stringstream returnValue;
    string       returnString;
    returnValue << frac;
    returnValue >> returnString;
    return returnString;
}

// This is defined as macro, not as function, to get helpful error messages in assert()
#define ASSERT_FRACTION_EQUAL( frac, str, value ) { \
        assert( ( frac ).eval() == value ); \
        assert( toString( frac ).compare( str ) == 0 ); \
}

int
main()
{
    // test evaluation and formatting
    ASSERT_FRACTION_EQUAL( Fraction( 1, 5 ), "1/5", 0.2 );
    ASSERT_FRACTION_EQUAL( Fraction( -1, 5 ), "-1/5", -0.2 );
    ASSERT_FRACTION_EQUAL( Fraction( 1, -5 ), "-1/5", -0.2 );
    ASSERT_FRACTION_EQUAL( Fraction( -1, -5 ), "1/5", 0.2 );
    ASSERT_FRACTION_EQUAL( Fraction( -10, 5 ), "-2", -2 );
    ASSERT_FRACTION_EQUAL( Fraction( 10, -5 ), "-2", -2 );
    ASSERT_FRACTION_EQUAL( Fraction( -10, -5 ), "2", 2 );
    ASSERT_FRACTION_EQUAL( Fraction( 0, -10 ), "0", 0 );

    // test copy and assignment construction
    Fraction f  = Fraction( 2, 1 );
    Fraction f2 = f;
    assert( f == f2 );

    // test overloaded operators
    ASSERT_FRACTION_EQUAL( f + Fraction( 5, 2 ), "9/2", 9. / 2 );
    ASSERT_FRACTION_EQUAL( f - Fraction( 5, 2 ), "-1/2", -1. / 2 );
    ASSERT_FRACTION_EQUAL( f * Fraction( 5, 2 ), "5", 5 );
    ASSERT_FRACTION_EQUAL( f / Fraction( 5, 2 ), "4/5", 4. / 5 );
    ASSERT_FRACTION_EQUAL( -Fraction( 5, 2 ), "-5/2", -5. / 2 );
    assert( ( Fraction( 2, 3 ) < Fraction( 3, 3 ) ) == true );
    assert( ( Fraction( 3, 3 ) < Fraction( 3, 3 ) ) == false );
    assert( ( Fraction( 3, 3 ) == Fraction( 9, 9 ) ) == true );
    assert( ( Fraction( 3, 3 ) == Fraction( 10, 9 ) ) == false );
    assert( ( Fraction( 3, 3 ) != Fraction( 9, 9 ) ) == false );

    // test integral_part() and fractional_part() functions
    assert( Fraction( 10, 7 ).integral_part() == 1 );
    assert( Fraction( 14, 7 ).integral_part() == 2 );
    assert( Fraction( 0, 1 ).integral_part() == 0 );
    assert( Fraction( 7, 7 ).integral_part() == 1 );
    assert( Fraction( -7, 7 ).integral_part() == -1 );
    assert( Fraction( -10, 7 ).integral_part() == -1 );
    assert( Fraction( -14, 7 ).integral_part() == -2 );

    assert( Fraction( 10, 7 ).fractional_part() == Fraction( 3, 7 ) );
    assert( Fraction( 14, 7 ).fractional_part() == Fraction( 0, 1 ) );
    assert( Fraction( 0, 1 ).fractional_part() == Fraction( 0, 1 ) );
    assert( Fraction( 7, 7 ).fractional_part() == Fraction( 0, 1 ) );
    assert( Fraction( -7, 7 ).fractional_part() == Fraction( 0, 1 ) );
    assert( Fraction( -10, 7 ).fractional_part() == Fraction( -3, 7 ) );
    assert( Fraction( -14, 7 ).fractional_part() == Fraction( 0, 1 ) );

    // test approximate() function
    std::cout.precision( 10 );
    assert( Fraction::approximate( -2. / 3 ) == Fraction( -2, 3 ) );
    assert( Fraction::approximate( 5. / -3 ) == Fraction( 5, -3 ) );
    assert( Fraction::approximate( 1997. / 2000 ) == Fraction( 1997, 2000 ) );
    assert( std::abs( Fraction::approximate( M_PI ).eval() - M_PI ) <= 1e-10 );

    // test approximate_farey() function
    assert( Fraction::approximate_farey( 0.0, 5 ) == Fraction( 0, 1 ) );
    assert( Fraction::approximate_farey( 2.0, 5 ) == Fraction( 2, 1 ) );
    assert( Fraction::approximate_farey( 5.2, 5 ) == Fraction( 26, 5 ) );
    assert( Fraction::approximate_farey( -2.0, 5 ) == Fraction( -2, 1 ) );
    assert( Fraction::approximate_farey( 2. / 3, 5 ) == Fraction( 2, 3 ) );
    assert( Fraction::approximate_farey( -2. / 3, 5 ) == Fraction( -2, 3 ) );
    assert( Fraction::approximate_farey( 5. / -3, 5 ) == Fraction( 5, -3 ) );
}
