/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2016-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stdio.h>
#include <iostream>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>
#include <cassert>

using namespace std;
int
main()
{
    EXTRAP::SingleParameterSimpleModelGenerator* bob = new EXTRAP::SingleParameterSimpleModelGenerator();
    EXTRAP::ExperimentPointList                  input;
    EXTRAP::Interval                             interval;
    interval.start = 0;
    interval.end   = 0;
    EXTRAP::Parameter*    param = new EXTRAP::Parameter( "p" );
    EXTRAP::ParameterList paramlist;
    paramlist.push_back( *param );
    EXTRAP::Coordinate pvl1, pvl2, pvl3, pvl4, pvl5;
    pvl1.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 1 ) );
    pvl2.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 2 ) );
    pvl3.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 3 ) );
    pvl4.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 4 ) );
    pvl5.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 5 ) );
    double                   y1 = 50 + 10;
    double                   y2 = 100 + 40;
    double                   y3 = 150 + 90;
    double                   y4 = 200 + 160;
    double                   y5 = 250 + 250;
    EXTRAP::ExperimentPoint* i1 = new EXTRAP::ExperimentPoint( &pvl1, 1, y1, interval, 0, y1, interval, y1, y1, NULL, NULL );
    EXTRAP::ExperimentPoint* i2 = new EXTRAP::ExperimentPoint( &pvl2, 1, y2, interval, 0, y2, interval, y2, y2, NULL, NULL );
    EXTRAP::ExperimentPoint* i3 = new EXTRAP::ExperimentPoint( &pvl3, 1, y3, interval, 0, y3, interval, y3, y3, NULL, NULL );
    EXTRAP::ExperimentPoint* i4 = new EXTRAP::ExperimentPoint( &pvl4, 1, y4, interval, 0, y4, interval, y4, y4, NULL, NULL );
    EXTRAP::ExperimentPoint* i5 = new EXTRAP::ExperimentPoint( &pvl5, 1, y5, interval, 0, y5, interval, y5, y5, NULL, NULL );
    input.push_back( i1 );
    input.push_back( i2 );
    input.push_back( i3 );
    input.push_back( i4 );
    input.push_back( i5 );
    EXTRAP::CompoundTerm t1, t2, t3, t4, t5;
    t1.setCoefficient( 42 );
    EXTRAP::SimpleTerm   s1, s2, s3;
    EXTRAP::FunctionType poly = EXTRAP::polynomial;
    EXTRAP::FunctionType log  = EXTRAP::logarithm;

    s1.setFunctionType( poly );
    s1.setExponent( 1 );
    s2.setFunctionType( poly );
    s2.setExponent( 2 );
    s3.setFunctionType( log );
    s3.setExponent( 1 );
    t1.addSimpleTerm( s3 );
    t2.addSimpleTerm( s1 );
    t3.addSimpleTerm( s2 );
    t4.addSimpleTerm( s3 );
    t4.addSimpleTerm( s1 );
    t5.addSimpleTerm( s3 );
    t5.addSimpleTerm( s2 );
    t1.setCoefficient( 1 );
    t2.setCoefficient( 1 );
    t3.setCoefficient( 1 );
    t4.setCoefficient( 1 );
    t5.setCoefficient( 1 );

    bob->addHypothesisBuildingBlock( t1 );
    bob->addHypothesisBuildingBlock( t2 );
    bob->addHypothesisBuildingBlock( t3 );
    bob->addHypothesisBuildingBlock( t4 );
    bob->addHypothesisBuildingBlock( t5 );
    bob->printHypothesisBuildingBlocks();
    bob->setMaxTermCount( 2 );
    DebugStream << "=== No crossvalidation ===" << endl;
    bob->setCrossvalidationMethod( EXTRAP::CROSSVALIDATION_NONE );

    //test
    EXTRAP::Experiment* exp;

    EXTRAP::ModelGeneratorOptions options = EXTRAP::ModelGeneratorOptions();

    EXTRAP::Model* m1 = bob->createModel( exp, options, input, NULL );
    DebugStream << "Selected model: " << dynamic_cast<EXTRAP::SingleParameterFunction*>( m1->getModelFunction() )->getAsString( "p" ) << endl;
    DebugStream << "=== Leave-one-out crossvalidation ===" << endl;
    bob->setCrossvalidationMethod( EXTRAP::CROSSVALIDATION_LEAVE_ONE_OUT );
    EXTRAP::Model* m2 = bob->createModel( exp, options, input, NULL );
    DebugStream << "Selected model: " << dynamic_cast<EXTRAP::SingleParameterFunction*>( m2->getModelFunction() )->getAsString( "p" ) << endl;
    assert( m2->getComments().empty() );
    delete i1;
    delete i2;
    delete i3;
    delete i4;
    delete i5;

    // read experiment file
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/experiment4.txt" );
    assert( experiment != NULL );
    delete experiment;
    std::cout << "Test reading wrong experiment" << std::endl;
    //read wrong experiment (too many parameters)
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/experiment3.txt" );
    assert( experiment2 == NULL );
    //read wrong experiment(missing a parameter)
    EXTRAP::Experiment* experiment3 = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/experiment.txt" );
    assert( experiment3 == NULL );
    return 0;
}
