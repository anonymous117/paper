/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

//#include <config.h>
#include <iostream>
#include <cassert>
#include <ctime>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <map>

#include <EXTRAP_SingleParameterRefiningModelGenerator.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <EXTRAP_MultiParameterSimpleModelGenerator.hpp>
#include <EXTRAP_Experiment.hpp>


void
printCallpath( EXTRAP::Experiment* experiment, const std::string& cpath_fname )
{
    const EXTRAP::CallpathList& callpaths = experiment->getAllCallpaths();

    std::ofstream outfile( cpath_fname.c_str() );

    for ( EXTRAP::CallpathList::const_iterator callpath_it = callpaths.begin();
          callpath_it != callpaths.end();
          ++callpath_it )
    {
        EXTRAP::Callpath* callpath = *callpath_it;
        outfile << callpath->getFullName() << std::endl;
    }

    outfile.close();
}


void
printModels( EXTRAP::Experiment* experiment, const std::string& out_fname, unsigned int nparams )
{
    EXTRAP::MetricList           metrics        = experiment->getMetrics();
    EXTRAP::CallpathList         callpaths      = experiment->getAllCallpaths();
    const EXTRAP::ParameterList& parameterNames = experiment->getParameters();

    std::ofstream outfile( out_fname.c_str() );

    outfile << "Metric name, cnode, model, no. terms, AR2, SMAPE" << std::endl;

    for ( EXTRAP::MetricList::iterator metric_it = metrics.begin();
          metric_it != metrics.end();
          ++metric_it )
    {
        EXTRAP::Metric* metric = *metric_it;
        for ( EXTRAP::CallpathList::iterator callpath_it = callpaths.begin();
              callpath_it != callpaths.end();
              ++callpath_it )
        {
            EXTRAP::Callpath* callpath = *callpath_it;

            const EXTRAP::ModelList& model_list = experiment->getModels( *metric, *callpath );

            if ( nparams == 1 )
            {
                EXTRAP::SingleParameterFunction* function =
                    dynamic_cast<EXTRAP::SingleParameterFunction*>( model_list[ 0 ]->getModelFunction() );
                outfile << metric->getName() << ", "
                        << callpath->getFullName() << ", "
                        << function->getAsString( parameterNames ) << ", "
                        << function->getCompoundTerms().size() << ", "
                        << model_list[ 0 ]->getAR2() << ", "
                        << model_list[ 0 ]->getSMAPE()
                        << std::endl;
            }
            else
            {
                EXTRAP::MultiParameterFunction* function =
                    dynamic_cast<EXTRAP::MultiParameterFunction*>( model_list[ 0 ]->getModelFunction() );
                outfile << metric->getName() << ", "
                        << callpath->getFullName() << ", "
                        << function->getAsString( parameterNames ) << ", "
                        << function->getMultiParameterTerms().size() << ", "
                        << model_list[ 0 ]->getAR2() << ", "
                        << model_list[ 0 ]->getSMAPE()
                        << std::endl;
            }
        }
    }

    outfile.close();
}


int
main( int argc, char* argv[] )
{
    if ( argc < 3 )
    {
        std::cout << "Usage: mparam_model <input file> <output file>" << std::endl;
        std::exit( -1 );
    }

    EXTRAP::Experiment*     mparam_experiment = EXTRAP::Experiment::openTextInput( argv[ 1 ] );
    EXTRAP::MetricList      metrics           = mparam_experiment->getMetrics();
    EXTRAP::CallpathList    callpaths         = mparam_experiment->getAllCallpaths();
    EXTRAP::ModelGenerator* model_generator   = NULL;
    unsigned int            nparams           = mparam_experiment->getParameters().size();

    if ( nparams == 1 )
    {
        EXTRAP::SingleParameterSimpleModelGenerator* single_generator =
            new EXTRAP::SingleParameterSimpleModelGenerator();
        single_generator->setEpsilon( 0.05 );
        single_generator->setMaxTermCount( 1 );
        single_generator->generateDefaultHypothesisBuildingBlockSet();
        model_generator = single_generator;
    }
    else
    {
        EXTRAP::MultiParameterSimpleModelGenerator* mparam_generator =
            new EXTRAP::MultiParameterSimpleModelGenerator();
        mparam_generator->setModelOptions( EXTRAP::GENERATE_MODEL_MEDIAN );
        model_generator = mparam_generator;
    }

    mparam_experiment->addModelGenerator( model_generator );
    mparam_experiment->modelAll( *model_generator );

    printModels( mparam_experiment, argv[ 2 ], nparams );

    delete mparam_experiment;

    return 0;
}
