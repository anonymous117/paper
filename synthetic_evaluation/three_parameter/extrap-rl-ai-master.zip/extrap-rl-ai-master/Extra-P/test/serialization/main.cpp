/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stdio.h>
#include <iostream>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <cassert>
#include <climits>
#include <cstring>
#include <EXTRAP_CubeFileReader.hpp>
#include <EXTRAP_Coordinate.hpp>
#include <EXTRAP_IoHelper.hpp>
#include <ctime>
#include <cmath>

using namespace std;

void
testRegions( void )
{
    EXTRAP::Region* reg1 = new EXTRAP::Region( "reg1", "main.cpp", 5 );
    reg1->setId( 1 );
    EXTRAP::Region* reg2 = new EXTRAP::Region( "reg2", "foo.cpp", 25 );
    reg2->setId( 2 );
    EXTRAP::Region* reg3 = new EXTRAP::Region( "reg3", "bar.cpp", 51 );
    reg3->setId( 3 );
    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out );
    reg1->serialize( &ioHelper );
    reg2->serialize( &ioHelper );
    reg3->serialize( &ioHelper );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::Region* reg1clone = EXTRAP::Region::deserialize(  &ioHelper );
    ioHelper.readString();
    EXTRAP::Region* reg2clone = EXTRAP::Region::deserialize(  &ioHelper );
    ioHelper.readString();
    EXTRAP::Region* reg3clone = EXTRAP::Region::deserialize(  &ioHelper );
    in.close();
    assert( equal( reg1clone, reg1 ) );
    assert( equal( reg2clone, reg2 ) );
    assert( equal( reg3clone, reg3 ) );
    remove( "output.bin" );
    delete( reg1clone );
    delete( reg2clone );
    delete( reg3clone );
    delete( reg1 );
    delete( reg2 );
    delete( reg3 );
}

void
testMetrics( void )
{
    EXTRAP::Metric* met1 = new EXTRAP::Metric( "met1", "processors" );
    met1->setId( 4 );
    EXTRAP::Metric* met2 = new EXTRAP::Metric( "met2", "fpops" );
    met2->setId( 5 );
    EXTRAP::Metric* met3 = new EXTRAP::Metric( "met3", "fpadds" );
    met3->setId( 6 );
    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out );
    met1->serialize(  &ioHelper );
    met2->serialize(  &ioHelper );
    met3->serialize(  &ioHelper );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::Metric* met1clone = EXTRAP::Metric::deserialize( &ioHelper );
    ioHelper.readString();
    EXTRAP::Metric* met2clone = EXTRAP::Metric::deserialize( &ioHelper );
    ioHelper.readString();
    EXTRAP::Metric* met3clone = EXTRAP::Metric::deserialize( &ioHelper );
    in.close();
    assert( equal( met1clone, met1 ) );
    assert( equal( met2clone, met2 ) );
    assert( equal( met3clone, met3 ) );
    remove( "output.bin" );
    delete( met1clone );
    delete( met2clone );
    delete( met3clone );
    delete( met1 );
    delete( met2 );
    delete( met3 );
}

void
testParameters( void )
{
    EXTRAP::Parameter p1 = EXTRAP::Parameter( "parameter1" );
    p1.setId( 7 );
    EXTRAP::Parameter p2 = EXTRAP::Parameter( "parameter2" );
    p2.setId( 8 );
    EXTRAP::Parameter p3 = EXTRAP::Parameter( "parameter3" );
    p3.setId( 9 );
    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out );
    p1.serialize(  &ioHelper );
    p2.serialize(  &ioHelper );
    p3.serialize(  &ioHelper );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::Parameter p1clone = EXTRAP::Parameter::deserialize(  &ioHelper );
    ioHelper.readString();
    EXTRAP::Parameter p2clone = EXTRAP::Parameter::deserialize(  &ioHelper );
    ioHelper.readString();
    EXTRAP::Parameter p3clone = EXTRAP::Parameter::deserialize(  &ioHelper );
    in.close();
    remove( "output.bin" );
    assert( equal( &p1clone, &p1 ) );
    assert( equal( &p2clone, &p2 ) );
    assert( equal( &p3clone, &p3 ) );
}

void
testCallpaths( void )
{
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();
    EXTRAP::Region*     reg1       = new EXTRAP::Region( "reg1", "main.cpp", 5 );
    EXTRAP::Region*     reg2       = new EXTRAP::Region( "reg2", "foo.cpp", 25 );
    EXTRAP::Region*     reg3       = new EXTRAP::Region( "reg3", "bar.cpp", 51 );
    experiment->addRegion( reg1 );
    experiment->addRegion( reg2 );
    experiment->addRegion( reg3 );
    EXTRAP::Callpath* cp1 = new EXTRAP::Callpath( reg1, NULL );
    EXTRAP::Callpath* cp2 = new EXTRAP::Callpath( reg2, cp1 );
    EXTRAP::Callpath* cp3 = new EXTRAP::Callpath( reg3, cp1 );
    std::ofstream     out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper  ioHelper = EXTRAP::IoHelper( &out );
    cp1->serialize( &ioHelper );
    cp2->serialize(  &ioHelper );
    cp3->serialize(  &ioHelper );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::Callpath* cp1clone = EXTRAP::Callpath::deserialize(  experiment, &ioHelper );
    experiment->addCallpath( cp1clone );
    ioHelper.readString();
    EXTRAP::Callpath* cp2clone = EXTRAP::Callpath::deserialize( experiment, &ioHelper );
    experiment->addCallpath( cp2clone );
    ioHelper.readString();
    EXTRAP::Callpath* cp3clone = EXTRAP::Callpath::deserialize( experiment, &ioHelper );
    experiment->addCallpath( cp3clone );
    in.close();
    remove( "output.bin" );
    assert( equal( cp1, cp1clone ) );
    assert( equal( cp2, cp2clone ) );
    assert( equal( cp3, cp3clone ) );
    delete( experiment );
}

void
test( void ( * f )( void ) )
{
    ( *f )();
}

void
testCoordinates()
{
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();
    EXTRAP::Parameter*  p1         = new EXTRAP::Parameter( "parameter1" );
    experiment->addParameter( *p1 );
    EXTRAP::Parameter* p2 = new EXTRAP::Parameter( "parameter2" );
    experiment->addParameter( *p2 );
    EXTRAP::Coordinate* c11 = new EXTRAP::Coordinate();
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 1 ) );
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 1 ) );
    experiment->addCoordinate( c11 );
    EXTRAP::Coordinate* c21 = new EXTRAP::Coordinate();
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 2 ) );
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 1 ) );
    experiment->addCoordinate( c21 );
    EXTRAP::Coordinate* c12 = new EXTRAP::Coordinate();
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 1 ) );
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 2 ) );
    experiment->addCoordinate( c12 );
    EXTRAP::Coordinate* c22 = new EXTRAP::Coordinate();
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 2 ) );
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 2 ) );
    experiment->addCoordinate( c22 );
    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out );
    c11->serialize(  &ioHelper );
    c21->serialize(  &ioHelper );
    c12->serialize(  &ioHelper );
    c22->serialize(  &ioHelper );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::Coordinate* c11clone = EXTRAP::Coordinate::deserialize(  experiment, &ioHelper );
    ioHelper.readString();
    EXTRAP::Coordinate* c21clone = EXTRAP::Coordinate::deserialize(  experiment, &ioHelper );
    ioHelper.readString();
    EXTRAP::Coordinate* c12clone = EXTRAP::Coordinate::deserialize(  experiment, &ioHelper );
    ioHelper.readString();
    EXTRAP::Coordinate* c22clone = EXTRAP::Coordinate::deserialize(  experiment, &ioHelper );
    in.close();
    remove( "output.bin" );
    assert( equal( c11clone, c11 ) );
    assert( equal( c21clone, c21 ) );
    assert( equal( c12clone, c12 ) );
    assert( equal( c22clone, c22 ) );
    delete( experiment );
}

void
testExperimentPoints( void )
{
    EXTRAP::Experiment* experiment = new EXTRAP::Experiment();
    EXTRAP::Parameter*  p1         = new EXTRAP::Parameter( "parameter1" );
    EXTRAP::Parameter*  p2         = new EXTRAP::Parameter( "parameter2" );
    experiment->addParameter( *p1 );
    experiment->addParameter( *p2 );
    EXTRAP::Coordinate* c11 = new EXTRAP::Coordinate();
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 1 ) );
    c11->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 1 ) );
    EXTRAP::Coordinate* c21 = new EXTRAP::Coordinate();
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 2 ) );
    c21->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 1 ) );
    EXTRAP::Coordinate* c12 = new EXTRAP::Coordinate();
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 1 ) );
    c12->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 2 ) );
    EXTRAP::Coordinate* c22 = new EXTRAP::Coordinate();
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p1, 2 ) );
    c22->insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *p2, 2 ) );
    experiment->addCoordinate( c11 );
    experiment->addCoordinate( c21 );
    experiment->addCoordinate( c12 );
    experiment->addCoordinate( c22 );

    EXTRAP::Metric* met1 = new EXTRAP::Metric( "met1", "processors" );
    EXTRAP::Metric* met2 = new EXTRAP::Metric( "met2", "fpops" );
    EXTRAP::Metric* met3 = new EXTRAP::Metric( "met3", "fpadds" );
    experiment->addMetric( met1 );
    experiment->addMetric( met2 );
    experiment->addMetric( met3 );


    EXTRAP::Region* reg1 = new EXTRAP::Region( "reg1", "main.cpp", 5 );
    EXTRAP::Region* reg2 = new EXTRAP::Region( "reg2", "foo.cpp", 25 );
    EXTRAP::Region* reg3 = new EXTRAP::Region( "reg3", "bar.cpp", 51 );
    experiment->addRegion( reg1 );
    experiment->addRegion( reg2 );
    experiment->addRegion( reg3 );

    EXTRAP::Callpath* cp1 = new EXTRAP::Callpath( reg1, NULL );
    EXTRAP::Callpath* cp2 = new EXTRAP::Callpath( reg1, cp1 );
    EXTRAP::Callpath* cp3 = new EXTRAP::Callpath( reg1, cp1 );
    experiment->addCallpath( cp1 );
    experiment->addCallpath( cp2 );
    experiment->addCallpath( cp3 );
    EXTRAP::Interval meanCI1;
    meanCI1.start = 1.0;
    meanCI1.end   = 1.0;
    EXTRAP::Interval meanCI2;
    meanCI2.start = 2.0;
    meanCI2.end   = 2.0;
    EXTRAP::Interval meanCI3;
    meanCI3.start = 3.0;
    meanCI3.end   = 3.0;
    EXTRAP::Interval medianCI1;
    medianCI1.start = 1.0;
    medianCI1.end   = 1.0;
    EXTRAP::Interval medianCI2;
    medianCI2.start = 2.0;
    medianCI2.end   = 2.0;
    EXTRAP::Interval medianCI3;
    medianCI3.start = 3.0;
    medianCI3.end   = 3.0;
    EXTRAP::ExperimentPoint* exP1 = new EXTRAP::ExperimentPoint( c11, 1, 1.0, meanCI1, 1.0, 1.0, medianCI1, 1.0, 1.0, cp1, met1 );
    EXTRAP::ExperimentPoint* exP2 = new EXTRAP::ExperimentPoint( c12, 2, 2.0, meanCI2, 2.0, 2.0, medianCI2, 2.0, 2.0, cp2, met2 );
    EXTRAP::ExperimentPoint* exP3 = new EXTRAP::ExperimentPoint( c21, 3, 3.0, meanCI3, 3.0, 3.0, medianCI3, 3.0, 3.0, cp3, met3 );

    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out );
    exP1->serialize(  &ioHelper );
    exP2->serialize(  &ioHelper );
    exP3->serialize(  &ioHelper );
    out.close();

    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::ExperimentPoint* exP1clone = EXTRAP::ExperimentPoint::deserialize( experiment, &ioHelper );
    ioHelper.readString();
    EXTRAP::ExperimentPoint* exP2clone = EXTRAP::ExperimentPoint::deserialize( experiment, &ioHelper );
    ioHelper.readString();
    EXTRAP::ExperimentPoint* exP3clone = EXTRAP::ExperimentPoint::deserialize( experiment, &ioHelper );
    in.close();
    assert( equal( exP1, exP1clone ) );
    assert( equal( exP2, exP2clone ) );
    assert( equal( exP3, exP3clone ) );
    remove( "output.bin" );
    delete( experiment );
}

void
testSingleParameterSimpleModelGenerator( void )
{
    EXTRAP::SingleParameterSimpleModelGenerator* bob = new EXTRAP::SingleParameterSimpleModelGenerator();
    EXTRAP::CompoundTerm                         t1, t2, t3, t4, t5;
    t1.setCoefficient( 42 );
    EXTRAP::SimpleTerm   s1, s2, s3;
    EXTRAP::FunctionType poly = EXTRAP::polynomial;
    EXTRAP::FunctionType log  = EXTRAP::logarithm;

    s1.setFunctionType( poly );
    s1.setExponent( 1 );
    s2.setFunctionType( poly );
    s2.setExponent( 2 );
    s3.setFunctionType( log );
    s3.setExponent( 3 );
    t1.addSimpleTerm( s3 );
    t2.addSimpleTerm( s1 );
    t3.addSimpleTerm( s2 );
    t4.addSimpleTerm( s3 );
    t4.addSimpleTerm( s1 );
    t5.addSimpleTerm( s3 );
    t5.addSimpleTerm( s2 );
    t1.setCoefficient( 1 );
    t2.setCoefficient( 1 );
    t3.setCoefficient( 1 );
    t4.setCoefficient( 1 );
    t5.setCoefficient( 1 );
    bob->addHypothesisBuildingBlock( t1 );
    bob->addHypothesisBuildingBlock( t2 );
    bob->addHypothesisBuildingBlock( t3 );
    bob->addHypothesisBuildingBlock( t4 );
    bob->addHypothesisBuildingBlock( t5 );
    bob->setMaxTermCount( 2 );
    bob->setCrossvalidationMethod( EXTRAP::CROSSVALIDATION_LEAVE_ONE_OUT );
    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out );
    bob->serialize(  &ioHelper );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    ioHelper.readString();
    EXTRAP::SingleParameterSimpleModelGenerator* alice = EXTRAP::SingleParameterSimpleModelGenerator::deserialize(  &ioHelper );
    in.close();
    remove( "output.bin" );
    assert( equal( alice, bob ) );
    delete( bob );
    delete( alice );
}

void
testExperiments( void )
{
    EXTRAP::Experiment* experiment = EXTRAP::Experiment::openTextInput( EXTRAP_TEST_DIR "/data/experiment2.txt" );
    std::ofstream       out( "output.bin", std::ofstream::binary );
    experiment->serialize( out );
    out.close();
    std::ifstream       in( "output.bin", std::ifstream::binary );
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::deserialize( in );
    in.close();
    remove( "output.bin" );
    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( experiment2 );
    std::ifstream in2( EXTRAP_TEST_DIR "/data/experimentFiles/milc.extrap", std::ifstream::binary );
    assert( EXTRAP::Experiment::deserialize( in2 ) != NULL );
    std::ifstream in3( EXTRAP_TEST_DIR "/data/experimentFiles/scorep", std::ifstream::binary );
    assert( EXTRAP::Experiment::deserialize( in3 ) != NULL );
}

void
testCubeFileReaderSerializationDeserialization( void )
{
    std::vector<int> values;
    values.push_back( 1 );
    values.push_back( 10 );
    values.push_back( 25 );
    EXTRAP::Parameter       parX = EXTRAP::Parameter( "p" );
    EXTRAP::Parameter       parY = EXTRAP::Parameter( "size" );
    EXTRAP::Parameter       parZ = EXTRAP::Parameter( "z" );
    EXTRAP::CubeFileReader* cfr  = new EXTRAP::CubeFileReader();
    cfr->prepareCubeFileReader( 3, EXTRAP_TEST_DIR "/data", "mm.", "", "profile.cubex", 1 );
    cfr->addParameter( parX, "x", values );
    cfr->addParameter( parY, "y", values );
    cfr->addParameter( parY, "z", values );
    EXTRAP::Experiment* experiment = cfr->readCubeFiles( 1 );
    if ( experiment == NULL )
    {
        std::cerr << "[EXTRA-P] Error: Failed to read Cube file." << std::endl;
        exit( 1 );
    }
    std::ofstream out( "output.bin", std::ofstream::binary );
    experiment->serialize( out );
    out.close();
    std::ifstream       in( "output.bin", std::ifstream::binary );
    EXTRAP::Experiment* experiment2 = EXTRAP::Experiment::deserialize( in );
    in.close();
    remove( "output.bin" );
    assert( equal( experiment, experiment2 ) );
    delete( experiment );
    delete( cfr );
    delete( experiment2 );
}

int64_t
invertInt( int val )
{
    int64_t value64 = val;
    char    arr[ 8 ];
    memcpy( arr, &value64, 8 );
    char rev[ 8 ];
    for ( int i = 0; i < 8; i++ )
    {
        rev[ i ] = arr[ 8 - 1 - i ];
    }
    std::memcpy( &value64, rev, 8 );
    return value64;
}

EXTRAP::Value
invertValue( EXTRAP::Value val )
{
    int           valueSize = sizeof( EXTRAP::Value );
    EXTRAP::Value value;
    char          arr[ valueSize ];
    memcpy( arr, &val, valueSize );
    char rev[ valueSize ];
    for ( int i = 0; i < valueSize; i++ )
    {
        rev[ i ] = arr[ valueSize - 1 - i ];
    }
    std::memcpy( &value, rev, valueSize );
    return value;
}

void
testEndianness()
{
    EXTRAP::Value    val             = 3.1416;
    EXTRAP::Value    valInv          = invertValue( val );
    int              intMax          = INT_MAX;
    int              intMin          = INT_MIN;
    int              intSomething    = 31416;
    int64_t          intMaxInv       = invertInt( intMax );
    int64_t          intMinInv       = invertInt( intMin );
    int64_t          intSomethingInv = invertInt( intSomething );
    std::ofstream    out( "output.bin", std::ofstream::binary );
    EXTRAP::IoHelper ioHelper = EXTRAP::IoHelper( &out, true );
    ioHelper.writeValue(  valInv );
    ioHelper.writeInt(  intMaxInv );
    ioHelper.writeInt(  intMinInv );
    ioHelper.writeInt(  intSomethingInv );
    out.close();
    std::ifstream in( "output.bin", std::ifstream::binary );
    ioHelper = EXTRAP::IoHelper( &in );
    EXTRAP::Value v              = ioHelper.readValue();
    int           intMaxIn       = ioHelper.readInt();
    int           intMinIn       = ioHelper.readInt();
    int           intSomethingIn = ioHelper.readInt();
    in.close();
    assert( intMax == intMaxIn );
    assert( intMin == intMinIn );
    assert( intSomething == intSomethingIn );
    assert( val == v );
}

int
main()
{
    std::cout << "Starting Serialization Test Suite" << std::endl;
    test( &testRegions );
    std::cout << "RegionTest was successfull" << std::endl;
    test( &testMetrics );
    std::cout << "MetricTest was successfull" << std::endl;
    test( &testParameters );
    std::cout << "ParameterTest was successfull" << std::endl;
    test( &testCallpaths );
    std::cout << "CallpathTest was successfull" << std::endl;
    test( &testCoordinates );
    std::cout << "CoordinateTest was successfull" << std::endl;
    test( &testExperimentPoints );
    std::cout << "ExperimentPointTest was successfull" << std::endl;
    /**
     * deactivated, because fails with the new configuration of the simplefunction modeler for the sparse modeler
     * needs to be fixed later!!!
       test( &testSingleParameterSimpleModelGenerator );
       std::cout << "SingleParameterSimpleModelGeneratorTest was successfull" << std::endl;
     **/
    test( &testExperiments );
    std::cout << "ExperimentsTest was successfull" << std::endl;
    test( &testCubeFileReaderSerializationDeserialization );
    std::cout << "CubeFileReader Serialization & Deserialization Test was successfull" << std::endl;
    test( &testEndianness );
    std::cout << "EndiannessTest was successfull" << std::endl;
    std::cout << "Serialization Test Suite was completed" << std::endl;
    return 0;
}
