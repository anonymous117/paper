/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_METRIC_HPP
#define EXTRAP_METRIC_HPP

#include <string>
#include <vector>
#include <set>
#include <map>
#include <fstream>
#include <cassert>

namespace EXTRAP
{
class Metric
{
public:

    static const std::string METRIC_PREFIX;
    Metric( const std::string& name,
            const std::string& unit );
    virtual
    ~Metric();
    virtual std::string
    getName( void ) const;
    virtual std::string
    getUnit( void ) const;
    int64_t
    getId( void ) const;
    void
    setId( int64_t id );
    virtual bool
    serialize(
        IoHelper* ioHelper ) const;
    static Metric*
    deserialize(
        IoHelper* ioHelper );

protected:
    std::string m_name;
    std::string m_unit;

private:
    int64_t m_id;
};
bool
equal( const Metric* lhs,
       const Metric* rhs );

bool
less( const Metric* lhs,
      const Metric* rhs );

typedef std::vector<Metric*> MetricList;
};

#endif
