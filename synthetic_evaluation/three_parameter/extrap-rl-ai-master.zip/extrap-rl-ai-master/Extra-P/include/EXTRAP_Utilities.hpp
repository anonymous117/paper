/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_UTILITIES_H
#define EXTRAP_UTILITIES_H

#include <EXTRAP_MessageStream.hpp>
#include <iostream>

void
matrixInverse( double* matrix,
               int     n );

#define SAFE_RETURN( result ) \
    if ( !result ) \
    { \
        return false; \
    } \

#define SAFE_RETURN_NULL( result ) \
    if ( result == NULL ) \
    { \
        return NULL; \
    } \

#define ErrorStream MessageStream::Errors

#define WarningStream MessageStream::Warnings

#define NoteStream MessageStream::Notes

//#define DebugStream std::cout << "[EXTRA-P] Debug: "
#define DebugStream if ( 0 ) std::cout

#endif
