/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_SIMPLE_MODEL_GENERATOR_HPP
#define EXTRAP_SINGLE_PARAMETER_SIMPLE_MODEL_GENERATOR_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterHypothesis.hpp>
#include <EXTRAP_SingleParameterModelGenerator.hpp>

namespace EXTRAP
{
class SingleParameterFunction;

class SingleParameterSimpleModelGenerator : public SingleParameterModelGenerator
{
public:
    static const std::string SINGLEPARAMETERSIMPLEMODELGENERATOR_PREFIX;
    SingleParameterSimpleModelGenerator();

    void
    generateHypothesisBuildingBlockSet
    (
        const std::vector<double>& poly_exponents,
        const std::vector<double>& log_exponents
    );

    void
    generateDefaultHypothesisBuildingBlockSet();

    //TODO: fix for the sparse modeler evaluation
    void
    generateDefaultHypothesisBuildingBlocks();

    void
    addHypothesisBuildingBlock( CompoundTerm term );

    void
    printHypothesisBuildingBlocks( void );

    void
    setMaxTermCount( int );

    int
    getMaxTermCount( void ) const;

    const std::vector<CompoundTerm>&
    getBuildingBlocks( void ) const;

    virtual bool
    serialize(
        IoHelper* ioHelper ) const;

    static SingleParameterSimpleModelGenerator*
    deserialize(
        IoHelper* ioHelper );

protected:
    virtual SingleParameterFunctionModeler&
    getFunctionModeler() const;

    SingleParameterSimpleFunctionModeler* m_modeler; // FIXME: this should be a SingleParameterModelGenerator (base class)
};

bool
equal( const SingleParameterSimpleModelGenerator* lhs,
       const SingleParameterSimpleModelGenerator* rhs );
};

#endif
