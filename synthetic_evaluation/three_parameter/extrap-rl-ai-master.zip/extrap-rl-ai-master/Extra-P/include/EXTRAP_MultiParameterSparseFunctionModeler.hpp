/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MULTI_PARAMETER_SPARSE_MODELER_HPP
#define EXTRAP_MULTI_PARAMETER_SPARSE_MODELER_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_MultiParameterFunctionModeler.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_MultiParameterFunction.hpp>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <EXTRAP_IoHelper.hpp>
#include <EXTRAP_Experiment.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <EXTRAP_IncrementalPoint.hpp>
#include <EXTRAP_MultiParameterHypothesis.hpp>
#include <EXTRAP_Fraction.hpp>
#include <iostream>
#include <cassert>
#include <ctime>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <map>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
class MultiParameterSparseFunctionModeler : public MultiParameterFunctionModeler
{
public:
    virtual MultiParameterHypothesis
    createModel( const Experiment*             experiment,
                 const ModelGeneratorOptions&  options,
                 const std::vector<DataPoint>& modeledDataPointList,
                 ModelCommentList&             comments,
                 const Function*               expectationFunction = NULL );

protected:

    //Start of external state
    // (nothing here)
    //End of external state

private:
    std::vector<CoordinateList>
    findFirstMeasurementPoints( const Experiment* parent_experiment,
                                int               min_measurement_points );

    std::vector<CoordinateList>
    findMaxMeasurementPoints( const Experiment* parent_experiment,
                              int               min_measurement_points );

    std::vector<CoordinateList>
    findCheapestMeasurementPoints( const Experiment*             parent_experiment,
                                    int                           min_measurement_points,
                                    const std::vector<DataPoint>& modeledDataPointList );

    std::vector<double>
    getParameterValues( ParameterList parameters,
                        Coordinate*   reference_coordinate,
                        int           parameter_id );

    bool
    compareParameterValues( std::vector<double> parameter_value_list1,
                            std::vector<double> parameter_value_list2 );

    bool
    analyzeMeasurementPoint( ParameterList       parameters,
                             std::vector<double> parameter_value_list );

    std::vector<Experiment*>
    createAllExperiments( std::vector<CoordinateList>   coordinate_container_list,
                          const Experiment*             parent_experiment,
                          const std::vector<DataPoint>& modeledDataPointList );

    Experiment*
    createSingleParameterExperiment( const Experiment*             original_experiment,
                                     CoordinateList                coordinate_container,
                                     Parameter                     parameter,
                                     Metric*                       metric,
                                     Region*                       region,
                                     Callpath*                     callpath,
                                     const std::vector<DataPoint>& modeledDataPointList );

    std::vector<Experiment*>
    modelAllExperiments( std::vector<Experiment*> experiments,
                         ModelGeneratorOptions    options );

    Experiment*
    addSingleParameterModeler( Experiment*           exp,
                               ModelGeneratorOptions options );

    void
    getSingleParameterExperimentFunctions( std::vector<Experiment*> experiments );

    MultiParameterHypothesis
    findBestMultiParameterHypothesis( const std::vector<DataPoint>&         modeledDataPointList,
                                      const Experiment*                     parent_experiment,
                                      std::vector<SingleParameterFunction*> functions );

    CoordinateList
    getBaseCoordinates( std::vector<CoordinateList> coordinate_container_list );

    std::vector<DataPoint>
    getBaseDataPoints( CoordinateList                base_cord_list,
                       const Experiment*             experiment,
                       const std::vector<DataPoint>& modeledDataPointList );

    std::vector<DataPoint>
    getAdditionalDataPoints( CoordinateList                base_cord_list,
                             const Experiment*             experiment,
                             const std::vector<DataPoint>& modeledDataPointList );

    std::vector<DataPoint>
    sortByCostDec(             const Experiment*             experiment,
                               const std::vector<DataPoint>& modeledDataPointList );

    std::vector<DataPoint>
    sortByCostInc(             const Experiment*             experiment,
                               const std::vector<DataPoint>& modeledDataPointList );

    std::vector<DataPoint>
    addAdditionalDataPoints( std::vector<DataPoint>&       data_points,
                             const std::vector<DataPoint>& modeledDataPointList,
                             int                           number_add_data_points );

    std::vector<int>                               m_paramsToDelete;
    std::vector<int>                               m_paramsToKeep;
    std::vector<EXTRAP::Parameter>       m_params;
    std::vector<SingleParameterFunction*> m_single_parameter_functions;
    ModelGeneratorOptions m_options;
};
};

#endif
