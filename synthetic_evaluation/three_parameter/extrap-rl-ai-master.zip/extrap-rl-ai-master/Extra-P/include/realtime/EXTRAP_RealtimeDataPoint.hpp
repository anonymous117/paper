/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_REALTIME_DATA_POINT_HPP
#define EXTRAP_REALTIME_DATA_POINT_HPP

#include <EXTRAP_Parameter.hpp>
#include <EXTRAP_Region.hpp>
#include <EXTRAP_Metric.hpp>
#include "EXTRAP_QuantileApproximator.hpp"

/**
 * Trick the SWIG wrapper generator.
 * If the return value is a const class reference, we can not access
 * methods of the class in python. Thus, we make SWIG think the return
 * values not const via defining an empty CONST. In all other cases
 * we want to have the returned reference of to be const to ensure
 * side-affect free programming.
 */
#ifndef CONST
#define CONST const
#endif

namespace EXTRAP
{
/**
 * This class represents an updatable data point for one metric/callpath pair.
 */
class RealtimeDataPoint
{
private:
    EXTRAP::Value
    updateStdDeviation( EXTRAP::Value old_deviation,
                        EXTRAP::Value old_average,
                        int           old_sample_count,
                        EXTRAP::Value new_point );

    EXTRAP::Value
    updateAverage( EXTRAP::Value old_average,
                   int           old_sample_count,
                   EXTRAP::Value new_point );

public:
    /**
     * Creates a new RealtimeDataPoint object
     * @param data: a time measurement
     * @param metric: the metric for which the time was measured
     * @param region: the callpath from which the measurement originates
     * @param tValuePath: a path to the file containing tabulated t values
     *                    for the 0.95 quantile of the student-t distribution
     */
    RealtimeDataPoint( EXTRAP::Value data,
                       Region*       region,
                       Metric*       metric );

    /**
     * Updates the properties of the datapoint using the new value provided
     * to represent data from the original collection of measurements and the
     * new measurement
     * @param newValue is the new measurement
     */
    void
    update( EXTRAP::Value newValue );

    /**
     * Returns the sample count.
     */
    virtual int
    getSampleCount( void ) const;

    /**
     * Returns the mean.
     */
    virtual Value
    getMean( void ) const;

    /**
     * Returns the confidence interval for the mean.
     */
    virtual Interval
    getMeanCI( void ) const;

    /**
     * Returns standard deviation.
     */
    virtual Value
    getStandardDeviation( void ) const;

    /**
     * Returns the median.
     */
    virtual Value
    getMedian( void ) const;

    /**
     * Returns the confidence interval for the median.
     */
    virtual Interval
    getMedianCI( void ) const;

    /**
     * Returns the minimum.
     */
    virtual Value
    getMinimum( void ) const;

    /**
     * Returns the maximum.
     */
    virtual Value
    getMaximum( void ) const;

    /**
     * @return the region
     */
    virtual Region*
    getRegion( void ) const;

    /**
     * @return the metric
     */
    virtual Metric*
    getMetric( void ) const;

protected:

    /**
     * Stores the mean.
     */
    Value m_mean;

    /**
     * Stores the number of samples the data point was derived from.
     */
    int m_sample_count;

    /**
     * Stores a confidence interval for the mean. Only valid if sample count > 1.
     */
    Interval m_confidence_interval_mean;

    /**
     * Stores the standard deviation.
     */
    Value m_standard_deviation;

    /**
     * Stores the median.
     */
    Value m_median;

    /**
     * Stores a confidence interval for the median. Only valid if sample count > 1.
     */
    Interval m_confidence_interval_median;

    /**
     * Stores the minimum.
     */
    Value m_minimum;

    /**
     * Stores the maximum.
     */
    Value m_maximum;

    /**
     * Stores a pointer to the associated Region.
     */
    Region* m_region;

    /**
     * Stores a pointer to the associated Metric.
     */
    Metric* m_metric;

    EXTRAP::QuantileApproximator* m_approx_median;
    EXTRAP::QuantileApproximator* m_approx_5_percent;
    EXTRAP::QuantileApproximator* m_approx_95_percent;
};
};

#endif
