/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MULTI_PARAMETER_SIMPLE_MODEL_GENERATOR_HPP
#define EXTRAP_MULTI_PARAMETER_SIMPLE_MODEL_GENERATOR_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_MultiParameterHypothesis.hpp>
#include <EXTRAP_MultiParameterModelGenerator.hpp>
#include <EXTRAP_MultiParameterSimpleFunctionModeler.hpp>

namespace EXTRAP
{
class SingleParameterFunction;
class MultiParameterFunction;

class MultiParameterSimpleModelGenerator : public MultiParameterModelGenerator
{
public:

    static const std::string MULTIPARAMETERSIMPLEMODELGENERATOR_PREFIX;
    MultiParameterSimpleModelGenerator();


    virtual bool
    serialize( IoHelper* ioHelper ) const;

    static MultiParameterSimpleModelGenerator*
    deserialize( IoHelper* ioHelper );

protected:
    virtual MultiParameterFunctionModeler&
    getFunctionModeler() const;

    MultiParameterSimpleFunctionModeler* m_modeler;
};

bool
equal( const MultiParameterSimpleModelGenerator* lhs,
       const MultiParameterSimpleModelGenerator* rhs );
};

#endif
