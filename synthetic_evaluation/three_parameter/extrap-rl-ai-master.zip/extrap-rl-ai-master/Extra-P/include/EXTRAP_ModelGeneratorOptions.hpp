/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MODEL_GENERATOR_OPTIONS_HPP
#define EXTRAP_MODEL_GENERATOR_OPTIONS_HPP

#include <EXTRAP_Types.hpp>

namespace EXTRAP
{
/**
 * This is the interface for model generator options.
 */
class ModelGeneratorOptions
{
public:

    ModelGeneratorOptions();

    ~ModelGeneratorOptions();

    void
    setGenerateModelOptions( GenerateModelOptions value );

    GenerateModelOptions
    getGenerateModelOptions( void );

    void
    setMinNumberPoints( int value );

    int
    getMinNumberPoints( void );

    void
    setSinglePointsStrategy( SparseModelerSingleParameterStrategy value );

    SparseModelerSingleParameterStrategy
    getSinglePointsStrategy( void );

    void
    setUseAddPoints( bool value );

    bool
    getUseAddPoints( void );

    void
    setNumberAddPoints( int value );

    int
    getNumberAddPoints( void );

    void
    setMultiPointsStrategy( SparseModelerMultiParameterStrategy value );

    SparseModelerMultiParameterStrategy
    getMultiPointsStrategy( void );

private:

    //options used for all modelers
    GenerateModelOptions generate_model_options;

    //single parameter experiment options (only sparse modeler)
    int                                  min_number_points;
    SparseModelerSingleParameterStrategy single_points_strategy;

    //multi parameter experiment options (only sparse modeler)
    bool                                use_add_points;
    int                                 number_add_points;
    SparseModelerMultiParameterStrategy multi_points_strategy;
};

bool
equal( const ModelGeneratorOptions lhs,
       const ModelGeneratorOptions rhs );
}

#endif
