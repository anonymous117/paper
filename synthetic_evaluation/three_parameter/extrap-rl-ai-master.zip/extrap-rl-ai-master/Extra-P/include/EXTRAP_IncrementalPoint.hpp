/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_INCREMENTAL_POINT_HPP
#define EXTRAP_INCREMENTAL_POINT_HPP

#include <EXTRAP_ExperimentPoint.hpp>

namespace EXTRAP
{
/**
 * This class represents one data point for one metric/callpath pair.
 */
class IncrementalPoint
{
public:
    virtual void
    addValue( Value value );

    virtual void
    clear( void );

    virtual int
    getSize( void );

    virtual ExperimentPoint*
    getExperimentPoint( const Coordinate* coordinates,
                        const Metric*     metric,
                        const Callpath*   callpath );

private:
    std::vector<Value> m_values;
};
}; // namespace EXTRAP

#endif
