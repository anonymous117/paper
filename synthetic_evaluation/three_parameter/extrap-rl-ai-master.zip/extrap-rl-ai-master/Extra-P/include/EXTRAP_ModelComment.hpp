/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MODELCOMMENT_HPP
#define EXTRAP_MODELCOMMENT_HPP

#include <EXTRAP_Utilities.hpp>
#include <EXTRAP_Types.hpp>
#include <set>
#include <fstream>
#include <map>
#include <cassert>
#include <EXTRAP_IoHelper.hpp>

namespace EXTRAP
{
class ModelComment
{
protected:
    std::string m_message;
    int64_t     m_id;

public:
    static const std::string MODELCOMMENT_PREFIX;
    ModelComment( const std::string& message );

    virtual
    ~ModelComment();

    const std::string&
    getMessage();

    virtual bool
    serialize(                IoHelper* ioHelper ) const;

    static ModelComment*
    deserialize(                  IoHelper* ioHelper );

    virtual void
    setId( int64_t id );

    virtual int64_t
    getId( void ) const;
};
bool
equal( ModelComment* lhs,
       ModelComment* rhs );

/**
 * Type of the list of model comments
 */
typedef std::vector<ModelComment*> ModelCommentList;
};
#endif
