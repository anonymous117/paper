/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MLHELPER_HPP
#define EXTRAP_MLHELPER_HPP

#include <config.h>
#include <stdio.h>
#include <iostream>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Utilities.hpp>
#include <cassert>
#include <ctime>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <map>
#include <EXTRAP_IncrementalPoint.hpp>

namespace EXTRAP
{
class Mlhelper
{
public:

    Mlhelper();

    virtual
    ~Mlhelper();

    Experiment*
    addCoordinates( Experiment* experiment, int flag1, int flag2, int flag3, int flag4, int flag5, 
    int flag6, int flag7, int flag8, int flag9, int flag10, int flag11, int flag12, int flag13, int flag14, 
    int flag15, int flag16, int flag17, int flag18, int flag19, int flag20, int flag21, int flag22, int flag23, 
    int flag24, int flag25 );

    Experiment*
    addDataPoints( Experiment* experiment, std::vector<int> selected_points, std::vector<double> measurements );
};
};

#endif
