/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MULTI_PARAMETER_FUNCTION_MODELER_HPP
#define EXTRAP_MULTI_PARAMETER_FUNCTION_MODELER_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_MultiParameterTerm.hpp>
#include <EXTRAP_MultiParameterHypothesis.hpp>
#include <EXTRAP_DataPoint.hpp>
#include <EXTRAP_SingleParameterFunctionModeler.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
class MultiParameterFunction;

class MultiParameterFunctionModeler
{
public:
    MultiParameterFunctionModeler();

    virtual MultiParameterHypothesis
    createModel( const Experiment*             experiment,
                 const ModelGeneratorOptions&  options,
                 const std::vector<DataPoint>& modeledDataPointList,
                 ModelCommentList&             comments,
                 const Function*               expectationFunction = NULL ) = 0;

    virtual MultiParameterFunction*
    createConstantModel( const std::vector<DataPoint>& modeledDataPointList );

protected:
    /**
     * Returns the best valid hypothesis from the currently configured search space, starting with a given initialHypothesis.
     * The algorithm uses the abstract functions initSearchSpace, nextHypothesis, getCurrentHypothesis and compareHypotheses
     * to traverse the search space.
     *
     * The function assumes ownership of the passed initialHypothesis and its model function and will delete it
     * unless it is being returned as the best found hypothesis.
     */

    //Start of external state

    SingleParameterFunctionModeler* m_single_parameter_function_modeler;
    //End of external state
};
};

#endif
