/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLEPARAMETERFUNCTION_HPP
#define EXTRAP_SINGLEPARAMETERFUNCTION_HPP

#include <EXTRAP_Function.hpp>
#include <EXTRAP_CompoundTerm.hpp>

namespace EXTRAP
{
class SingleParameterFunction : public Function
{
public:
    static const std::string SINGLEPARAMETERFUNCTION_PREFIX;
    SingleParameterFunction( void );
    SingleParameterFunction( const SingleParameterFunction& obj );

    virtual Value
    evaluate( const ParameterValueList& parameterValues ) const;

    virtual std::string
    getAsString( const std::string& parameterName ) const;
    virtual std::string
    getAsString( const ParameterList& parameterNames ) const;

    void
    addCompoundTerm( const CompoundTerm& ct );

    std::vector<CompoundTerm>&
    getCompoundTerms( void );

    const std::vector<CompoundTerm>&
    getCompoundTerms( void ) const;

    void
    setConstantCoefficient( Value v );

    Value
    getConstantCoefficient( void ) const;

    virtual Function*
    clone( void ) const;

    virtual bool
    serialize(
        IoHelper* ioHelper ) const;
    static SingleParameterFunction
    deserialize(
        IoHelper* ioHelper );

    virtual FunctionClass
    getFunctionClass() const;

private:
    std::vector<CompoundTerm> m_compound_terms;
    Value                     m_constant_coefficient;
};
bool
equal( const SingleParameterFunction* lhs,
       const SingleParameterFunction* rhs );
};

#endif
