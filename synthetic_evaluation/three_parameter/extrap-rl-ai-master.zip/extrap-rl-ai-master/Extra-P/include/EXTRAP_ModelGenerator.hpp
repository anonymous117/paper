/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MODEL_GENERATOR_HPP
#define EXTRAP_MODEL_GENERATOR_HPP

#include <EXTRAP_Model.hpp>
#include <EXTRAP_ExperimentPoint.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
/**
 * This is the base class and interface for model generators.
 */
class ModelGenerator
{
public:
    /**
     * Make destructor virtual
     */
    virtual
    ~ModelGenerator();

    /**
     * Creates a new model.
     * @param dataPoints    A list of data points from which we want to derive
     *                      a model.
     * @expectationFunction A function with an expectation of the model.
     */
    virtual Model*
    createModel( const Experiment*            experiment,
                 const ModelGeneratorOptions& options,
                 const ExperimentPointList&   dataPoints,
                 const Function*              expectationFunction = NULL );

    virtual bool
    serialize(
        IoHelper* ioHelper ) const;

    /**
     * Returns the user specified name for the generator configuration.
     */
    virtual std::string
    getUserName( void ) const;

    /**
     * Sets the user specified name for the generator configuration.
     * It allows a user to name his models.
     * @param newName  The name given to the model.
     */
    virtual void
    setUserName( const std::string& newName );

    virtual void
    setId( int64_t id );

    virtual int64_t
    getId( void ) const;

protected:
    std::string m_user_name;
    int64_t     m_id;
};

typedef std::vector<ModelGenerator*> ModelGeneratorList;

bool
equal( const ModelGenerator* lhs,
       const ModelGenerator* rhs );
};

#endif
