#! /bin/sh

#########################################
# Installation specific data

# SVN base directory
SVNBASE="/var/lib/svn"

# use absolute path to svnlook
SVNLOOK=/usr/bin/svnlook

# default repositories
repos="extra-p"

# user for svn accesses
SVNUSER="www-data:www-data"

#########################################

# take repos from the command line, if any
if [ $# -gt 0 ]; then
    repos="$*"
fi

PRE_COMMIT="$(mktemp)"

$SVNLOOK cat $SVNBASE/extra-p trunk/tools/beautifier/pre-commit > "$PRE_COMMIT" &&
    chmod 0755 "$PRE_COMMIT" &&
    chown $SVNUSER "$PRE_COMMIT"
if [ $? -ne 0 ]; then
    echo "Can't generate pre-commit hook." >&2
    exit 1
fi

for repo in $repos
do
    if [ ! -d $SVNBASE/$repo/hooks ]; then
        echo >&2 "No repository for $repo."
        continue
    fi

    if cp --archive --backup=numbered "$PRE_COMMIT" $SVNBASE/$repo/hooks/pre-commit; then
        echo "pre-commit hook installed for repository $repo."
    else
        echo >&2 "Installation failed for repository $repo."
    fi
done

rm -f "$PRE_COMMIT"
