from math import log

if __name__ == "__main__":
    function = "x**3+log(y,2)+z**2+t"
    p1 = [4,8,16,32,64]
    p2 = [10,20,30,40,50]
    p3 = [100,200,300,400,500]
    p4 = [1,2,3,4,5]
    file = open("test.txt", "w")
    for a in range(len(p1)):
        x = p1[a]
        for b in range(len(p2)):
            y = p2[b]
            for c in range(len(p3)):
                z = p3[c]
                for d in range(len(p4)):
                    t = p4[d]
                    time = eval(function)
                    line = '{\"params\":{\"x\":'+str(x)+',\"y\":'+str(y)+',\"z\":'+str(z)+',\"t\":'+str(t)+'},\"metric\":\"metr\",\"value\":'+str(time)+'}\n'
                    #print(line)
                    file.write(line)
    file.close()
