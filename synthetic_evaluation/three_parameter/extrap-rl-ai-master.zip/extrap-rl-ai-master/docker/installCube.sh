#!/bin/sh
wget http://apps.fz-juelich.de/scalasca/releases/cube/4.4/dist/cubelib-4.4.2.tar.gz
tar -zxvf cubelib-4.4.2.tar.gz
cd cubelib-4.4.2
mkdir vpath
ls
cd vpath
../configure --prefix=/cube4.4.2
make
make install
make installcheck
