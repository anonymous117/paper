import tkinter as tk
from tkinter import filedialog
import os
import sys
from math import *
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

def select_folder():
    root = tk.Tk()
    root.withdraw()
    return filedialog.askdirectory()

def get_file_names(path):
        return os.listdir(path)

def parse_to_python_function(function):
    # remove leading + for the first coefficient
    if function[0] == ' ':
        function = function[1:]
    if function[0] == '+':
        function = function[1:]
    if function[0] == ' ':
        function = function[1:]

    # replace power operator ^ with **
    while True:
        id = 0
        complete = True
        for i in range(0,len(function)):
            if function[i] == '^':
                id = i
                complete = False
                break
        if complete == True:
            break
        temp = function[:id]
        temp2 = function[id+2:]
        exponent = function[id+1]
        temp2 = '**' + exponent + temp2
        function = temp + temp2

    # replace log operator log2(x) with log(x,2)
    while True:
        id = function.find('log2')
        if id == -1:
            break
        else:
            temp = function[:id]
            temp2 = function[id+4:]
            bracket1 = temp2.find('(')
            bracket2 = temp2.find(')')
            parameter = temp2
            parameter = parameter[bracket1+1:]
            idd = parameter.find(')')
            parameter = parameter[:idd]
            temp3 = temp2[:bracket1]
            temp4 = temp2[bracket2+1:]
            temp2 = temp3 + temp4
            function = temp + 'log(' + parameter + ',2)' + temp2

    return function


if __name__ == "__main__":
    path = select_folder()
    files = get_file_names(path)
    #set parameters
    p_max = 64
    size_max = 50
    multiplicators = [2,4,8,10]
    noise = int(input("Please input noise: "))
    numbers = []
    for _ in range(len(multiplicators)):
        template = []
        for _ in range(18):
            template.append(0)
        numbers.append(template)
    for i in range(len(files)):
        file = files[i]
        src = path + '/' + file
        with open(src) as f:
            lines = f.readlines()
        for j in range(len(lines)):
            string = lines[j]
            lines[j] = string[:-1]
        for z in range(len(lines)-1):
            baseline_function = lines[0]
            modeled_function = lines[z+1]
            baseline_function_python = parse_to_python_function(baseline_function)
            modeled_function_python = parse_to_python_function(modeled_function)
            for j in range(len(multiplicators)):
                p = p_max * multiplicators[j]
                size = size_max * multiplicators[j]
                result_base = eval(baseline_function_python)
                result_modeled = eval(modeled_function_python)
                one_percent = result_base / 100
                # limit = max result noise allowed in one direction
                limit = (one_percent * noise)/2
                difference_absolute = abs(result_base - result_modeled)
                
                if difference_absolute > limit:
                    difference_percent = difference_absolute / one_percent
                    #print(difference_absolute)
                    #print(difference_percent)
                    numbers[j][z] = numbers[j][z] + 1


    #plot the data
    zero = []
    one = []
    two = []
    three = []
    for j in range(18):
        zero.append(numbers[0][j])
        one.append(numbers[1][j])
        two.append(numbers[2][j])
        three.append(numbers[3][j])

    #show data
    print(zero)
    print(one)
    print(two)
    print(three)

    ind = np.arange(len(zero))  # the x locations for the groups
    width = 0.2  # the width of the bars

    fig, ax = plt.subplots()
    rects1 = ax.bar(ind-width*2+width/2, zero, width,
                    color='red', label='2x')
    rects2 = ax.bar(ind-width+width/2, one, width,
                    color='green', label='4x')
    rects3 = ax.bar(ind + width-width/2, two, width,
                    color='blue', label='8x')
    rects4 = ax.bar(ind + width*2-width/2, three, width,
                    color='yellow', label='10x')

    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_ylabel('Number of functions')
    ax.set_title('Scaling analysis. Noise: '+str(noise)+'%')
    ax.set_xticks(ind)
    ax.set_xticklabels(('N', 'S 9', 'S 10', 'S 11', 'S 12', 'S 13', 'S 14', 'S 15', 'S 16', 'S 17', 'S 18', 'S 19', 'S 20', 'S 21', 'S 22', 'S 23', 'S 24', 'S 25'))
    ax.legend()

    def autolabel_term_plot(rects, xpos='center'):
        xpos = xpos.lower()  # normalize the case of the parameter
        ha = {'center': 'center', 'right': 'left', 'left': 'right'}
        offset = {'center': 0.5, 'right': 0.57, 'left': 0.43}  # x_txt = x + w*off

        for rect in rects:
            height = rect.get_height()
            ax.text(rect.get_x() + rect.get_width()*offset[xpos], 1.01*height,
                    '{}'.format(height), ha=ha[xpos], va='bottom')

    autolabel_term_plot(rects1, "center")
    autolabel_term_plot(rects2, "center")
    autolabel_term_plot(rects3, "center")
    autolabel_term_plot(rects4, "center")
    
    
    #plt.savefig('/home/marcus/Desktop/scaling_analysis.png', dpi=300)
    plt.show()
    print("done.")
