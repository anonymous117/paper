/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_FunctionGenerator.hpp>
#include <EXTRAP_MultiParamFunctionGenerator.hpp>
#include <cmath>
#include <stdio.h>

namespace EXTRAP
{
FunctionGenerator::FunctionGenerator( FunctionCategory functionCat, int terms )
    : m_functionCat( functionCat ), m_terms( terms )
{
    //deactive >> is bad for term analysis, we do not want inactive terms
    //m_expPolyCommon.push_back( 0.0 );
    m_expPolyCommon.push_back( 1.0 );
    m_expPolyCommon.push_back( 2.0 );
    m_expPolyCommon.push_back( 3.0 );

    m_expPolyRare.assign( m_expPolyCommon.begin(), m_expPolyCommon.end() );
    m_expPolyRare.push_back( 0.5 );
    m_expPolyRare.push_back( 1.5 );
    m_expPolyRare.push_back( 2.5 );
    m_expPolyRare.push_back( 1 / 3.0 );
    m_expPolyRare.push_back( 2 / 3.0 );
    m_expPolyRare.push_back( 4 / 3.0 );
    m_expPolyRare.push_back( 5 / 3.0 );
    m_expPolyRare.push_back( 7 / 3.0 );
    m_expPolyRare.push_back( 8 / 3.0 );

    m_expPolyExotic.assign( m_expPolyRare.begin(), m_expPolyRare.end() );
    m_expPolyExotic.push_back( 1 / 4.0 );
    m_expPolyExotic.push_back( 3 / 4.0 );
    m_expPolyExotic.push_back( 5 / 4.0 );
    m_expPolyExotic.push_back( 7 / 4.0 );
    m_expPolyExotic.push_back( 9 / 4.0 );
    m_expPolyExotic.push_back( 11 / 4.0 );
    m_expPolyExotic.push_back( 1 / 5.0 );
    m_expPolyExotic.push_back( 2 / 5.0 );
    m_expPolyExotic.push_back( 3 / 5.0 );
    m_expPolyExotic.push_back( 4 / 5.0 );
    m_expPolyExotic.push_back( 6 / 5.0 );
    m_expPolyExotic.push_back( 7 / 5.0 );
    m_expPolyExotic.push_back( 8 / 5.0 );
    m_expPolyExotic.push_back( 9 / 5.0 );
    m_expPolyExotic.push_back( 11 / 5.0 );
    m_expPolyExotic.push_back( 12 / 5.0 );
    m_expPolyExotic.push_back( 13 / 5.0 );
    m_expPolyExotic.push_back( 14 / 5.0 );

    //deactive >> is bad for term analysis, we do not want inactive terms
    //m_expLogCommon.push_back( 0.0 );
    m_expLogCommon.push_back( 1.0 );

    m_expLogRare.assign( m_expLogCommon.begin(), m_expLogCommon.end() );
    m_expLogRare.push_back( 2.0 );

    m_expLogExotic.assign( m_expLogRare.begin(), m_expLogRare.end() );
    m_expLogExotic.push_back( 0.5 );
    m_expLogExotic.push_back( 1.5 );
}

FunctionGenerator::~FunctionGenerator()
{
}

void
FunctionGenerator::generateCompoundTerm( EXTRAP::CompoundTerm& compTerm,
                                         FunctionCategory&     actualCat,
                                         bool&                 isTrivial )
{
    actualCat = m_functionCat;
    isTrivial = false;

    compTerm.setCoefficient( 1.0 );

    EXTRAP::SimpleTerm poly_term;
    EXTRAP::SimpleTerm log_term;
    int                poly_rand_idx = 0;
    int                log_rand_idx  = 0;
    poly_term.setFunctionType( EXTRAP::polynomial );
    log_term.setFunctionType( EXTRAP::logarithm );
    switch ( m_functionCat )
    {
        case EXTRAP::COMMON_CAT:
            poly_rand_idx = getRandomIdx( 0, m_expPolyCommon.size() - 1 );
            log_rand_idx  = getRandomIdx( 0, m_expLogCommon.size() - 1 );
            poly_term.setExponent( m_expPolyCommon[ poly_rand_idx ] );
            log_term.setExponent( m_expLogCommon[ log_rand_idx ] );
            break;
        case EXTRAP::RARE_CAT:
            poly_rand_idx = getRandomIdx( 0, m_expPolyRare.size() - 1 );
            log_rand_idx  = getRandomIdx( 0, m_expLogRare.size() - 1 );
            poly_term.setExponent( m_expPolyRare[ poly_rand_idx ] );
            log_term.setExponent( m_expLogRare[ log_rand_idx ] );
            if ( poly_rand_idx < m_expPolyCommon.size() && log_rand_idx < m_expLogCommon.size() )
            {
                actualCat = EXTRAP::COMMON_CAT;
            }
            break;
        case EXTRAP::EXOTIC_CAT:
            poly_rand_idx = getRandomIdx( 0, m_expPolyExotic.size() - 1 );
            log_rand_idx  = getRandomIdx( 0, m_expLogExotic.size() - 1 );
            poly_term.setExponent( m_expPolyExotic[ poly_rand_idx ] );
            log_term.setExponent( m_expLogExotic[ log_rand_idx ] );
            if ( poly_rand_idx < m_expPolyCommon.size() && log_rand_idx < m_expLogCommon.size() )
            {
                actualCat = EXTRAP::COMMON_CAT;
            }
            else if ( poly_rand_idx < m_expPolyRare.size() && log_rand_idx < m_expLogRare.size() )
            {
                actualCat = EXTRAP::RARE_CAT;
            }
            break;
    }
    isTrivial = ( poly_rand_idx == 0 ) && ( log_rand_idx == 0 );

    int choice = randomSwitch( 1, 3 );

    if ( choice == 1 )
    {
        compTerm.addSimpleTerm( poly_term );
    }
    else if ( choice == 2 )
    {
        compTerm.addSimpleTerm( log_term );
    }
    else if ( choice == 3 )
    {
        compTerm.addSimpleTerm( poly_term );
        compTerm.addSimpleTerm( log_term );
    }
    else
    {
        compTerm.addSimpleTerm( poly_term );
        compTerm.addSimpleTerm( log_term );
    }
}

double
FunctionGenerator::getRandomCoeff()
{
    double u   = drand48();
    double exp = ( u * 5.0 ) - 2.0;

    return std::pow( 10.0, exp );
}

int
FunctionGenerator::getRandomIdx( int lo, int hi )
{
    double u  = drand48();
    double nr = u * ( hi - lo ) + lo;
    return ( int )round( nr );
}

bool
FunctionGenerator::flipCoin()
{
    double u = drand48();
    return u >= 0.5;
}

int
FunctionGenerator::randomSwitch( int min, int max )
{
    int output = min + ( rand() % static_cast<int>( max - min + 1 ) );
    return output;
}
}
