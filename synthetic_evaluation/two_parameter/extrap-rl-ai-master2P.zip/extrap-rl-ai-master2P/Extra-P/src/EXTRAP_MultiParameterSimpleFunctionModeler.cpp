/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_MultiParameterSimpleFunctionModeler.hpp>
#include <EXTRAP_SingleParameterHypothesis.hpp>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>
#include <sstream>

namespace EXTRAP
{
const std::string BAD_MODEL               = "This model has a large error metric (SMAPE). Probably the measurements can not be explained by PMNF.";
const std::string BETTER_USER_EXPECTATION = "Expectation function specified by user is a better model than the best hypothesis.";

MultiParameterHypothesis
MultiParameterSimpleFunctionModeler::createModel( const Experiment*             experiment,
                                                  const ModelGeneratorOptions&  options,
                                                  const std::vector<DataPoint>& modeledDataPointList,
                                                  ModelCommentList&             comments,
                                                  const Function*               expectationFunction )
{
    double constantCost = 0;

    double meanModel = 0;

    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        meanModel += modeledDataPointList[ i ].getValue() / ( double )modeledDataPointList.size();
    }
    for ( int i = 0; i < modeledDataPointList.size(); i++ )
    {
        constantCost += ( modeledDataPointList[ i ].getValue() - meanModel ) * ( modeledDataPointList[ i ].getValue() - meanModel );
    }
    //constantCost
    //First the data points have to be split by parameter

    std::vector<std::vector<DataPoint> > singleParamDataPointLists;
    int                                  parameterNumbers;
    std::vector<EXTRAP::Parameter>       params;
    
    assert( modeledDataPointList.size() > 0 );
    parameterNumbers = modeledDataPointList[ 0 ].getParameterList().size();
    for ( int i = 1; i < modeledDataPointList.size(); i++ )
    {
        assert( parameterNumbers == modeledDataPointList[ i ].getParameterList().size() );
    }
    for ( EXTRAP::ParameterValueList::const_iterator it = modeledDataPointList[ 0 ].getParameterList().begin(); it != modeledDataPointList[ 0 ].getParameterList().end(); it++ )
    {
        const Parameter p = it->first;
        params.push_back( p );
        std::vector<DataPoint> singleParamDataPointList;
        std::vector<bool>      valueUsed( modeledDataPointList.size(), false );
        for ( int j = 0; j < modeledDataPointList.size(); j++ )
        {
            if ( valueUsed[ j ] == true )
            {
                continue;
            }
            Value v           = 0;
            int   sampleCount = 0;
            for ( int k = j; k < modeledDataPointList.size(); k++ )
            {
                if ( modeledDataPointList[ j ].getParameterValue( p ) == modeledDataPointList[ k ].getParameterValue( p ) )
                {
                    v += modeledDataPointList[ j ].getValue();
                    sampleCount++;
                    valueUsed[ k ] = true;
                }
            }
            v = v / ( double )sampleCount;
            ParameterValueList* temporaryPVL;
            temporaryPVL = new ParameterValueList();
            Interval interval;
            interval.end   = 0;
            interval.start = 0;
            temporaryPVL->insert( std::make_pair( p, modeledDataPointList[ j ].getParameterValue( p ) ) );
            const DataPoint t( temporaryPVL, sampleCount, v, interval );
            singleParamDataPointList.push_back( t );
        }
        singleParamDataPointLists.push_back( singleParamDataPointList );
    }
    //The datapoints are now split by parameter and sorted into the singleParamDataPoints vector
    std::vector<EXTRAP::SingleParameterHypothesis> bestSingleParameterHypotheses;
    std::vector<int>                               paramsToDelete;
    std::vector<int>                               paramsToKeep;
    ModelCommentList                               single_param_comments;
    //Create single parameter hypothesis for all parameters
    for ( int i = 0; i < singleParamDataPointLists.size(); i++ )
    {
        EXTRAP::SingleParameterHypothesis hyp = m_single_parameter_function_modeler->createModel( experiment, options, singleParamDataPointLists[ i ], single_param_comments, expectationFunction );

        if ( hyp.getFunction()->getCompoundTerms().size() > 0 )
        {
            bestSingleParameterHypotheses.push_back( hyp );
            paramsToKeep.push_back( i );
        }
        else
        {
            paramsToDelete.push_back( i );
        }
    }

    if ( paramsToDelete.size() == params.size() )
    {
        MultiParameterFunction* constantFunction = new MultiParameterFunction();
        constantFunction->setConstantCoefficient( meanModel );
        MultiParameterHypothesis constantHypothesis( constantFunction );
        constantHypothesis.setRSS( constantCost );
        constantHypothesis.setAR2( 0 );
        constantHypothesis.setrRSS( 0 );
        constantHypothesis.setSMAPE( 0 );
        return constantHypothesis;
    }
    else if ( ( params.size() - paramsToDelete.size() ) == 1 )
    {
        MultiParameterFunction* simpleFunction = new MultiParameterFunction();
        MultiParameterTerm      t;
        t.addCompoundTermParameterPair( bestSingleParameterHypotheses[ 0 ].getFunction()->getCompoundTerms()[ 0 ], params[ paramsToKeep[ 0 ] ] );
        t.setCoefficient( bestSingleParameterHypotheses[ 0 ].getFunction()->getCompoundTerms()[ 0 ].getCoefficient() );
        simpleFunction->addMultiParameterTerm( t );
        MultiParameterHypothesis simpleHypothesis( simpleFunction );
        simpleHypothesis.getFunction()->setConstantCoefficient( bestSingleParameterHypotheses[ 0 ].getFunction()->getConstantCoefficient() );
        simpleHypothesis.computeCost( modeledDataPointList );
        return simpleHypothesis;
    }

    //Remove unneccessary parameters
    for ( int i = paramsToDelete.size() - 1; i >= 0; i-- )
    {
        params.erase( params.begin() + paramsToDelete[ i ] );
    }

    //multi-term
    std::vector<MultiParameterHypothesis> modelHypotheses;
    EXTRAP::MultiParameterTerm            mult;
    std::vector<EXTRAP::CompoundTerm> compound_terms;
    for ( int i = 0; i < bestSingleParameterHypotheses.size(); i++ )
    {
        EXTRAP::CompoundTerm ct;
        ct = bestSingleParameterHypotheses[ i ].getFunction()->getCompoundTerms()[ 0 ];
        ct.setCoefficient( 1 );
        compound_terms.push_back(ct);
    }
    Parameter tmpp = params[0];
    std::string tmppname = tmpp.getName();
    if (tmppname == "p"){
        mult.addCompoundTermParameterPair( compound_terms[0], params[ 0 ] );
        mult.addCompoundTermParameterPair( compound_terms[1], params[ 1 ] );
    }else{
        mult.addCompoundTermParameterPair( compound_terms[1], params[ 1 ] );
        mult.addCompoundTermParameterPair( compound_terms[0], params[ 0 ] );
    }

    //mult.addCompoundTermParameterPair( compound_terms[0], params[ 0 ] );
    //mult.addCompoundTermParameterPair( compound_terms[1], params[ 1 ] );
    //mult.addCompoundTermParameterPair( compound_terms[2], params[ 2 ] );
    
    //add-term
    std::vector<EXTRAP::MultiParameterTerm> add;
    for ( int i = 0; i < bestSingleParameterHypotheses.size(); i++ )
    {
        EXTRAP::MultiParameterTerm tmp;
        EXTRAP::CompoundTerm       ct;
        ct = bestSingleParameterHypotheses[ i ].getFunction()->getCompoundTerms()[ 0 ];
        ct.setCoefficient( 1 );
        tmp.addCompoundTermParameterPair( ct, params[ i ] );
        add.push_back( tmp );
    }

    std::vector<MultiParameterHypothesis> hypotheses;

    //add Hypotheses for 2 parameter models
    if ( params.size() == 2 )
    {
        EXTRAP::MultiParameterFunction* f1, * f2, * f3, * f4;
        f1 = new  EXTRAP::MultiParameterFunction();
        //f2 = new  EXTRAP::MultiParameterFunction();
        //f3 = new  EXTRAP::MultiParameterFunction();
        f4 = new  EXTRAP::MultiParameterFunction();
        f1->addMultiParameterTerm( mult );
        //f2->addMultiParameterTerm( add[ 0 ] );
        //f2->addMultiParameterTerm( mult );
        //f3->addMultiParameterTerm( add[ 1 ] );
        //f3->addMultiParameterTerm( mult );
        f4->addMultiParameterTerm( add[ 0 ] );
        f4->addMultiParameterTerm( add[ 1 ] );
        MultiParameterHypothesis              mph1( f1 );
        //MultiParameterHypothesis              mph2( f2 );
        //MultiParameterHypothesis              mph3( f3 );
        MultiParameterHypothesis              mph4( f4 );
        hypotheses.push_back( mph1 );   //a*b
        //hypotheses.push_back( mph2 ); //a*b+a
        //hypotheses.push_back( mph3 ); //a*b+b
        hypotheses.push_back( mph4 );   //a+b
    }

    //add Hypotheses for 3 parameter models
    if ( params.size() == 3 )
    {
        EXTRAP::MultiParameterFunction* f5, * f6, * f7, * f8;
        f5 = new EXTRAP::MultiParameterFunction();
        f6 = new EXTRAP::MultiParameterFunction();
        f7 = new EXTRAP::MultiParameterFunction();
        f8 = new EXTRAP::MultiParameterFunction();
        f5->addMultiParameterTerm( mult );
        MultiParameterHypothesis mph5( f5 );
        f6->addMultiParameterTerm( add[ 1 ] );
        f6->addMultiParameterTerm( add[ 2 ] );
        f6->addMultiParameterTerm( add[ 0 ] );
        MultiParameterHypothesis mph6( f6 );
        /**
        f7->addMultiParameterTerm( mult );
        f7->addMultiParameterTerm( add[ 1 ] );
        f7->addMultiParameterTerm( add[ 2 ] );
        MultiParameterHypothesis mph7( f7 );
        hypotheses.push_back( mph7 );
        f8->addMultiParameterTerm( mult );
        f8->addMultiParameterTerm( add[ 0 ] );
        f8->addMultiParameterTerm( add[ 1 ] );
        f8->addMultiParameterTerm( add[ 2 ] );
        MultiParameterHypothesis mph8( f8 );
        hypotheses.push_back( mph8 );
        **/
        hypotheses.push_back( mph5 );   //a*b*c
        hypotheses.push_back( mph6 );   //a+b+c
    }
    
    MultiParameterHypothesis bestHypothesis = hypotheses[ 0 ];
    bestHypothesis.estimateParameters( modeledDataPointList );
    bestHypothesis.computeCost( modeledDataPointList );
    bestHypothesis.computeAdjustedRSquared( constantCost, modeledDataPointList );

    //
    // Uncomment the line below to get detailed printouts of all the hypotheses
    //
    //std::cout << "hypothesis 0 : " << bestHypothesis.getFunction()->getAsString( params ) << " --- smape: " << bestHypothesis.getSMAPE() << " --- rss: " << bestHypothesis.getRE() << " --- ar2: " << bestHypothesis.getAR2() << std::endl;

    for ( int i = 1; i < hypotheses.size(); i++ )
    {
        hypotheses[ i ].estimateParameters( modeledDataPointList );
        hypotheses[ i ].computeCost( modeledDataPointList );
        hypotheses[ i ].computeAdjustedRSquared( constantCost, modeledDataPointList );

        //
        // Uncomment the line below to get detailed printouts of all the hypotheses
        //
        //std::cout << "hypothesis " << i << " : " << hypotheses[ i ].getFunction()->getAsString( params ) << " --- smape: " << hypotheses[ i ].getSMAPE() << " --- rss: " << hypotheses[ i ].getRE() << " --- ar2: " << hypotheses[ i ].getAR2() << std::endl;

        if ( hypotheses[ i ].getSMAPE() < bestHypothesis.getSMAPE() )
        {
            delete ( bestHypothesis.getFunction() );
            bestHypothesis = hypotheses[ i ];
        }
        else
        {
            delete ( hypotheses[ i ].getFunction() );
        }

        //
        // Alternative hypotheses selection with relative error
        //
        //if ( hypotheses[ i ].getRE() < bestHypothesis.getRE() )
        //{
        //    delete ( bestHypothesis.getFunction() );
        //    bestHypothesis = hypotheses[ i ];
        //}
        //else
        //{
        //    delete ( hypotheses[ i ].getFunction() );
        //}
    }

    return bestHypothesis;
}
}; // Close namespace
