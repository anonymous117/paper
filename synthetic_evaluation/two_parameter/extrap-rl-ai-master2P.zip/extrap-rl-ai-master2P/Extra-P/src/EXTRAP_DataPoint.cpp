/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */
#include <config.h>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_DataPoint.hpp>
#include <cmath>
#include <EXTRAP_Utilities.hpp>

namespace EXTRAP
{
DataPoint::DataPoint( const ParameterValueList* coordinates,
                      int                       sampleCount,
                      Value                     value,
                      Interval                  confidenceInterval )
    : m_coordinates( coordinates ),
    m_sample_count( sampleCount ),
    m_value( value ),
    m_confidence_interval( confidenceInterval )
{
}

const ParameterValueList&
DataPoint::getParameterList( void ) const
{
    return *m_coordinates;
}

Value
DataPoint::getParameterValue( const Parameter& parameter ) const
{
    ParameterValueList::const_iterator it = m_coordinates->find( parameter );
    if ( it != m_coordinates->end() )
    {
        return it->second;
    }
    return INVALID_VALUE;
}

int
DataPoint::getSampleCount( void ) const
{
    return m_sample_count;
}

Value
DataPoint::getValue( void ) const
{
    return m_value;
}

Interval
DataPoint::getConfidenceInterval( void ) const
{
    return m_confidence_interval;
}
}; // Close namespace
