/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */
#include <config.h>
#include <EXTRAP_CubeFileReader.hpp>
#include <EXTRAP_CubeMapping.hpp>
#include <EXTRAP_IncrementalPoint.hpp>
#include <EXTRAP_Utilities.hpp>
#include <Cube.h>
#include <CubeMetric.h>
#include <CubeCartesian.h>
#include <CubeScaleFuncValue.h>
#include <CubeServices.h>
#include <string>
#include <stdlib.h>
#include <dirent.h>
#include <algorithm>

namespace EXTRAP
{
void
initializeMeasurements( std::vector< std::vector< IncrementalPoint > >& measurements,
                        int                                             numMetrics,
                        int                                             numCallpaths )
{
    for ( int metric = 0; metric < numMetrics; metric++ )
    {
        measurements.push_back( std::vector<IncrementalPoint>() );
        for ( int cp = 0; cp < numCallpaths; cp++ )
        {
            measurements[ metric ].push_back( IncrementalPoint() );
        }
    }
}

void
readValueFromCube( IncrementalPoint* experimentPoint,
                   cube::Cube*       cube,
                   cube::Metric*     metric,
                   cube::Cnode*      cnode,
                   int               scaling_type )
{
    if ( metric == NULL || cnode == NULL )
    {
        return;
    }

    const std::vector<cube::Thread*> threads = cube->get_thrdv();

    double accumulated_value = 0;
    for ( std::vector<cube::Thread*>::const_iterator thread = threads.begin();
          thread != threads.end();
          thread++ )
    {
        double thread_value = cube->get_sev( metric, cnode, *thread );
        if ( scaling_type == 1 )
        {
            experimentPoint->addValue( thread_value );
        }
        else
        {
            accumulated_value += thread_value;
        }
    }
    if ( scaling_type != 1 )
    {
        experimentPoint->addValue( accumulated_value );
    }
}

void
CubeFileReader::addParameter( const Parameter&        param,
                              const std::string&      prefix,
                              const std::vector<int>& values )
{
    m_parameters.push_back( param );
    m_parameter_prefixes.push_back( prefix );
    m_parameter_values.push_back( values );
}

//deprecated
std::vector<std::vector<int> >
CubeFileReader::getCombinations( int anchor )
{
    std::vector<std::vector<int> > result;
    if ( m_parameter_values.size() == 0 )
    {
        ErrorStream << "No parameters defined. Please add a parameter at first." << std::endl;
        return result;
    }

    for ( int i = 0; i < m_parameter_values[ 0 ].size(); i++ )
    {
        Coordinate pmList;
        pmList.insert( std::pair<Parameter, Value>( m_parameters[ 0 ], m_parameter_values[ 0 ][ i ] ) );
        std::vector<int> cand;
        cand.push_back( m_parameter_values[ 0 ][ i ] );
        if ( anchor != 1 )
        {
            result = getCombinationsRec( 1, cand, result, anchor, pmList );
        }
        else
        {
            result.push_back( cand );
            this->m_parameter_value_lists.push_back( new Coordinate( pmList ) );
        }
    }
    return result;
}

//deprecated
std::vector<std::vector<int> >
CubeFileReader::getCombinationsRec( int                            param,
                                    std::vector<int>               candidate,
                                    std::vector<std::vector<int> > result,
                                    int                            anchor,
                                    Coordinate                     cand )
{
    if ( this->m_parameters.size() != m_parameter_values.size() )
    {
        ErrorStream << "The number of added parameters is not equal to the number of parameter values given." << std::endl;
        return result;
    }
    if ( this->m_parameters.size() <= param )
    {
        ErrorStream << "Not enough dimensions defined in parameters: "
                    << this->m_parameters.size() << " dimensions defined; "
                    << anchor << " dimensions required." << std::endl;
        return result;
    }
    if ( m_parameter_values.size() <= param )
    {
        ErrorStream << "Not enough dimensions defined in parameter values: "
                    << this->m_parameters.size() << " dimensions defined; "
                    << anchor << " dimensions required." << std::endl;
        return result;
    }

    for ( int i = 0; i < this->m_parameter_values[ param ].size(); i++ )
    {
        cand.insert( std::pair<Parameter, Value>( this->m_parameters[ param ], m_parameter_values[ param ][ i ] ) );
        candidate.push_back( this->m_parameter_values[ param ][ i ] );
        if ( anchor - 1 > param )
        {
            result = this->getCombinationsRec( param + 1, candidate, result, anchor, cand );
        }
        else
        {
            this->m_parameter_value_lists.push_back( new Coordinate( cand ) );
            result.push_back( candidate );
        }
        cand.erase( this->m_parameters[ param ] );
        candidate.pop_back();
    }

    return result;
}

void
CubeFileReader::getCoordinates( std::vector<FileName> file_name_objects, ParameterList paramlist, int repetitions )
{
    //clear coordinate list
    this->m_parameter_value_lists.clear();

    //create the coordinates
    for ( int i = 0; i < file_name_objects.size(); i += this->m_reps )
    {
        //std::cout << file_name_objects[ i ].path << ", " << file_name_objects[ i ].parameter1 << ", " << file_name_objects[ i ].parameter2 << ", " << file_name_objects[ i ].parameter3 << "\n";
        std::vector<double> values;
        values.push_back( file_name_objects[ i ].parameter1 );
        values.push_back( file_name_objects[ i ].parameter2 );
        values.push_back( file_name_objects[ i ].parameter3 );

        Coordinate* cord = new Coordinate();
        for ( int j = 0; j < paramlist.size(); j++ )
        {
            cord->insert( std::pair<Parameter, Value>( paramlist.at( j ), values.at( j ) ) );
        }
        this->m_parameter_value_lists.push_back( cord );
    }

    //debug print out for the coordinates
    //std::cout << "Number coordinates: " << this->m_parameter_value_lists.size() << std::endl;
    //for ( int i = 0; i < this->m_parameter_value_lists.size(); i++ )
    //{
    //    std::cout << this->m_parameter_value_lists.at( i )->toString() << std::endl;
    //}
}

//comparator for sorting the file name list
struct comparer
{
    inline bool
    operator()( const FileName& one, const FileName& two )
    {
        return one.parameter1 < two.parameter1 || ( one.parameter1 == two.parameter1 && one.parameter2 < two.parameter2 ) || ( one.parameter1 == two.parameter1 && one.parameter2 == two.parameter2 && one.parameter3 < two.parameter3 ) || ( one.parameter1 == two.parameter1 && one.parameter2 == two.parameter2 && one.parameter3 == two.parameter3 && one.repetition < two.repetition );
    }
};

std::vector<FileName>
CubeFileReader::getFileNames( int numDimensions, ParameterList paramlist )
{
    std::vector<std::string> fileNames;
    std::string              postfix = "/profile.cubex";
    std::vector<std::string> folders;
    std::string              path  = this->m_dir;
    const char*              PATH  = path.c_str();
    DIR*                     dir   = opendir( PATH );
    struct dirent*           entry = readdir( dir );
    while ( entry != NULL )
    {
        if ( entry->d_type == DT_DIR )
        {
            folders.push_back( entry->d_name );
        }
        entry = readdir( dir );
    }
    closedir( dir );
    for ( int i = 0; i < folders.size(); i++ )
    {
        if ( folders.at( i ) == "." )
        {
            folders.erase( folders.begin() + i );
        }
        if ( folders.at( i ) == ".." )
        {
            folders.erase( folders.begin() + i );
        }
    }
    //construct full file path
    for ( int i = 0; i < folders.size(); i++ )
    {
        std::string file_path = path + "/" + folders.at( i ) + postfix;
        fileNames.push_back( file_path );
    }

    //populate the file name objects with the data
    std::vector<FileName> file_names( fileNames.size() );
    for ( int i = 0; i < fileNames.size(); i++ )
    {
        std::string postfix = "/profile.cubex";
        std::string dir     = fileNames.at( i );

        //remove prefix and postfix
        dir.erase( 0, this->m_dir.length() );
        int difference = dir.length() - postfix.length();
        dir.erase( difference, dir.length() );

        //remove prefix name
        int pos = dir.find( "." );
        dir.erase( 0, pos + 1 );

        //save repetition
        char dir_rep = dir.at( dir.length() - 1 );
        int  rep     =  dir_rep - 48;
        dir.erase( dir.length() - 3, dir.length() );

        std::vector<std::string> pairs;
        std::stringstream        ss( dir );
        while ( ss.good() )
        {
            std::string sub;
            getline( ss, sub, '.' );
            pairs.push_back( sub );
        }

        std::vector<double> parameter_values;
        for ( int j = 0; j < pairs.size(); j++ )
        {
            Parameter   ptmp      = paramlist.at( j );
            std::string ptmp_name = ptmp.getName();
            std::string value     = pairs.at( j );
            value.erase( 0, ptmp_name.length() );
            char buffer[ value.length() + 1 ];
            std::strcpy( buffer, value.c_str() );
            double x = atof( buffer );
            parameter_values.push_back( x );
        }

        file_names[ i ].path       = fileNames.at( i );
        file_names[ i ].parameter1 = parameter_values[ 0 ];
        file_names[ i ].parameter2 = parameter_values[ 1 ];
        file_names[ i ].parameter3 = parameter_values[ 2 ];
        file_names[ i ].repetition = rep;
    }

    //sort the vector of file names and parameter values
    sort( file_names.begin(), file_names.end(), comparer() );

    //debug print out
    //for ( int i = 0; i < file_names.size(); i++ )
    //{
    //   std::cout << file_names.at( i ).path << ", " << file_names.at( i ).parameter1 << ", " << file_names.at( i ).parameter2 << ", " << file_names.at( i ).parameter3 << ", " << file_names.at( i ).repetition << "\n";
    //}

    return file_names;
}

Experiment*
CubeFileReader::readCubeFiles( int dimensions )
{
    Experiment* experiment = new Experiment();
    try{
        if ( !this->isReadyToRead() )
        {
            ErrorStream << "CubeFileReader was not correctly initialized. "
                        << "Please add necessary data and retry."
                        << std::endl;
            return NULL;
        }
        cube::Cube*                                    cube = new cube::Cube();
        std::vector< std::vector< IncrementalPoint > > measurements;
        //load the file paths and coordinates from the cube file dirs
        std::vector<FileName> file_name_objects = this->getFileNames( dimensions, this->m_parameters );

        //populate vector with only the file paths
        std::vector<std::string> cube_files;
        for ( int i = 0; i < file_name_objects.size(); i++ )
        {
            cube_files.push_back( file_name_objects.at( i ).path );
        }
        //create the coordinates from the object vector
        getCoordinates( file_name_objects, this->m_parameters, this->m_reps );

        // Adding parameters and coordinates (only the parameters that are of interest)
        for ( int i = 0; i < dimensions; i++ )
        {
            experiment->addParameter( this->m_parameters[ i ] );
        }
        for ( CoordinateList::iterator it = this->m_parameter_value_lists.begin();
              it != this->m_parameter_value_lists.end();
              it++ )
        {
            experiment->addCoordinate( *it );
        }
        const MetricList&   metrics   = experiment->getMetrics();
        const CallpathList& callpaths = experiment->getAllCallpaths();
        // Adding CUBE data
        for ( int i = 0; i < cube_files.size(); i += this->m_reps )
        {
            Coordinate* coordinates = this->m_parameter_value_lists[ i / this->m_reps ];
            for ( int j = 0; j < this->m_reps; j++ )
            {
                // Read Cube file and create mapping
                cube->openCubeReport( cube_files[ i + j ] );
                CubeMapping mapping( experiment, cube );
                if ( i == 0 && j == 0 )
                {
                    mapping.createMetricDef();
                    mapping.createRegionDef();
                    mapping.createCallpathDef();
                    initializeMeasurements( measurements,
                                            experiment->getMetrics().size(),
                                            experiment->getAllCallpaths().size() );
                }
                else
                {
                    mapping.createMetricMapping();
                    mapping.createRegionMapping();
                    mapping.createCallpathMapping();
                }
                // Iterate over all metrics and callpaths and add data
                for ( MetricList::const_iterator metric_it = metrics.begin();
                      metric_it != metrics.end();
                      metric_it++ )
                {
                    cube::Metric* metric = mapping.getCubeMetric( *metric_it );
                    for ( CallpathList::const_iterator callpath_it = callpaths.begin();
                          callpath_it != callpaths.end();
                          callpath_it++ )
                    {
                        IncrementalPoint* point = &measurements[ ( *metric_it )->getId() ]
                                                  [ ( *callpath_it )->getId() ];
                        cube::Cnode* cnode = mapping.getCubeCallpath( *callpath_it );
                        readValueFromCube( point, cube, metric, cnode, this->m_scaling_type );
                    }
                }
                //Invokes the callback to the GUI
                this->make_progress();
            }
            // Iterate over all metrics and callpaths and create the experiment point
            for ( MetricList::const_iterator metric_it = metrics.begin();
                  metric_it != metrics.end();
                  metric_it++ )
            {
                int metric_id = ( *metric_it )->getId();
                for ( CallpathList::const_iterator callpath_it = callpaths.begin();
                      callpath_it != callpaths.end();
                      callpath_it++ )
                {
                    int               callpath_id = ( *callpath_it )->getId();
                    IncrementalPoint& ip          = measurements[ metric_id ][ callpath_id ];
                    ExperimentPoint*  point       = ip.getExperimentPoint( coordinates,
                                                                           *metric_it,
                                                                           *callpath_it );

                    experiment->addDataPoint( point,
                                              **metric_it,
                                              **callpath_it );
                    measurements[ metric_id ][ callpath_id ].clear();
                }
            }
        }
        // Cleanup
        delete cube;
    }
    catch ( ... )
    {
        ErrorStream << "Caught an exception while reading Cubes" << std::endl;
        //std::cout << "Caught an exception while reading Cubes" << std::endl;
        return NULL;
    }
    DebugStream << "Finished Processing Cubes" << std::endl;
    return experiment;
}

void
CubeFileReader::clear()
{
    this->m_callback_function = NULL;
    this->m_parameter_value_lists.clear();
    this->m_scaling_type = -1;
    this->m_dir.clear();
    this->m_prefix.clear();
    this->m_postfix.clear();
    this->m_parameter_values.clear();
    this->m_parameters.clear();
    this->m_parameter_prefixes.clear();
    this->m_reps = -1;
    this->m_cube_file_name.clear();
    this->m_use_input_file_name_list = false;
    this->m_use_reps_postfix         = false;
}

bool
CubeFileReader::isReadyToRead() const
{
    bool result = true;
    result &= this->m_scaling_type != -1;
    result &= !this->m_dir.empty();
    result &= !this->m_prefix.empty();
    result &= this->m_parameter_values.size() > 0;
    result &= this->m_parameters.size() > 0;
    result &= this->m_parameter_prefixes.size() > 0;
    result &= this->m_reps != -1;
    result &= !this->m_cube_file_name.empty();
    return result;
}

CubeFileReader::CubeFileReader()
{
    this->clear();
}
void
CubeFileReader::prepareCubeFileReader( int                scaling_type,
                                       const std::string& dir,
                                       const std::string& prefix,
                                       const std::string& postfix,
                                       const std::string& cubeFileName,
                                       int                reps )
{
    this->clear();
    this->m_scaling_type   = scaling_type;
    this->m_dir            = dir;
    this->m_prefix         = prefix;
    this->m_postfix        = postfix;
    this->m_cube_file_name = cubeFileName;
    this->m_reps           = reps;
}

void
CubeFileReader::prepareCubeFileReader( const std::string& pathToCubeConf )
{
    this->clear();
    std::ifstream dataFile;
    dataFile.open( pathToCubeConf.c_str(), std::ios::in );
    std::string lineString;
    std::string fieldName;
    if ( dataFile.is_open() == false )
    {
        ErrorStream << "Unable to open the test data file "
                    << pathToCubeConf
                    << std::endl;
        return;
    }
    std::vector<Value> data_points;
    while ( !dataFile.eof() )
    {
        getline( dataFile, lineString, '\n' );

        if ( lineString.empty() )
        {
            continue;
        }
        if ( lineString.c_str()[ 0 ] == '#' )
        {
            continue;
        }

        std::istringstream iss( lineString );
        iss >> fieldName;

        if ( fieldName == "DIR" )
        {
            iss >> this->m_dir;
        }
        else if ( fieldName == "PREFIX" )
        {
            iss >> this->m_prefix;
        }
        else if ( fieldName == "POSTFIX" )
        {
            iss >> this->m_postfix;
        }
        else if ( fieldName == "FILENAME" )
        {
            iss >> this->m_cube_file_name;
        }
        else if ( fieldName == "m_reps" )
        {
            iss >> this->m_reps;
        }
        else if ( fieldName == "X" )
        {
            std::vector<int> values;
            int              val;
            this->m_parameters.push_back( Parameter( "X" ) );
            this->m_parameter_prefixes.push_back( "x" );
            while ( !iss.eof() )
            {
                iss >> val;
                values.push_back( val );
            }
            this->m_parameter_values.push_back( values );
        }
        else if ( fieldName == "d" )
        {
            std::vector<int> values;
            int              val;
            this->m_parameters.push_back( Parameter( "o" ) );
            this->m_parameter_prefixes.push_back( "y" );
            while ( !iss.eof() )
            {
                iss >> val;
                values.push_back( val );
            }
            this->m_parameter_values.push_back( values );
        }
        else if ( fieldName == "g" )
        {
            std::vector<int> values;
            int              val;
            this->m_parameters.push_back( Parameter( "p" ) );
            this->m_parameter_prefixes.push_back( "z" );
            while ( !iss.eof() )
            {
                iss >> val;
                values.push_back( val );
            }
            this->m_parameter_values.push_back( values );
        }
        else
        {
            continue;
        }
    }
    dataFile.close();
}
void
CubeFileReader::prepareCubeFileReader( int                                   scaling_type,
                                       const std::string&                    dir,
                                       const std::string&                    prefix,
                                       const std::string&                    postfix,
                                       const std::string&                    cubeFileName,
                                       const ParameterList&                  parameters,
                                       const std::vector<std::string>&       parameterPrefixes,
                                       const std::vector<std::vector<int> >& parameterValues,
                                       int                                   reps )
{
    this->clear();
    this->m_scaling_type       = scaling_type;
    this->m_dir                = dir;
    this->m_prefix             = prefix;
    this->m_postfix            = postfix;
    this->m_cube_file_name     = cubeFileName;
    this->m_parameters         = parameters;
    this->m_parameter_prefixes = parameterPrefixes;
    this->m_parameter_values   = parameterValues;
    this->m_reps               = reps;
}

void
CubeFileReader::make_progress() const
{
    if ( this->m_callback_function == NULL )
    {
        return;
    }
    else
    {
        this->m_callback( this->m_callback_function );
        return;
    }
}

void
CubeFileReader::setCallbackFunction( CallbackFunction cb, void* func )
{
    this->m_callback          = cb;
    this->m_callback_function = func;
    return;
}
};
