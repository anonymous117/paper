/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */
#include <config.h>
#include <EXTRAP_Interface.hpp>
#include <cmath>
#include <realtime/EXTRAP_RealtimeDataPoint.hpp>

namespace EXTRAP
{
RealtimeDataPoint::RealtimeDataPoint( EXTRAP::Value data,
                                      Region*       region,
                                      Metric*       metric )
    : m_region( region ),
    m_metric( metric )
{
    this->m_mean               = data;
    this->m_maximum            = data;
    this->m_minimum            = data;
    this->m_median             = data;
    this->m_sample_count       = 1;
    this->m_standard_deviation = 0.0;

    EXTRAP::Interval ci;
    ci.start = data;
    ci.end   = data;

    this->m_confidence_interval_mean   = ci;
    this->m_confidence_interval_median = ci;

    this->m_approx_median     = new EXTRAP::QuantileApproximator( 0.5 );
    this->m_approx_5_percent  = new EXTRAP::QuantileApproximator( 0.05 );
    this->m_approx_95_percent = new EXTRAP::QuantileApproximator( 0.95 );

    this->m_approx_median->Update( data );
    this->m_approx_5_percent->Update( data );
    this->m_approx_95_percent->Update( data );
}

EXTRAP::Value
RealtimeDataPoint::updateAverage( EXTRAP::Value old_average, int old_sample_count, EXTRAP::Value new_point )
{
    /* old_average = sum(old_points) / old_sample_count
     *
     * old_sum_of_points = old_average * old_sample_count
     * new_sum_of_points = old_sum_of_points + new_point
     * new_sample_count = old_sample_count + 1
     *
     * new_average = new_sum_of_points / new_sample_count
     */

    return ( old_average * old_sample_count + new_point ) / ( old_sample_count + 1.0 );
}

EXTRAP::Value
RealtimeDataPoint::updateStdDeviation( EXTRAP::Value old_deviation, EXTRAP::Value old_average, int old_sample_count,
                                       EXTRAP::Value new_point )
{
    /* deviation = sqrt(sum((point - average)^2) / sample_count)
     *           = sqrt(sum(point^2 - 2 * point * average + average^2) / sample_count)
     *           = sqrt((sum(point^2 - 2 * point * average) + sample_count * average^2) / sample_count)
     *           = sqrt((sum(point^2) - 2 * average * sum(point) + sample_count * average^2) / sample_count)
     *           = sqrt((sum(point^2) - 2 * average^2 * sample_count + sample_count * average^2) / sample_count)
     *           = sqrt((sum(point^2) - average^2 * sample_count) / sample_count)
     *           = sqrt(sum(point^2) / sample_count - average^2)
     *
     * deviation^2 = sum(point^2) / sample_count - average^2
     * deviation^2 + average^2 = sum(point^2) / sample_count
     * sum(point^2) = (deviation^2 + average^2) * sample_count
     *
     * old_sum_of_points_squared = (old_deviation^2 + old_average^2) * old_sample_count
     * new_sum_of_points_squared = old_sum_of_points_squared + new_point^2
     * new_sample_count = old_sample_count + 1
     *
     * new_deviation = sqrt(new_sum_of_points_squared / new_sample_count - new_average^2)
     */

    EXTRAP::Value old_sum_of_points_squared = ( pow( old_deviation, 2 ) + pow( old_average, 2 ) ) * old_sample_count;
    EXTRAP::Value new_sum_of_points_squared = old_sum_of_points_squared + pow( new_point, 2 );
    EXTRAP::Value new_average               = updateAverage( old_average, old_sample_count, new_point );

    return sqrt( new_sum_of_points_squared / ( old_sample_count + 1.0 ) - pow( new_average, 2 ) );
}

void
RealtimeDataPoint::update( EXTRAP::Value newValue )
{
    this->m_approx_median->Update( newValue );
    this->m_approx_5_percent->Update( newValue );
    this->m_approx_95_percent->Update( newValue );

    this->m_standard_deviation = updateStdDeviation( this->getStandardDeviation(),
                                                     this->getMean(), this->getSampleCount(), newValue );

    // mean has to be computed after standard deviation because updateStdDeviation expects the old average value
    this->m_mean = updateAverage( this->getMean(), this->getSampleCount(), newValue );

    this->m_sample_count = this->getSampleCount() + 1;

    EXTRAP::Interval ci = computeTConfidenceInterval( this->m_mean, this->m_standard_deviation, this->m_sample_count, EXTRAP_TVALUES );

    this->m_confidence_interval_mean.start = ci.start;
    this->m_confidence_interval_mean.end   = ci.end;

    this->m_median                           = this->m_approx_median->GetQuantileValue();
    this->m_confidence_interval_median.start = this->m_approx_5_percent->GetQuantileValue();
    this->m_confidence_interval_median.end   = this->m_approx_95_percent->GetQuantileValue();

    this->m_minimum = this->getMinimum() <= newValue ? this->getMinimum() : newValue;
    this->m_maximum = this->getMaximum() >= newValue ? this->getMaximum() : newValue;
}

int
RealtimeDataPoint::getSampleCount( void ) const
{
    return m_sample_count;
}

Value
RealtimeDataPoint::getMean( void ) const
{
    return m_mean;
}

Interval
RealtimeDataPoint::getMeanCI( void ) const
{
    return m_confidence_interval_mean;
}

Value
RealtimeDataPoint::getStandardDeviation( void ) const
{
    return m_standard_deviation;
}

Value
RealtimeDataPoint::getMedian( void ) const
{
    return m_median;
}

Interval
RealtimeDataPoint::getMedianCI( void ) const
{
    return m_confidence_interval_median;
}

Value
RealtimeDataPoint::getMinimum( void ) const
{
    return m_minimum;
}

Value
RealtimeDataPoint::getMaximum( void ) const
{
    return m_maximum;
}

Region*
RealtimeDataPoint::getRegion( void ) const
{
    return m_region;
}

Metric*
RealtimeDataPoint::getMetric( void ) const
{
    return m_metric;
}
}; // Close namespace
