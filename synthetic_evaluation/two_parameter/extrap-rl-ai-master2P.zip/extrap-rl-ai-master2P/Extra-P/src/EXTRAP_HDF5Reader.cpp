/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_Types.hpp>
#include <EXTRAP_HDF5Reader.hpp>
using namespace H5;
namespace EXTRAP
{
const std::string HDF5Reader::H5_METRIC_ATTRIBUTE     = "METRIC";
const std::string HDF5Reader::H5_UNIT_ATTRIBUTE       = "UNIT";
const std::string HDF5Reader::H5_PARAMETER_ATTRIBUTE  = "PARAMETER";
const std::string HDF5Reader::H5_VALUES_ATTRIBUTE     = "VALUES";
const std::string HDF5Reader::H5_SOURCE_ATTRIBUTE     = "SOURCE";
const std::string HDF5Reader::H5_SOURCELINE_ATTRIBUTE = "LINE";
const StrType     HDF5Reader::H5_STR_TYPE             = StrType( PredType::C_S1, H5T_VARIABLE );
HDF5Reader::HDF5Reader( const std::string& filename ) : m_filename( filename )
{
    this->m_regions.clear();
    this->m_metrics.clear();
}

HDF5Reader::~HDF5Reader()
{
    delete( this->m_file );
}

bool
HDF5Reader::prepare_coordinate_vectors( std::vector<std::vector<Value> >& paramValues )
{
    switch ( this->m_parameters.size() )
    {
        case 1:
        {
            this->m_coordinates1D.resize( paramValues[ 0 ].size() );
            break;
        }
        case 2:
        {
            this->m_coordinates2D.resize( paramValues[ 0 ].size() );
            for ( int i = 0; i < paramValues[ 0 ].size(); i++ )
            {
                this->m_coordinates2D[ i ] = std::vector<Coordinate*>();
                this->m_coordinates2D[ i ].resize( paramValues[ 1 ].size() );
            }
            break;
        }
        case 3:
        {
            this->m_coordinates3D.resize( paramValues[ 0 ].size() );
            for ( int i = 0; i < paramValues[ 0 ].size(); i++ )
            {
                this->m_coordinates3D[ i ] = std::vector<std::vector<Coordinate*> >();
                this->m_coordinates3D[ i ].resize( paramValues[ 1 ].size() );
                for ( int j = 0; j < paramValues[ 1 ].size(); j++ )
                {
                    this->m_coordinates3D[ i ][ j ] = std::vector<Coordinate*>();
                    this->m_coordinates3D[ i ][ j ].resize( paramValues[ 2 ].size() );
                }
            }
            break;
        }
        default:
        {
            ErrorStream << "Only up to 3 dimensions are supported" << std::endl;
            return false;
        }
    }
    return true;
}

bool
HDF5Reader::readData( const H5File* file )
{
    this->m_experiment = new Experiment();
    Group* group = new Group( file->openGroup( "/" ) );
    if ( !this->process_root_group( group ) )
    {
        delete( group );
        return false;
    }
    if ( !this->process_group( group, NULL, std::string( "/" ) ) )
    {
        delete( group );
        return false;
    }
    delete( group );
    return true;
}

Region*
HDF5Reader::extract_region( const std::string& regName, const Group* group, const Attribute* sourceAttr, const Attribute* lineAttr )
{
    Region* res;
    if ( this->m_regions.find( regName ) != this->m_regions.end() )
    {
        res = this->m_regions.find( regName )->second;
        return res;
    }
    else
    {
        char* sourceFile;
        sourceAttr->read( sourceAttr->getStrType(), &sourceFile );
        std::string* source = new std::string( sourceFile );
        int          line;
        lineAttr->read( PredType::NATIVE_INT64, &line );
        Region*                               newRegion = new Region( regName, *source, line );
        std::pair<const std::string, Region*> newPair   = std::pair<const std::string, Region*>( regName, newRegion );
        this->m_regions.insert( newPair );
        return newRegion;
    }
}

Metric*
HDF5Reader::extract_metric( const std::string& metricName, const Group* group, const Attribute* unitAttr )
{
    Metric* res;
    if ( this->m_metrics.find( metricName ) != this->m_metrics.end() )
    {
        res = this->m_metrics.find( metricName )->second;
    }
    else
    {
        char* unit;
        unitAttr->read( unitAttr->getStrType(), &unit );
        res = new Metric( metricName, unit );
        this->m_metrics.insert( std::pair<const std::string, Metric*>( metricName, res ) );
        this->m_experiment->addMetric( res );
    }
    return res;
}

bool
HDF5Reader::create_coordinate_rec( int paramIndex, std::vector<std::vector<Value> >& paramValues, std::vector<Value>indexVector, Coordinate cand )
{
    if ( paramIndex == this->m_parameters.size() )
    {
        Coordinate* newCoordinate = new Coordinate( cand );
        switch ( this->m_parameters.size() )
        {
            case 1:
            {
                this->m_coordinates1D[ indexVector[ 0 ] ] = newCoordinate;
                break;
            }
            case 2:
            {
                this->m_coordinates2D[ indexVector[ 0 ] ][ indexVector[ 1 ] ] = newCoordinate;
                break;
            }
            case 3:
            {
                this->m_coordinates3D[ indexVector[ 0 ] ][ indexVector[ 1 ] ][ indexVector[ 2 ] ] = newCoordinate;
                break;
            }
            default:
            {
                ErrorStream << "Only up to 3 dimensions are supported" << std::endl;
                return false;
            }
        }
        this->m_experiment->addCoordinate( newCoordinate );
    }
    else
    {
        Parameter param = this->m_parameters[ paramIndex ];
        for ( int i = 0; i < paramValues[ paramIndex ].size(); i++ )
        {
            cand.insert( std::pair<Parameter, Value>( param, paramValues[ paramIndex ][ i ] ) );
            indexVector.push_back( i );
            create_coordinate_rec( paramIndex + 1, paramValues, indexVector, cand );
            cand.erase( param );
            indexVector.pop_back();
        }
    }
    return true;
}
bool
HDF5Reader::process_root_group( const Group* root )
{
    Attribute* paramsAttr;
    try{
        paramsAttr = new Attribute( root->openAttribute( H5_PARAMETER_ATTRIBUTE ) );
    }
    catch ( const AttributeIException& e )
    {
        return false;
    }
    DataSpace* paramDataspace = new DataSpace( paramsAttr->getSpace() );
    hsize_t    dims           = 0;
    paramDataspace->getSimpleExtentDims( &dims );
    delete( paramDataspace );
    char** paramNames = new char*[ dims ];
    paramsAttr->read( paramsAttr->getStrType(), ( void* )paramNames );
    delete( paramsAttr );
    for ( int i = 0; i < dims; i++ )
    {
        Parameter p = Parameter( paramNames[ i ] );
        this->m_parameters.push_back( p );
        this->m_experiment->addParameter( p );
    }
    delete( paramNames );
    //Read ParamValues
    std::vector<std::vector<Value> >values;
    for ( int i = 0; i < this->m_parameters.size(); i++ )
    {
        Attribute* paramValuesAttr;
        try{
            paramValuesAttr = new Attribute( root->openAttribute( this->m_parameters[ i ].getName() ) );
        }
        catch ( const AttributeIException& e )
        {
            return false;
        }
        DataSpace* paramValuesDataspace = new DataSpace( paramValuesAttr->getSpace() );
        hsize_t    dims                 = 0;
        paramValuesDataspace->getSimpleExtentDims( &dims );
        delete( paramValuesDataspace );
        std::vector<Value> valuesForParam;
        valuesForParam.resize( dims );
        paramValuesAttr->read( PredType::NATIVE_DOUBLE, valuesForParam.data() );
        delete( paramValuesAttr );
        values.push_back( valuesForParam );
    }
    if ( !this->prepare_coordinate_vectors( values ) )
    {
        return false;
    }
    //Create coordinates
    Coordinate         c;
    std::vector<Value> indexes;
    if ( !create_coordinate_rec( 0, values, indexes, c ) )
    {
        return false;
    }
    return true;
}

bool
HDF5Reader::process_group( const Group* group, Callpath* possibleParent, const std::string& str )
{
    size_t                                   delimiter     = str.find_last_of( "/" );
    hsize_t                                  numObjs       = group->getNumObjs();
    Callpath*                                this_callpath = NULL;
    Metric*                                  metric        = NULL;
    std::map<Coordinate*, IncrementalPoint*> coordinatesToIncrementalpoints;
    //Check if the group refers to a metric
    try{
        Exception::dontPrint();
        Attribute* unitAttribute = new Attribute( group->openAttribute( H5_UNIT_ATTRIBUTE ) );
        //This group represents a metric
        std::string metricName = str.substr( delimiter + 1, str.length() );
        metric = extract_metric( metricName, group, unitAttribute );
        delete( unitAttribute );
        coordinatesToIncrementalpoints.clear();
        if ( metric == NULL )
        {
            ErrorStream << "Failed to extract Metric " << metricName << std::endl;
            return false;
        }
    }
    catch ( const AttributeIException& e )
    {
    }
    //Check if the group refers to a region
    try{
        Exception::dontPrint();
        Attribute* sourceAttribute = new Attribute( group->openAttribute( H5_SOURCE_ATTRIBUTE ) );
        Attribute* lineAttribute   = new Attribute( group->openAttribute( H5_SOURCELINE_ATTRIBUTE ) );
        //All Other cases mean this is a Region/Callpath Group
        //std::string regionName = str.substr( delimiter + 1, str.length() - 1 );
        std::string regionName = str.substr( delimiter + 1, str.length() );
        Region*     reg        = extract_region( regionName.c_str(), group, sourceAttribute, lineAttribute );
        delete( sourceAttribute );
        delete( lineAttribute );
        if ( reg == NULL )
        {
            ErrorStream << "Failed to extract Region " << regionName << std::endl;
            return false;
        }
        this->m_experiment->addRegion( reg );
        this_callpath = new Callpath( reg, possibleParent );
        this->m_experiment->addCallpath( this_callpath );
    }
    catch ( const AttributeIException& e )
    {
    }
    //Process ChildElements
    if ( numObjs != 0 )
    {
        for ( int i = 0; i < numObjs; i++ )
        {
            std::string objName = group->getObjnameByIdx( i );
            if ( group->getObjTypeByIdx( i ) == H5O_TYPE_GROUP )
            {
                Group* g = new Group( group->openGroup( objName ) );
                if ( !this->process_group( g, this_callpath, objName ) )
                {
                    ErrorStream << "Failed to process Group " << objName << std::endl;
                    delete( g );
                    return false;
                }
                delete( g );
            }
            else if ( group->getObjTypeByIdx( i ) == H5O_TYPE_DATASET )
            {
                DataSet* dataset = new DataSet( group->openDataSet( objName ) );
                if ( !this->process_dataset( dataset, metric, possibleParent, coordinatesToIncrementalpoints ) )
                {
                    ErrorStream << "Failed to process DataSet " << objName << std::endl;
                    delete( dataset );
                    return false;
                }
                delete( dataset );
            }
        }
    }
    if ( metric != NULL )
    {
        return this->create_experiment_points( possibleParent, metric, coordinatesToIncrementalpoints );
    }
    return true;
}

bool
HDF5Reader::create_experiment_points( Callpath* cp, Metric* m, std::map<Coordinate*, IncrementalPoint*>& coordinatesToIncrementalpoints )
{
    int count = 0;
    for ( std::map<Coordinate*, IncrementalPoint*>::const_iterator it = coordinatesToIncrementalpoints.begin(); it != coordinatesToIncrementalpoints.end(); it++ )
    {
        this->m_experiment->addDataPoint( it->second->getExperimentPoint( it->first, m, cp ), *m, *cp );
        delete( it->second );
        count++;
    }
    coordinatesToIncrementalpoints.clear();
    return true;
}
bool
HDF5Reader::process_dataset( const DataSet* set, const Metric* metric, const Callpath* callpath, std::map<Coordinate*, IncrementalPoint*>& coordinatesToIncrementalpoints )
{
    DataSpace* dataSpace = new DataSpace( set->getSpace() );
    hsize_t    dims[ dataSpace->getSimpleExtentNdims() ];
    dataSpace->getSimpleExtentDims( dims );
    Coordinate* c;
    switch ( dataSpace->getSimpleExtentNdims() )
    {
        //Case for reading only onedimensional data
        case 1:
        {
            Value data[ dims[ 0 ] ];
            set->read( data, PredType::NATIVE_DOUBLE );
            for ( int j = 0; j < dims[ 0 ]; j++ )
            {
                c = this->m_coordinates1D[ j ];
                if ( coordinatesToIncrementalpoints.find( c ) != coordinatesToIncrementalpoints.end() )
                {
                    IncrementalPoint* point = coordinatesToIncrementalpoints.find( c )->second;
                    point->addValue( data[ j ] );
                }
                else
                {
                    IncrementalPoint* newIncrementalPoint = new IncrementalPoint();
                    newIncrementalPoint->addValue( data[ j ] );
                    coordinatesToIncrementalpoints.insert( std::pair<Coordinate*, IncrementalPoint*>( c, newIncrementalPoint ) );
                }
            }
            delete( dataSpace );
            return true;
        }
        //Case for reading only twodimensional data
        case 2:
        {
            Value data[ dims[ 0 ] ][ dims[ 1 ] ];
            set->read( data, PredType::NATIVE_DOUBLE );
            for ( int i = 0; i < dims[ 0 ]; i++ )
            {
                for ( int j = 0; j < dims[ 1 ]; j++ )
                {
                    c = this->m_coordinates2D[ i ][ j ];
                    if ( coordinatesToIncrementalpoints.find( c ) != coordinatesToIncrementalpoints.end() )
                    {
                        IncrementalPoint* point = coordinatesToIncrementalpoints.find( c )->second;
                        point->addValue( data[ i ][ j ] );
                    }
                    else
                    {
                        IncrementalPoint* newIncrementalPoint = new IncrementalPoint();
                        newIncrementalPoint->addValue( data[ i ][ j ] );
                        coordinatesToIncrementalpoints.insert( std::pair<Coordinate*, IncrementalPoint*>( c, newIncrementalPoint ) );
                    }
                }
            }
            delete( dataSpace );
            return true;
        }
        //Case for reading only threedimensional data
        case 3:
        {
            Value data[ dims[ 0 ] ][ dims[ 1 ] ][ dims[ 2 ] ];
            set->read( data, PredType::NATIVE_DOUBLE );
            for ( int i = 0; i < dims[ 0 ]; i++ )
            {
                for ( int j = 0; j < dims[ 1 ]; j++ )
                {
                    for ( int k = 0; k < dims[ 2 ]; k++ )
                    {
                        c = this->m_coordinates3D[ i ][ j ][ k ];
                        if ( coordinatesToIncrementalpoints.find( c ) != coordinatesToIncrementalpoints.end() )
                        {
                            IncrementalPoint* point = coordinatesToIncrementalpoints.find( c )->second;
                            point->addValue( data[ i ][ j ][ k ] );
                        }
                        else
                        {
                            IncrementalPoint* newIncrementalPoint = new IncrementalPoint();
                            newIncrementalPoint->addValue( data[ i ][ j ][ k ] );
                            coordinatesToIncrementalpoints.insert( std::pair<Coordinate*, IncrementalPoint*>( c, newIncrementalPoint ) );
                        }
                    }
                }
            }
            delete( dataSpace );
            return true;
        }
        default:
        {
            ErrorStream << "Currently there is no support for more than 3 dimensions" << std::endl;
            return false;
        }
    }
}

Experiment*
HDF5Reader::read()
{
    if ( H5File::isHdf5( this->m_filename ) )
    {
        this->m_file = new H5File( this->m_filename, H5F_ACC_RDONLY );
        if ( !this->readData( this->m_file ) )
        {
            return NULL;
        }
    }
    else
    {
        ErrorStream << "File " << this->m_filename << " is not a valid HDF5 File" << std::endl;
        return NULL;
    }
    return this->m_experiment;
}
};
