##/*
## * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
## *
## * Copyright (c) 2019,
## * Technische Universitaet Darmstadt, Germany
## *
## * This software may be modified and distributed under the terms of
## * a BSD-style license.  See the COPYING file in the package base
## * directory for details.
## *
## */

"""Extra-P Synthetic Data Creation Tool.

Usage:
  extrap-data run [--name=<n>] [-i=<i>] [-r=<r>] [-n=<a>] [-s=<s>] [--count=<c>] [--minp=<x>] [--so=<y>] [--mo=<z>] [--rep=<f>] [--debug]
  extrap-data -h | --help
  extrap-data --version

Options:
  --name=<n>    Select the source folder name for the evaluation.
  -i=<i>    Number of iterations.
  -r=<r>    Number of repetitions.
  -n=<a>    Set the noise percent for the measurements.
  -s=<s>    Set the seed.
  --count=<c>   Set the start number for the output folders.
  --debug   Set log level to debug. Lowest log level.
  --minp=<x>    Set the minimum number of points required for the single parameter experiments [4,5,6,7].
  --so=<y>      Set the option for the single parameter point selection strategy [0,1,2].
  --mo=<z>      Set the option for the multi parameter point selection strategy [0,1].
  --rep=<f>     Set the number of repetitions per measurement point.
"""

import logging
import sys
import os
import shutil
import re
import numpy as np
import csv
import random
import EXTRAP
from math import *
from extrap.docopt import docopt

def parse_to_python_function(function):
    # remove leading + for the first coefficient
    if function[0] == ' ':
        function = function[1:]
    if function[0] == '+':
        function = function[1:]
    if function[0] == ' ':
        function = function[1:]
    # replace power operator ^ with **
    while True:
        id = 0
        complete = True
        for i in range(0,len(function)):
            if function[i] == '^':
                id = i
                complete = False
                break
        if complete == True:
            break
        temp = function[:id]
        temp2 = function[id+2:]
        exponent = function[id+1]
        temp2 = '**' + exponent + temp2
        function = temp + temp2
    # replace log operator log2(x) with log(x,2)
    while True:
        id = function.find('log2')
        if id == -1:
            break
        else:
            temp = function[:id]
            temp2 = function[id+4:]
            bracket1 = temp2.find('(')
            bracket2 = temp2.find(')')
            parameter = temp2
            parameter = parameter[bracket1+1:]
            idd = parameter.find(')')
            parameter = parameter[:idd]
            temp3 = temp2[:bracket1]
            temp4 = temp2[bracket2+1:]
            temp2 = temp3 + temp4
            function = temp + 'log(' + parameter + ',2)' + temp2
    return function

def set_log_level(arguments):
    if arguments['--debug']:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

if __name__ == '__main__':
    args = docopt(__doc__, version='Extra-P Evaluation Tool.')
    set_log_level(args)

    if args['run']:
        # check options parsed
        if args['--name']:
            folder_name = str(args['--name'])
        if args['-i']:
            iterations = int(args['-i'])
        else:
            iterations = 100
        if args['-r']:
            repetitions = int(args['-r'])
        else:
            repetitions = 10
        if args['-n']:
            noise_percent = float(args['-n'])
        else:
            noise_percent = 0.0
        if args['-s']:
            seed = int(args['-s'])
        else:
            seed = 1
        if args['--count']:
            count = int(args['--count'])
        else:
            count = 0
        if args['--minp']:
            min_p = int(args['--minp'])
        else:
            min_p = 5
        if args['--so']:
            so = int(args['--so'])
        else:
            so = 0
        if args['--mo']:
            mo = int(args['--mo'])
        else:
            mo = 0
        if args['--rep']:
            rep = int(args['--rep'])
        else:
            rep = 5

        #[--minp=<x>] [--so=<y>] [--mo=<z>] 

        logging.info("Generating synthetic data in path '/"+str(folder_name)+"' with "+str(repetitions)+" repetitions, "+str(iterations)+" iterations, "+str(noise_percent)+"% noise, "+str(min_p)+" min. points per parameter and "+str(rep)+" repetitions per measurement point.")
        
        number_of_functions = iterations * repetitions
        
        # check if main dir exists
        if os.path.exists(folder_name+"/")==True:
            shutil.rmtree(folder_name+"/")
            logging.info("Existing data has been deleted.")

        # create folder system
        main_dir = folder_name+"/"
        config_path = main_dir + "config.txt"
        input_path = main_dir + "inputs/"
        ouput_path = main_dir + "outputs/"
        os.mkdir(main_dir)
        os.mkdir(input_path)
        os.mkdir(ouput_path)
        for i in range(repetitions):
            input_folder_path = input_path + str(i+count) + "/"
            output_folder_path = ouput_path + str(i+count) + "/"
            os.mkdir(input_folder_path)
            os.mkdir(output_folder_path)
        logging.info("Folder system has been created.")
        
        # set the data generation options
        function_category = EXTRAP.COMMON_CAT
        function_terms = 2
        # term contribution should be: epsilon=3*noise
        epsilon = 1.0
        if noise_percent == 0:
            epsilon = 1.0
        else:
            epsilon = noise_percent * 3
        random.seed(0)

        # set options for the modelers
        generate_option   = EXTRAP.GENERATE_MODEL_MEAN
        if so == 0:
            single_option     = EXTRAP.FIRST_POINTS_FOUND
        elif so == 1:
            single_option     = EXTRAP.MAX_NUMBER_POINTS
        else:
            single_option     = EXTRAP.CHEAPEST_POINTS
        #single_option     = EXTRAP.FIRST_POINTS_FOUND
        if mo == 0:
            multi_option      = EXTRAP.INCREASING_COST
        else:
            multi_option      = EXTRAP.DECREASING_COST
        min_number_points = min_p

        # create the parameter list
        p    = EXTRAP.Parameter( "p" )
        size = EXTRAP.Parameter( "size" )
        parameter_list = []
        parameter_list.append(p)
        parameter_list.append(size)

        # create the measurement points
        measurement_points_param_p   = [ 4, 8, 16, 32, 64, 128, 256 ]
        measurement_points_param_size = [ 10, 20, 30, 40, 50, 60, 70 ]

        #measurement_points_param_p = [8,64,512,4096,32768]
        #measurement_points_param_size = [2,4,6,8,10]

        # set the metric
        metric_input = "metr"

        # write the config to file
        generatemodeloption = ""
        sinleoption         = ""
        multioption         = ""
        if ( generate_option == EXTRAP.GENERATE_MODEL_MEAN ):
            generatemodeloption = "GENERATE_MODEL_MEAN"
        else:
            generatemodeloption = "GENERATE_MODEL_MEDIAN"
        if ( single_option == EXTRAP.FIRST_POINTS_FOUND ):
            sinleoption = "FIRST_POINTS_FOUND"
        elif ( single_option == EXTRAP.MAX_NUMBER_POINTS ):
            sinleoption = "MAX_NUMBER_POINTS"
        elif ( single_option == EXTRAP.CHEAPEST_POINTS ):
            sinleoption = "CHEAPEST_POINTS"
        if ( multi_option == EXTRAP.INCREASING_COST ):
            multioption = "INCREASING_COST"
        else:
            multioption = "DECREASING_COST"
        config_file = open(config_path, "w")
        config_file.write("generate model options: "+str(generatemodeloption))
        config_file.write("\nsingle parameter points strategy: "+str(sinleoption))
        config_file.write("\nmulti parameter points strategy: "+str(multioption))
        config_file.write("\nnumber minimum points: "+str(min_number_points))
        config_file.write("\nmeasurement points for p: ["+str(measurement_points_param_p[0])+","+str(measurement_points_param_p[1])+","+str(measurement_points_param_p[2])+","+str(measurement_points_param_p[3])+","+str(measurement_points_param_p[4])+"]")
        config_file.write("\nmeasurement points for size: ["+str(measurement_points_param_size[0])+","+str(measurement_points_param_size[1])+","+str(measurement_points_param_size[2])+","+str(measurement_points_param_size[3])+","+str(measurement_points_param_size[4])+"]")
        config_file.write("\nnoise percent: "+str(noise_percent))
        config_file.write("\nepsilon, term contribution minimum: "+str(epsilon))
        config_file.close()
        logging.info("Configuration was written to file.")

        # init the function generator
        function_generator = EXTRAP.MultiParamFunctionGenerator( function_category, function_terms, parameter_list, epsilon, seed )

        # init function vector for saving the results
        functions = []

        # run the synthetic data generation process
        for i in range(repetitions):

            for j in range(iterations):

                # generate a random function
                baseline_function        = function_generator.getFunction()
                baseline_function_string = baseline_function.getAsString( parameter_list )

                logging.debug("Basline: "+str(baseline_function_string))

                functions.append( baseline_function_string )

                # create file path for the input file
                input_file_path = input_path + str(i+count) + "/input_" + str(j) + ".txt"

                # save measurements to the input file
                input_file = open(input_file_path, "w")
                
                for a in range(min_p):
                    
                    for b in range(min_p):

                        p = measurement_points_param_p[ a ]
                        size = measurement_points_param_size[ b ]
                        python_function = parse_to_python_function(baseline_function_string)
                        measurement = eval(python_function)
                        
                        for _ in range(rep):
                            # add noise to the measurements
                            value = measurement
                            #print("actual:",value)
                            sigma = value * ( noise_percent / 100.0 )
                            #print("sigma:",sigma)
                            f = random.uniform(-1.0, 1.0)
                            #print("f:",f)
                            noise = f * sigma
                            #print("noise:",noise)
                            value = value + noise
                            #print("value with noise:",value)
                            output = "{\"params\":{\"p\":" + str(measurement_points_param_p[ a ]) + "," + "\"size\":" + str(measurement_points_param_size[ b ]) + "},\"metric\":\"" + str(metric_input) + "\",\"value\":" + str(value) + "}\n"
                            input_file.write(output)

                input_file.close()

                # run normal multi parameter modeler with all 25 points
                experiment       = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics          = experiment.getMetrics()
                callpaths        = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                mparam_generator = EXTRAP.MultiParameterSimpleModelGenerator()
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( single_option )
                options.setMultiPointsStrategy( multi_option )
                options.setUseAddPoints( False )
                options.setNumberAddPoints( 0 )
                model_generator = mparam_generator
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                normal_function = model.getModelFunction()
                normal_function_string = normal_function.getAsString(experiment.getParameters())
                functions.append( normal_function_string )
                logging.debug("Normal model: "+str(normal_function_string))


                # run sparse modeler with base, 9 points
                sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
                model_generator = sparse_modeler
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( EXTRAP.CHEAPEST_POINTS )
                options.setMultiPointsStrategy( EXTRAP.INCREASING_COST )
                options.setUseAddPoints( False )
                options.setNumberAddPoints( 1 )
                experiment     = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics        = experiment.getMetrics()
                callpaths      = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                sparse_function = model.getModelFunction()
                sparse_function_string = sparse_function.getAsString(experiment.getParameters())
                functions.append( sparse_function_string )
                logging.debug("Sparse model 9: "+str(sparse_function_string))

                # run sparse modeler with 10 points, 1 additional point
                sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
                model_generator = sparse_modeler
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( EXTRAP.CHEAPEST_POINTS )
                options.setMultiPointsStrategy( EXTRAP.INCREASING_COST )
                options.setUseAddPoints( True )
                options.setNumberAddPoints( 1 )
                experiment     = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics        = experiment.getMetrics()
                callpaths      = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                sparse_function = model.getModelFunction()
                sparse_function_string = sparse_function.getAsString(experiment.getParameters())
                functions.append( sparse_function_string )
                logging.debug("Sparse model 10: "+str(sparse_function_string))

                # run sparse modeler with 11 points, 2 additional point
                sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
                model_generator = sparse_modeler
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( EXTRAP.CHEAPEST_POINTS )
                options.setMultiPointsStrategy( EXTRAP.INCREASING_COST )
                options.setUseAddPoints( True )
                options.setNumberAddPoints( 2 )
                experiment     = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics        = experiment.getMetrics()
                callpaths      = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                sparse_function = model.getModelFunction()
                sparse_function_string = sparse_function.getAsString(experiment.getParameters())
                functions.append( sparse_function_string )
                logging.debug("Sparse model 11: "+str(sparse_function_string))

                # run sparse modeler with 15 points, 6 additional point
                sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
                model_generator = sparse_modeler
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( EXTRAP.CHEAPEST_POINTS )
                options.setMultiPointsStrategy( EXTRAP.INCREASING_COST )
                options.setUseAddPoints( True )
                options.setNumberAddPoints( 6 )
                experiment     = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics        = experiment.getMetrics()
                callpaths      = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                sparse_function = model.getModelFunction()
                sparse_function_string = sparse_function.getAsString(experiment.getParameters())
                functions.append( sparse_function_string )
                logging.debug("Sparse model 15: "+str(sparse_function_string))

                # run sparse modeler with 20 points, 11 additional point
                sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
                model_generator = sparse_modeler
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( EXTRAP.CHEAPEST_POINTS )
                options.setMultiPointsStrategy( EXTRAP.INCREASING_COST )
                options.setUseAddPoints( True )
                options.setNumberAddPoints( 11 )
                experiment     = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics        = experiment.getMetrics()
                callpaths      = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                sparse_function = model.getModelFunction()
                sparse_function_string = sparse_function.getAsString(experiment.getParameters())
                functions.append( sparse_function_string )
                logging.debug("Sparse model 20: "+str(sparse_function_string))

                # run sparse modeler with 25 points, 16 additional point
                sparse_modeler  = EXTRAP.MultiParameterSparseModelGenerator()
                model_generator = sparse_modeler
                options = EXTRAP.ModelGeneratorOptions()
                options.setGenerateModelOptions( generate_option )
                options.setMinNumberPoints( min_number_points )
                options.setSinglePointsStrategy( EXTRAP.CHEAPEST_POINTS )
                options.setMultiPointsStrategy( EXTRAP.INCREASING_COST )
                options.setUseAddPoints( True )
                options.setNumberAddPoints( 16 )
                experiment     = EXTRAP.Experiment.openJsonInput( input_file_path )
                metrics        = experiment.getMetrics()
                callpaths      = experiment.getAllCallpaths()
                metric = metrics[0]
                call_path = callpaths[0]
                experiment.addModelGenerator( model_generator )
                experiment.modelAll( model_generator, experiment, options )
                models = experiment.getModels(metric, call_path)
                model = models[0]
                sparse_function = model.getModelFunction()
                sparse_function_string = sparse_function.getAsString(experiment.getParameters())
                functions.append( sparse_function_string )
                logging.debug("Sparse model 25: "+str(sparse_function_string))

               

                logging.debug("\n")
               
                # save the result data
                ouput_file_path = ouput_path + str(i+count) + "/modeler_result_" + str(j) + ".txt"
                output_file = open(ouput_file_path, "w")
                for k in range(len(functions)):
                    output2 = functions[k] + "\n"
                    output_file.write(output2)
                output_file.close()

                # clear the result vector
                functions.clear()
                
            
            logging.info("Repetition "+str(i+count)+" finished.")
        
        logging.info("Data generation finished. Results have been saved to "+str(main_dir)+".")