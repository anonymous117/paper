class Coordinate():
   
    def __init__(self, parameters, values):
        self.parameters = parameters
        self.values = values
        
    def out(self):
        print_string = ""
        for i in range(len(self.parameters)):
            print_string = print_string + "(" + str(self.parameters[i].get_name()) + ","
            print_string = print_string + str(self.values[i]) + ")"
        print(print_string)
        
    def get_parameters(self):
        return self.parameters
    
    def get_parameter(self, id):
        return self.parameters[id]

    def get_values(self):
        return self.values

    def get_value(self, id):
        return self.values[id]