import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from extrap.Util import smooth

class Cost():

    def __init__(self, cost):
        self.cost = cost
        self.percentage_cost()
        self.smooth_cost = smooth(self.cost, 0.9)

    def percentage_cost(self):
        for i in range(len(self.cost)):
            self.cost[i] *= 100

    def plot(self):
        ax = plt.subplot(111)
        ax.plot(self.cost, 'b-')
        ax.plot(self.smooth_cost, 'r-')
        # Hide the right and top spines
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        # Only show ticks on the left and bottom spines
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')
        ax.set_xlim(0,len(self.cost))
        ax.xaxis.labelpad = 10
        ax.yaxis.labelpad = 10
        plt.xlabel("Training epochs")
        plt.ylabel("Cost")
        plt.show()
    
    def save(self):
        cost_file = open("plotdata/costdata.t", "w")
        for i in range(len(self.cost)):
            cost_file.write(str(i+1)+" "+str(self.cost[i])+"\n")
        cost_file.close()
        smooth_cost_file = open("plotdata/smoothcostdata.t", "w")
        for i in range(len(self.smooth_cost)):
            smooth_cost_file.write(str(i+1)+" "+str(self.smooth_cost[i])+"\n")
        smooth_cost_file.close()