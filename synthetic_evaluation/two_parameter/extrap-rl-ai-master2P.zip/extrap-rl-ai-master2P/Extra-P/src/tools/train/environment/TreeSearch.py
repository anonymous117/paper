import copy
import numpy as np

class TreeSearch():
   
    def __init__(self, environment, agent):
        self.environment = copy.deepcopy(environment)
        self.init_env = copy.deepcopy(environment)
        self.init_state = self.init_env.get_state()
        self.agent = agent
        
    
    def search_tree(self, num_simulations):
        '''
        Do tree search on the different actions and figure out which leads to the highest reward
        '''
        # compute all the valid actions
        all_valid_actions = self.compute_all_valid_actions()
        all_valid_actions_first = all_valid_actions
        number_of_actions = len(all_valid_actions)

        # initialize result vector
        self.sourcing_results = []
        for _ in range(number_of_actions):
            self.sourcing_results.append(0)

        for _ in range(num_simulations):
            # initialize reward
            single_reward = 0

            # choose initial action
            q_values = self.agent.get_q_values(self.init_state)
            q_values = self.transform_q_values(q_values, all_valid_actions)
            cum_weights = self.calc_cum_weights(q_values)
            index, action = self.choose_action(cum_weights, q_values)
            first_action = action

            while True:
                # update the environment
                state_, reward, done, info = self.environment.step(action)
                state = state_

                # choose next action
                q_values = self.agent.get_q_values(state)
                all_valid_actions = self.compute_all_valid_actions()
                q_values = self.transform_q_values(q_values, all_valid_actions)
                cum_weights = self.calc_cum_weights(q_values)
                index, action = self.choose_action(cum_weights, q_values)

                # check if episode is done
                if done == True:
                    single_reward = reward
                    break

            # save the reward of the current tree rollout policy
            self.save_reward(first_action, all_valid_actions_first, single_reward)
            
            # reset environment for the next tree rollout
            self.environment = copy.deepcopy(self.init_env)

        # find the best policy and with that the best action for the initial state
        best_action = self.find_best_action(all_valid_actions_first)
        return best_action   

    def compute_all_valid_actions(self):
        '''
        Returns all valid actions in the current environment state
        '''
        valid_actions = []
        if self.environment.stage == 1:
            valid_actions.append(25)
            valid_actions.append(26)
            valid_actions.append(27)
            valid_actions.append(28)
            valid_actions.append(29)
        elif self.environment.stage == 2:
            valid_actions.append(30)
            valid_actions.append(31)
            valid_actions.append(32)
            valid_actions.append(33)
            valid_actions.append(34)
        else:
            for i in range(25):
                if self.environment.selected_points[i] == 0:
                    valid_actions.append(i)
        return valid_actions

    def transform_q_values(self, q_values, all_valid_actions):
        '''
        Returns the q-values per action in a list
        '''
        result = []
        for i in range(len(all_valid_actions)):
            action = all_valid_actions[i]
            action_value = q_values[0][action]
            result.append([action, action_value])
        return result
    
    def calc_cum_weights(self, q_values):
        '''
        Calculate the cumulated weights for the tree search
        '''
        sum = 0
        for i in range(len(q_values)):
            sum = sum + np.absolute(q_values[i][1])
        one_percent = sum / 100
        q_value_percentages = []
        for i in range(len(q_values)):
            id = q_values[i][0]
            q_value_percentage = (np.absolute(q_values[i][1]) / one_percent) / 100
            q_value_percentages.append([id,q_value_percentage])
        q_weights = []
        for i in range(len(q_value_percentages)):
            q_weight = q_value_percentages[i][1]
            q_weights.append(q_weight)
        cum_weights = [0] + list(np.cumsum(q_weights))
        return cum_weights

    def choose_action(self, cum_weights, q_values):
        '''
        Choose an action based on the calculated weights in the tree
        '''
        x = np.random.random()
        index = self.find_interval(x, cum_weights)
        action = q_values[index][0]
        return index, action

    def find_interval(self, x, partition):
        '''
        Find action that matches to weight range
        '''
        for i in range(0, len(partition)):
            if x < partition[i]:
                return i-1
        return -1

    def save_reward(self, first_action, all_valid_actions_first, new_reward_value):
        '''
        Saves the result of a tree rollout
        '''
        index = -1
        for i in range(len(all_valid_actions_first)):
            if(all_valid_actions_first[i] == first_action):
                index = i
        current_reward_value = self.sourcing_results[index]
        if(new_reward_value > current_reward_value):
            self.sourcing_results[index] = new_reward_value

    def find_best_action(self, all_valid_actions_first):
        '''
        Finds the best action for the inital state by searching for the policy with maximum reward
        '''
        max_value = 0
        index = -1
        for i in range(len(self.sourcing_results)):
            if(self.sourcing_results[i] > max_value):
                max_value = self.sourcing_results[i]
                index = i
        best_action = all_valid_actions_first[index]
        return best_action