from math import *
from random import randint
from extrap.Exponents import Exponents
from extrap.Coefficients import Coefficients

class Function():

    def __init__(self, epsilon, parameter_values):
        # term contribution minimum
        self.epsilon = epsilon
        self.parameter_values = parameter_values
        self.p_min = min(self.parameter_values[0])
        self.p_max = max(self.parameter_values[0])
        self.size_min = min(self.parameter_values[1])
        self.size_max = max(self.parameter_values[1])
        if len(self.parameter_values)==3:
            self.n_min = min(self.parameter_values[2])
            self.n_max = max(self.parameter_values[2])
        else:
            self.n_min = 0
            self.n_max = 0
        self.function = self.generate_function() 

    def generate_function(self):
        if len(self.parameter_values)==3:
            coefficient = Coefficients()
            # a+b+c function type
            if randint(0,1)==0:
                while(True):
                    c1 = coefficient.get_random_coefficient()
                    c2 = coefficient.get_random_coefficient()
                    c3 = coefficient.get_random_coefficient()
                    c4 = coefficient.get_random_coefficient()
                    a = self.generate_compound_term("p")
                    b = self.generate_compound_term("size")
                    c = self.generate_compound_term("n")
                    function = str(c1) + "+" + str(c2) + "*" + a + "+" + str(c3) + "*" + b + "+" + str(c4) + "*" + c
                    term_a = str(c2) + "*" + a
                    term_b = str(c3) + "*" + b
                    term_c = str(c4) + "*" + c
                    term_results_min = []
                    term_results_max = []
                    p = self.p_min
                    size = self.size_min
                    n = self.n_min
                    function_result_min = eval(function)
                    term_results_min.append(eval(term_a))
                    term_results_min.append(eval(term_b))
                    term_results_min.append(eval(term_c))
                    p = self.p_max
                    size = self.size_max
                    n = self.n_max
                    function_result_max = eval(function)
                    term_results_max.append(eval(term_a))
                    term_results_max.append(eval(term_b))
                    term_results_max.append(eval(term_c))
                    one_percent_min = function_result_min / 100.0
                    one_percent_max = function_result_max / 100.0
                    percent_terms_min = []
                    percent_terms_max = []
                    for i in range(len(term_results_min)):
                        percent_min = term_results_min[i] / one_percent_min
                        percent_max = term_results_max[i] / one_percent_max
                        percent_terms_min.append(percent_min)
                        percent_terms_max.append(percent_max)
                    is_valid = True
                    for i in range(len(percent_terms_min)):
                        if percent_terms_min[i] < self.epsilon or percent_terms_max[i] < self.epsilon:
                            is_valid = False
                            break
                    if is_valid==True:
                        return function
            # a*b*c function type
            else:
                c1 = coefficient.get_random_coefficient()
                c2 = coefficient.get_random_coefficient()
                a = self.generate_compound_term("p")
                b = self.generate_compound_term("size")
                c = self.generate_compound_term("n")
                return str(c1) + "+" + str(c2) + "*" + a + "*" + b + "*" + c
        else:
            coefficient = Coefficients()
            # a+b function type
            if randint(0,1)==0:
                while(True):
                    c1 = coefficient.get_random_coefficient()
                    c2 = coefficient.get_random_coefficient()
                    c3 = coefficient.get_random_coefficient()
                    a = self.generate_compound_term("p")
                    b = self.generate_compound_term("size")
                    function = str(c1) + "+" + str(c2) + "*" + a + "+" + str(c3) + "*" + b
                    term_a = str(c2) + "*" + a
                    term_b = str(c3) + "*" + b
                    term_results_min = []
                    term_results_max = []
                    p = self.p_min
                    size = self.size_min
                    function_result_min = eval(function)
                    term_results_min.append(eval(term_a))
                    term_results_min.append(eval(term_b))
                    p = self.p_max
                    size = self.size_max
                    function_result_max = eval(function)
                    term_results_max.append(eval(term_a))
                    term_results_max.append(eval(term_b))
                    one_percent_min = function_result_min / 100.0
                    one_percent_max = function_result_max / 100.0
                    percent_terms_min = []
                    percent_terms_max = []
                    for i in range(len(term_results_min)):
                        percent_min = term_results_min[i] / one_percent_min
                        percent_max = term_results_max[i] / one_percent_max
                        percent_terms_min.append(percent_min)
                        percent_terms_max.append(percent_max)
                    is_valid = True
                    for i in range(len(percent_terms_min)):
                        if percent_terms_min[i] < self.epsilon or percent_terms_max[i] < self.epsilon:
                            is_valid = False
                            break
                    if is_valid==True:
                        return function
            # a*b function type
            else:
                c1 = coefficient.get_random_coefficient()
                c2 = coefficient.get_random_coefficient()
                a = self.generate_compound_term("p")
                b = self.generate_compound_term("size")
                return str(c1) + "+" + str(c2) + "*" + a + "*" + b

    def generate_compound_term(self, parameter):
        exponent = Exponents()
        choice = randint(0,2)
        # poly term
        if choice==0:
            e1 = exponent.get_random_exponent_poly()
            return "(" + parameter + "**" + str(e1) + ")"
        # log term
        elif choice==1:
            e1 = exponent.get_random_exponent_log()
            return "log(" + parameter + ",2)**" + str(e1)
        # poly log term
        else:
            e1 = exponent.get_random_exponent_poly()
            e2 = exponent.get_random_exponent_log()
            return "(" + parameter + "**" + str(e1) + ")" + "*log(" + parameter + ",2)**" + str(e2)

    def out(self):
        print(self.function)
    
    def get_function(self):
        return self.function
    
    def evaluate(self, p, size, n):
        return eval(self.function)