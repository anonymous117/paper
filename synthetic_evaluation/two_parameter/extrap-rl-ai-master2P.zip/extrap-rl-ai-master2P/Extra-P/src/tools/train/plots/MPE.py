import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from extrap.Util import smooth

class MPE():

    def __init__(self, mpe):
        self.mpe = mpe

    def plot(self):
        ax = plt.subplot(111)
        ax.plot(self.mpe, 'bo')
        # Hide the right and top spines
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        # Only show ticks on the left and bottom spines
        ax.yaxis.set_ticks_position('left')
        ax.xaxis.set_ticks_position('bottom')
        ax.set_xlim(0,len(self.mpe))
        ax.xaxis.labelpad = 10
        ax.yaxis.labelpad = 10
        plt.xlabel("Evaluation epochs")
        plt.ylabel("MPE")
        plt.show()
    
    def calc_average_mpe(self):
        sum = 0
        for i in range(len(self.mpe)):
            sum += self.mpe[i]
        average_mpe = sum / len(self.mpe) 
        print("Average MPE: "+str(average_mpe))