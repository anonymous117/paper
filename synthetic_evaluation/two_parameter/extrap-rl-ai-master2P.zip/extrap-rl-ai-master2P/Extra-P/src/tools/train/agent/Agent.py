import numpy as np
import tensorflow as tf
import operator
from numpy import save
from extrap.Memory import Memory

class Agent():

    def __init__(self, n_actions, n_features, epsilon_max, epsilon_min, alpha, gamma,
                 replace_target_iter, memory_size, batch_size, replay_start_size, final_exploration, epsilon_upgrade_frequency):

        # number of all possible actions
        self.n_actions = n_actions
        # number of features, inputs for the states
        self.n_features = n_features
        # greedy policy
        self.epsilon_max = epsilon_max
        self.epsilon_min = epsilon_min
        self.epsilon = self.epsilon_max
        # replay start size
        self.replay_start_size = replay_start_size
        # learning rate
        self.lr = alpha
        # discount factor
        self.gamma = gamma
        # replace the target net after n iterations
        self.replace_target_iter = replace_target_iter
        # memory size
        self.memory_size = memory_size
        # batch size
        self.batch_size = batch_size
        # final exploration episode
        self.final_exploration = final_exploration
        # upgrade frequency for e-greedy strategy
        self.epsilon_upgrade_frequency = epsilon_upgrade_frequency

        # total learning step
        self.learn_step_counter = 0

        # initialize prioritized memory
        self.memory = Memory(capacity=memory_size)

        # consist of [target_net, evaluate_net]
        self.build_net()
        t_params = tf.get_collection('target_net_params')
        e_params = tf.get_collection('eval_net_params')
        self.replace_target_op = [tf.assign(t, e) for t, e in zip(t_params, e_params)]

        self.sess = tf.Session()
        self.merged = tf.summary.merge_all()

        # log data for training
        self.writer = tf.summary.FileWriter("logs/", self.sess.graph)

        # saver to save NN after training
        self.saver = tf.train.Saver()

        self.sess.run(tf.global_variables_initializer())
        self.costs = []

    def build_net(self):
        '''
        Creates the artificial neural network, the brain of the agent
        '''

        # Dueling DQN Architecture
        def build_layers(s, c_names, n_l1, w_initializer, b_initializer):
            with tf.variable_scope('l1'):
                w1 = tf.get_variable('w1', [self.n_features, n_l1], initializer=w_initializer, collections=c_names)
                b1 = tf.get_variable('b1', [1, n_l1], initializer=b_initializer, collections=c_names)
                l1 = tf.nn.relu(tf.matmul(s, w1) + b1)

            with tf.variable_scope('Value'):
                w2 = tf.get_variable('w2', [n_l1, 1], initializer=w_initializer, collections=c_names)
                b2 = tf.get_variable('b2', [1, 1], initializer=b_initializer, collections=c_names)
                self.V = tf.matmul(l1, w2) + b2

            with tf.variable_scope('Advantage'):
                w2 = tf.get_variable('w2', [n_l1, self.n_actions], initializer=w_initializer, collections=c_names)
                b2 = tf.get_variable('b2', [1, self.n_actions], initializer=b_initializer, collections=c_names)
                self.A = tf.matmul(l1, w2) + b2

            with tf.variable_scope('Q'):
                out = self.V + (self.A - tf.reduce_mean(self.A, axis=1, keepdims=True))

            return out

        # Eval Net
        self.s = tf.placeholder(tf.float32, [None, self.n_features], name='s')
        self.q_target = tf.placeholder(tf.float32, [None, self.n_actions], name='Q_target')
        self.ISWeights = tf.placeholder(tf.float32, [None, 1], name='IS_weights')

        with tf.variable_scope('eval_net'):
            c_names, n_l1, w_initializer, b_initializer = \
                ['eval_net_params', tf.GraphKeys.GLOBAL_VARIABLES], 20, \
                tf.random_normal_initializer(0., 0.3), tf.constant_initializer(0.1)

            self.q_eval = build_layers(self.s, c_names, n_l1, w_initializer, b_initializer)

        with tf.variable_scope('loss'):
            self.abs_errors = tf.reduce_sum(tf.abs(self.q_target - self.q_eval), axis=1)    # for updating Sumtree
            self.loss = tf.reduce_mean(self.ISWeights * tf.squared_difference(self.q_target, self.q_eval))
            tf.summary.scalar('loss', self.loss)

        with tf.variable_scope('train'):
            self._train_op = tf.train.AdamOptimizer(self.lr).minimize(self.loss)

        # Target Net
        self.s_ = tf.placeholder(tf.float32, [None, self.n_features], name='s_')

        with tf.variable_scope('target_net'):
            c_names = ['target_net_params', tf.GraphKeys.GLOBAL_VARIABLES]

            self.q_next = build_layers(self.s_, c_names, n_l1, w_initializer, b_initializer)

    def store_transition(self, s, a, r, s_):
        '''
        Stores a state transition in the memory
        '''
        transition = np.hstack((s.get_observation(), [a, r], s_.get_observation()))
        self.memory.store(transition)    # have high priority for newly arrived transition

    def choose_action(self, state, environment):
        '''
        Chooses the next action to be performed by the agent
        '''
        observation = np.array(state.get_observation())
        observation = observation[np.newaxis, :]
        action_values = self.sess.run(self.q_eval, feed_dict={self.s: observation})

        #-------- this code is only for plotting!
        if not hasattr(self, 'q'):
            self.q = []
            self.running_q = 0
        self.running_q = self.running_q*0.99 + 0.01 * np.max(action_values)
        self.q.append(self.running_q)
        #------------------------------

        # choose from knowledge
        if np.random.uniform() >= self.epsilon:
            q_values = self.sess.run(self.q_eval, feed_dict={self.s: observation})
            actions = {}
            for i in range(len(q_values[0])):
                key = str(i)
                actions[key] = q_values[0][i]
            sorted_actions = sorted(actions.items(), key=operator.itemgetter(1), reverse=True)
            is_valid = False
            id = 0
            while is_valid == False:
                action_tuple = sorted_actions[id]
                action = int(action_tuple[0])
                is_valid = environment.validate_action(action)
                if is_valid == False:
                    id += 1

        # choose random
        else:
            is_valid = False
            while is_valid == False:
                action = np.random.randint(0, self.n_actions)
                is_valid = environment.validate_action(action)
        return action

    def learn(self, i):
        '''
        Learn from the saved state changes in memory
        '''
        if self.learn_step_counter % self.replace_target_iter == 0:
            self.sess.run(self.replace_target_op)

        tree_idx, batch_memory, ISWeights = self.memory.sample(self.batch_size)

        q_next, q_eval4next = self.sess.run(
            [self.q_next, self.q_eval],
            feed_dict={self.s_: batch_memory[:, -self.n_features:],
                       self.s: batch_memory[:, -self.n_features:]})
        q_eval = self.sess.run(self.q_eval, {self.s: batch_memory[:, :self.n_features]})

        q_target = q_eval.copy()

        batch_index = np.arange(self.batch_size, dtype=np.int32)
        eval_act_index = batch_memory[:, self.n_features].astype(int)
        reward = batch_memory[:, self.n_features + 1]

        max_act4next = np.argmax(q_eval4next, axis=1)
        selected_q_next = q_next[batch_index, max_act4next]

        q_target[batch_index, eval_act_index] = reward + self.gamma * selected_q_next

        _, abs_errors, self.cost = self.sess.run([self._train_op, self.abs_errors, self.loss],
                                         feed_dict={self.s: batch_memory[:, :self.n_features],
                                                    self.q_target: q_target,
                                                    self.ISWeights: ISWeights})
        self.memory.batch_update(tree_idx, abs_errors)     # update priority

        #TODO: write cost and action values to logs
        # log cost
        #tf.summary.scalar('cost', self.cost)
        # write to logs
        result = self.sess.run(self.merged, feed_dict={self.s: batch_memory[:, :self.n_features],
                                                    self.q_target: q_target,
                                                    self.ISWeights: ISWeights})
        self.writer.add_summary(result, i)

        self.costs.append(self.cost)
        self.learn_step_counter += 1

    def set_epsilon(self, epsilon):
        '''
        Set the epsilon value
        '''
        self.epsilon = epsilon

    def get_loss(self):
        '''
        Returns the costs as a list
        '''
        return self.costs

    def get_epsilon(self):
        '''
        Returns the current epsilon value of the agent
        '''
        return self.epsilon

    def adjust_epsilon(self, current_episode):
        '''
        Reduces the epsilon value for the e-greedy strategy based on the current episode
        '''
        if current_episode <= self.final_exploration and current_episode >= self.replay_start_size:
            if current_episode % self.epsilon_upgrade_frequency == 0:
                relevant_episodes = self.final_exploration - self.replay_start_size
                one_percent = relevant_episodes / 100
                percent = (current_episode - self.replay_start_size) / one_percent
                percent = percent / 100
                range = self.epsilon_max - self.epsilon_min
                decrease = percent * range
                epsilon_value = 1 - decrease
                self.epsilon = epsilon_value

    def set_alpha(self, alpha):
        '''
        Sets the learning rate
        '''
        self.lr = alpha

    def get_q_values(self, state):
        '''
        Returns the q-values for a given state
        '''
        observation = np.array(state.get_observation())
        observation = observation[np.newaxis, :]
        q_values = self.sess.run(self.q_eval, feed_dict={self.s: observation})
        return q_values

    def save_NN(self):
        '''
        Saves the NN (session) after training
        '''
        save_path = self.saver.save(self.sess, "my_net/save_net.ckpt")
        print("Saved tf-session to path: ", save_path)

    def load_NN(self):
        '''
        Load the NN (session) from checkpoint
        '''
        saver = tf.train.Saver()
        saver.restore(self.sess, "my_net/save_net.ckpt")
        print("Loaded tf-session from path: my_net/save_net.ckpt")
