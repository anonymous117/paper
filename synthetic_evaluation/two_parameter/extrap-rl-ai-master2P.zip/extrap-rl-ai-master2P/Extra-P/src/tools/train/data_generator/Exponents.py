from random import randint

class Exponents():

    def __init__(self):
        #self.values_poly = [0, 0.25, 0.5, 2/3, 0.75, 1, 1.25, 4/3, 1.5, 5/3, 1.75, 2, 2.25, 7/3, 2.5, 8/3, 2.75, 3]
        #self.values_log = [0, 1, 2]
        self.values_poly = [1, 2, 3]
        self.values_log = [1]
    
    def get_random_exponent_poly(self):
        return self.values_poly[randint(0, len(self.values_poly)-1)]
    
    def get_random_exponent_log(self):
        return self.values_log[randint(0, len(self.values_log)-1)] 