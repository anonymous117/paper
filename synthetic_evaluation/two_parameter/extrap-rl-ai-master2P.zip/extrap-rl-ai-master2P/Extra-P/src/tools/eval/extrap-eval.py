##/*
## * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
## *
## * Copyright (c) 2019,
## * Technische Universitaet Darmstadt, Germany
## *
## * This software may be modified and distributed under the terms of
## * a BSD-style license.  See the COPYING file in the package base
## * directory for details.
## *
## */

"""Extra-P Data Evaluation Tool.

Usage:
  extrap-eval run [--name=<n>] [-i=<i>] [-r=<r>] [--debug]
  extrap-eval -h | --help
  extrap-eval --version

Options:
  --name=<n>    Select the source folder name for the evaluation.
  -i=<i>    Number of iterations.
  -r=<r>    Number of repetitions.
  --debug   Set log level to debug. Lowest log level.
"""

import logging
import sys
import os
import shutil
import re
import numpy as np
import csv
import EXTRAP
import math
from math import *
from extrap.docopt import docopt
from extrap.util import ModelerResult
from extrap.util import InputFile
from extrap.util import Parameter
from extrap.util import Metric
from extrap.util import MeasurementPoint
from extrap.util import Measurement
from extrap.util import BaselineFunction

def parse_to_python_function(function):
    # remove leading + for the first coefficient
    if function[0] == ' ':
        function = function[1:]
    if function[0] == '+':
        function = function[1:]
    if function[0] == ' ':
        function = function[1:]
    # replace power operator ^ with **
    while True:
        id = 0
        complete = True
        for i in range(0,len(function)):
            if function[i] == '^':
                id = i
                complete = False
                break
        if complete == True:
            break
        temp = function[:id]
        temp2 = function[id+2:]
        exponent = function[id+1]
        temp2 = '**' + exponent + temp2
        function = temp + temp2
    # replace log operator log2(x) with log(x,2)
    while True:
        id = function.find('log2')
        if id == -1:
            break
        else:
            temp = function[:id]
            temp2 = function[id+4:]
            bracket1 = temp2.find('(')
            bracket2 = temp2.find(')')
            parameter = temp2
            parameter = parameter[bracket1+1:]
            idd = parameter.find(')')
            parameter = parameter[:idd]
            temp3 = temp2[:bracket1]
            temp4 = temp2[bracket2+1:]
            temp2 = temp3 + temp4
            function = temp + 'log(' + parameter + ',2)' + temp2
    return function

def compute_relative_error(baseline_function, modeler_result, measurement_points):
    #get modeler function
    modeler_function_string = modeler_result
    modeler_python_function = parse_to_python_function(modeler_function_string)

    #get baseline function
    baseline_function_string = baseline_function
    baseline_python_function = parse_to_python_function(baseline_function_string)

    sum_relative_error = 0
    for i in range(len(measurement_points)):
        measurement_point = measurement_points[i]
        measurement_point_values = measurement_point.getValues()
        p = measurement_point_values[0]
        size = measurement_point_values[1]
        result_normal = eval(modeler_python_function)
        result_base = eval(baseline_python_function)
        absolute_error = abs(result_normal - result_base)
        relative_error = absolute_error / result_base
        sum_relative_error = sum_relative_error + relative_error
    if sum_relative_error!=0 and math.isnan(sum_relative_error)==False:
        return sum_relative_error / 25
    elif math.isnan(sum_relative_error)==True:
        return 1
    else:
        return 0

def compute_relative_error_all_iterations(baseline_functions, normal_modeler_results, sparse_modeler_results, n, measurement_points):
    #data storages for the relative error
    relative_error_normal_models = 0
    relative_errors_sparse_models = []
    for _ in range(6):
        relative_errors_sparse_models.append(0)
    
    #print(n)
    
    for a in range(n):
        if a% 1000 == 0:
            logging.info(str(a)+"/"+str(n))
    
        #compute relative error for normal modeler 
        relative_error_normal_model = compute_relative_error(baseline_functions[a], normal_modeler_results[a], measurement_points)
        relative_error_normal_models = relative_error_normal_models + relative_error_normal_model

        #compute relative errors for all instances of the sparse modeler
        data_storage = sparse_modeler_results[a]
        for b in range(len(data_storage)):
            sparse_result = data_storage[b]
            relative_error_sparse_model = compute_relative_error(baseline_functions[a], sparse_result, measurement_points)
            relative_errors_sparse_models[b] = relative_errors_sparse_models[b] + relative_error_sparse_model
    
    relative_error_normal_models = relative_error_normal_models / n
    for a in range(len(relative_errors_sparse_models)):
        relative_errors_sparse_models[a] = relative_errors_sparse_models[a] / n
    relative_errors = []
    relative_errors = [relative_error_normal_models] + relative_errors_sparse_models
    return relative_errors

def compute_percentage_error(relative_errors):
    percentage_errors = []
    for i in range(len(relative_errors)):
        percentage_errors.append(relative_errors[i]*100)
    return percentage_errors

def check_for_parameters(function_term):
    pos1 = function_term.find("p")
    pos2 = function_term.find("size")
    #pos3 = function_term.find("n")
    #in this case there is no parameter in the term
    if pos1==-1 and pos2==-1:
        return False
    else:
        return True

def parse_terms(functions_terms):
    terms = functions_terms
    for j in range(len(terms)):
        terms[j] = terms[j].replace(" ", "")
    terms_copy = []
    for j in range(len(terms)):
        has_parameter = check_for_parameters(terms[j])
        if has_parameter==True:
            terms_copy.append(terms[j])
    for j in range(len(terms_copy)):
        temp = terms_copy[j]
        pos = temp.find("*")
        temp = temp[pos+1:]
        terms_copy[j] = temp
    return terms_copy

def search_term(base_terms, term):
    is_existing = False
    for i in range(len(base_terms)):
        if base_terms[i] == term:
            is_existing = True
            break
    return is_existing

def term_analysis(baseline_functions, normal_modeler_results, sparse_modeler_results, iterations):
    n_value = [0]*3
    s_values = []
    for i in range(6):
        s_values.append([0,0,0])

    for i in range(iterations):
        #get the terms of the baseline function
        bf_function_string = baseline_functions[i]
        bf_function_string_copy = bf_function_string
        bf_function_string_copy = bf_function_string_copy[3:]
        bf_function_string_copy_terms = bf_function_string_copy.split("+")
        bf_function_string_copy_terms = parse_terms(bf_function_string_copy_terms)

        #print("Base: ",bf_function_string_copy_terms)
    
        #get the terms of the normal modeler function
        nmr_function_string = normal_modeler_results[i]
        nmr_function_string_copy = nmr_function_string
        nmr_function_string_copy = nmr_function_string_copy[3:]
        
        #check for nan values in the function, when matrix fails count it as modele incorrect!
        if nmr_function_string_copy.find("nan")!=-1:
            print("Error. Found nan value: ", nmr_function_string_copy)
            n_value[0] = n_value[0] + 1
            break
            
        nmr_function_string_copy_terms = nmr_function_string_copy.split("+")
        nmr_function_string_copy_terms = parse_terms(nmr_function_string_copy_terms)

        #print("Normal Modeler: ",nmr_function_string_copy_terms)

        #check the terms of the normal modeler function
        normal_modeler_correct_terms = 0
        for j in range(len(nmr_function_string_copy_terms)):
            nmr_function_string_copy_term = nmr_function_string_copy_terms[j]
            is_existing = search_term(bf_function_string_copy_terms, nmr_function_string_copy_term)
            if is_existing==True:
                normal_modeler_correct_terms = normal_modeler_correct_terms + 1

        #print("Correct terms: ",normal_modeler_correct_terms)
        #print("\n")

        # model is correct
        if len(bf_function_string_copy_terms)==normal_modeler_correct_terms:
            n_value[2] = n_value[2] + 1
        # check if the lead order term is correct
        if normal_modeler_correct_terms < 2 and normal_modeler_correct_terms > 0 and len(bf_function_string_copy_terms)==2 and len(nmr_function_string_copy_terms)==2:
            terms = bf_function_string_copy.split("+")
            function = parse_to_python_function(bf_function_string)
            term1 = parse_to_python_function(terms[1])
            term2 = parse_to_python_function(terms[2])
            #term3 = parse_to_python_function(terms[3])
            p = 64
            size = 50
            #n = 10
            function_result = eval(function)
            one_percent = function_result / 100
            term1_result = eval(term1)
            term2_result = eval(term2)
            #term3_result = eval(term3)
            term1_percent = term1_result / one_percent
            term2_percent = term2_result / one_percent
            #term3_percent = term3_result / one_percent
            id = 0
            tp = term1_percent
            if term2_percent > tp:
                tp = term2_percent
                id = 1
            #if term3_percent > tp:
            #    tp = term3_percent
            #    id = 2
            if bf_function_string_copy_terms[id]==nmr_function_string_copy_terms[id]:
                # lead order term is correct
                n_value[1] = n_value[1] + 1
            else:
                # model is incorrect
                n_value[0] = n_value[0] + 1
        # model is incorrect
        if normal_modeler_correct_terms==0:
            n_value[0] = n_value[0] + 1

        #get the terms of the sparse modeler function
        smr = sparse_modeler_results[i]
        
        for j in range(len(smr)):
            smr0_funtion_string = smr[j]
            smr0_funtion_string_copy = smr0_funtion_string
            smr0_funtion_string_copy = smr0_funtion_string_copy[3:]
            
            #check for nan values in the function, when matrix fails count it as modele incorrect!
            if smr0_funtion_string_copy.find("nan")!=-1:
                print("Error. Found nan value: ", smr0_funtion_string_copy)
                s_values[j][0] = s_values[j][0] + 1
                break
            
            smr0_funtion_string_copy_terms = smr0_funtion_string_copy.split("+")
            smr0_funtion_string_copy_terms = parse_terms(smr0_funtion_string_copy_terms)

            #check the terms of the sparse modeler function
            sparse_modeler_correct_terms = 0
            for z in range(len(smr0_funtion_string_copy_terms)):
                smr0_funtion_string_copy_term = smr0_funtion_string_copy_terms[z]
                is_existing = search_term(bf_function_string_copy_terms, smr0_funtion_string_copy_term)
                if is_existing==True:
                    sparse_modeler_correct_terms = sparse_modeler_correct_terms + 1

            # model is correct
            if len(bf_function_string_copy_terms)==sparse_modeler_correct_terms:
                s_values[j][2] = s_values[j][2] + 1
            # check if the lead order term is correct
            if sparse_modeler_correct_terms < 2 and sparse_modeler_correct_terms > 0 and len(bf_function_string_copy_terms)==2 and len(smr0_funtion_string_copy_terms)==2:
                terms = bf_function_string_copy.split("+")
                function = parse_to_python_function(bf_function_string)
                term1 = parse_to_python_function(terms[1])
                term2 = parse_to_python_function(terms[2])
                #term3 = parse_to_python_function(terms[3])
                p = 64
                size = 50
                #n = 10
                function_result = eval(function)
                one_percent = function_result / 100
                term1_result = eval(term1)
                term2_result = eval(term2)
                #term3_result = eval(term3)
                term1_percent = term1_result / one_percent
                term2_percent = term2_result / one_percent
                #term3_percent = term3_result / one_percent
                id = 0
                tp = term1_percent
                if term2_percent > tp:
                    tp = term2_percent
                    id = 1
                #if term3_percent > tp:
                #    tp = term3_percent
                #    id = 2
                if bf_function_string_copy_terms[id]==smr0_funtion_string_copy_terms[id]:
                    # lead order term is correct
                    s_values[j][1] = s_values[j][1] + 1
                else:
                    # model is incorrect
                    s_values[j][0] = s_values[j][0] + 1
            # model is incorrect
            if sparse_modeler_correct_terms==0:
                s_values[j][0] = s_values[j][0] + 1

    s_values.insert(0, n_value)
    return s_values    

def calculate_percent_term_data(term_data, iterations):
    one_percent = iterations / 100
    for i in range(len(term_data)):
        for j in range(len(term_data[i])):
            value = term_data[i][j]
            percent = value / one_percent
            term_data[i][j] = percent
    return term_data

def load_data_from_result_files(iterations, repetitions, folder_name):
    basline_functions = []
    normal_functions = []
    data_storage = []
    for i in range(repetitions):
        for j in range(iterations):
            with open(folder_name+"/outputs/"+str(i)+"/modeler_result_"+str(j)+".txt") as f:
                lines = f.readlines()
            b = lines[0]
            b = b[:-1]
            a = lines[1]
            a = a[:-1]
            sparse_functions = []
            counter = 2
            while counter < len(lines):
                c = lines[counter]
                c = c[:-1]
                sparse_functions.append(c)
                counter = counter + 1
            # append funtions
            basline_functions.append(b)
            normal_functions.append(a)
            data_storage.append(sparse_functions)      
    return basline_functions, normal_functions, data_storage

def save_csv(data, filename):
    with open(filename, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        for val in data:
            writer.writerow([val])

def save_csv2(data, filename):
    with open(filename, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        writer.writerows(data)

def set_log_level(arguments):
    if arguments['--debug']:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

if __name__ == '__main__':
    args = docopt(__doc__, version='Extra-P Evaluation Tool.')
    set_log_level(args)

    if args['run']:
        # check options parsed
        if args['--name']:
            folder_name = str(args['--name'])
        number_function_terms = 2
        if args['-i']:
            iterations = int(args['-i'])
        else:
            iterations = 100
        if args['-r']:
            repetitions = int(args['-r'])
        else:
            repetitions = 10
        logging.info("Running evaluation for outputs in folder '/"+str(folder_name)+"' with "+str(repetitions)+" repetitions and "+str(iterations)+" iterations.")
        number_of_functions = iterations * repetitions

        # create modeling objects
        parameter_1_name = "p"
        parameter_2_name = "size"
        #parameter_3_name = "n"
        metric = Metric("metr")
        parameter_1 = Parameter(parameter_1_name)
        parameter_2 = Parameter(parameter_2_name)
        #parameter_3 = Parameter(parameter_3_name)
        parameters = []
        parameters.append(parameter_1)
        parameters.append(parameter_2)
        #parameters.append(parameter_3)
        measurement_points_param_1 = ([4,8,16,32,64])
        measurement_points_param_2 = ([10,20,30,40,50])
        #measurement_points_param_3 = ([2,4,6,8,10])
        #measurement_points_param_1 = ([8,64,512,4096,32768])
        #measurement_points_param_2 = ([2,4,6,8,10])
        #measurement_points_param_3 = ([32,64,96,128,160])
        measurement_points = []
        for a in range(len(measurement_points_param_1)):
            for b in range(len(measurement_points_param_2)):
                #for c in range(len(measurement_points_param_3)):
                measurement_point_values = []
                measurement_point_values.append(measurement_points_param_1[a])
                measurement_point_values.append(measurement_points_param_2[b])
                #measurement_point_values.append(measurement_points_param_3[c])
                measurement_point = MeasurementPoint(parameters, measurement_point_values)
                measurement_points.append(measurement_point)
                    
        # load data from output folders
        basline_functions, normal_functions, data_storage = load_data_from_result_files(iterations, repetitions, folder_name)
        
        logging.info("Data has been loaded.")

        # path for save files
        path = folder_name+"/"

        # calculate relative errors
        logging.info("Calculating relative error.")
        relative_errors = compute_relative_error_all_iterations(basline_functions, normal_functions, data_storage, number_of_functions, measurement_points)
        save_csv(relative_errors, path+"relative_errors.csv")
        logging.info("Relative errors calculation finished.")
        
        # calculate percentage errors
        percentage_errors = compute_percentage_error(relative_errors)
        save_csv(percentage_errors, path+"percentage_errors.csv")
        
        # calculate term data
        term_data = term_analysis(basline_functions, normal_functions, data_storage, number_of_functions)
        save_csv2(term_data, path+"absolute_term_data.csv")

        # calculate percent term data
        percent_term_data = calculate_percent_term_data(term_data, number_of_functions)
        save_csv2(percent_term_data, path+"percentage_term_data.csv")

        logging.info("Evaluation finished. Results written to "+str(path)+".")
        