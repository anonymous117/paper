# -*- coding: utf-8 -*-
##
## This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
##
## Copyright (c) 2016-2018,
## Technische Universitaet Darmstadt, Germany
##
## This software may be modified and distributed under the terms of
## a BSD-style license.  See the COPYING file in the package base
## directory for details.
##

import EXTRAP
try:
   from PyQt4.QtGui import *
except ImportError:
   from PyQt5.QtGui import *
   from PyQt5.QtWidgets import *

def convert_string_to_numberlist( str ):
   words = str.split( "," )
   numbers = EXTRAP.StdVectorDouble()
   for word in words:
      numbers.push_back( float( word ) )
   return numbers

class SingleParameterSimpleModeler(QWidget):
   
   def __init__(self, modelerWidget, parent):
      super(SingleParameterSimpleModeler, self).__init__(parent)

      self.term_number = 1
      self.poly_exp = "0.5, 1, 1.5, 2, 2.5"
      self.log_exp = "1"
      self.modeler_widget = modelerWidget

      self.initUI()

   def initUI(self):
      
      grid = QGridLayout( self )
      self.setLayout( grid )    

      model_button = QPushButton(self)
      model_button.setText( "Generate models")
      model_button.pressed.connect( self.remodel )

      self.term_number_edit = QSpinBox(self)
      self.term_number_edit.setMinimum(1);
      self.term_number_edit.setMaximum(3);
      self.term_number_edit.setValue( self.term_number )
      self.term_number_edit.setFixedWidth(60)

      self.poly_exp_edit = QLineEdit(self)
      self.poly_exp_edit.setText( self.poly_exp )
      self.poly_exp_edit.move(180,70)

      self.log_exp_edit = QLineEdit(self)
      self.log_exp_edit.setText( self.log_exp )
      self.log_exp_edit.move(180,100)

      label = QLabel( self )
      label.setText("Number of terms:")
      grid.addWidget( label, 0, 0 )

      label = QLabel( self )
      label.setText("Exponents of polynoms:")
      grid.addWidget( label, 1, 0 )

      label = QLabel( self )
      label.setText("Exponents for logarithms:")
      grid.addWidget( label, 2, 0 )

      grid.addWidget( self.term_number_edit, 0, 1 )
      grid.addWidget( self.poly_exp_edit, 1, 1)
      grid.addWidget( self.log_exp_edit, 2, 1)
      grid.addWidget( model_button, 3, 0)

      widget = QWidget( self )
      widget.setMinimumHeight( self.height() - 120 )
      grid.addWidget( widget, 4, 0)

   def getName(self):
      return "Default Model Generator"

   def remodel(self):
      
      self.term_number = self.term_number_edit.value()
      self.poly_exp    = self.poly_exp_edit.text()
      self.log_exp     = self.log_exp_edit.text()

      poly_exp  = convert_string_to_numberlist( self.poly_exp )
      log_exp   = convert_string_to_numberlist( self.log_exp )
      
      modeler = EXTRAP.SingleParameterSimpleModelGenerator()
      modeler.generateHypothesisBuildingBlockSet( poly_exp, log_exp )
      modeler.setMaxTermCount( self.term_number )
      modeler.setEpsilon( 0.01 )

      options = EXTRAP.ModelGeneratorOptions()

      #init the optins
      options.setMinNumberPoints(5)
      options.setUseAddPoints(False)
      options.setNumberAddPoints(0)
      options.setSinglePointsStrategy(EXTRAP.FIRST_POINTS_FOUND)
      options.setMultiPointsStrategy(EXTRAP.INCREASING_COST)
      
      self.modeler_widget.onGenerate( modeler, options )
