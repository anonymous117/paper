# -*- coding: utf-8 -*-
##
## This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
##
## Copyright (c) 2017-2019,
## Technische Universitaet Darmstadt, Germany
##
## This software may be modified and distributed under the terms of
## a BSD-style license.  See the COPYING file in the package base
## directory for details.
##

import EXTRAP
try:
   from PyQt4.QtGui import *
except ImportError:
   from PyQt5.QtGui import *
   from PyQt5.QtWidgets import *

from extrap.SingleParameterSimpleModeler import SingleParameterSimpleModeler
from extrap.SingleParameterRefiningModeler import SingleParameterRefiningModeler
from extrap.SingleParameterExhaustiveModeler import SingleParameterExhaustiveModeler
from extrap.MultiParameterSimpleModeler import MultiParameterSimpleModeler
from extrap.MultiParameterSparseModeler import MultiParameterSparseModeler

class ModelerWidget(QWidget):
   
   def __init__(self, mainWidget, parent):
      super(ModelerWidget, self).__init__(parent)
      self.main_widget = mainWidget
      self.initUI()

      #init modeler options
      self.options = EXTRAP.ModelGeneratorOptions()
      self.options.setMinNumberPoints(5)
      self.options.setUseAddPoints(False)
      self.options.setNumberAddPoints(0)
      self.options.setSinglePointsStrategy(EXTRAP.FIRST_POINTS_FOUND)
      self.options.setMultiPointsStrategy(EXTRAP.INCREASING_COST)

   def initUI(self):
      grid = QGridLayout( self )
      self.setLayout( grid )    

      self.model_name_edit = QLineEdit(self)
      self.model_name_edit.setPlaceholderText ("ModelName")
      self.model_name_edit.setText("New Model")

      self.model_generator_selector = QComboBox( self )
      self.model_generator_selector.currentIndexChanged.connect(self.generator_changed)
      self.model_configurator_widget = QStackedWidget( self )

      label = QLabel( self )
      label.setText("Generator Type:")
      grid.addWidget( label, 0, 0 )

      label = QLabel( self )
      label.setText("Name new Model:")
      grid.addWidget( label, 1, 0 )

      grid.addWidget( self.model_generator_selector, 0, 1)
      grid.addWidget( self.model_name_edit, 1, 1)

      self.model_mean_radio = QRadioButton( self.tr("Model mean") )
      self.model_mean_radio.setChecked( True )
      grid.addWidget( self.model_mean_radio, 2, 0, 1, 2 )

      self.model_median_radio = QRadioButton( self.tr("Model median") )
      grid.addWidget( self.model_median_radio, 3, 0, 1, 2 )

      self.model_mean_median_radio_group = QButtonGroup(grid)
      self.model_mean_median_radio_group.addButton(self.model_mean_radio)
      self.model_mean_median_radio_group.addButton(self.model_median_radio)
     
      #Add modeler specific widget
      grid.addWidget( self.model_configurator_widget,4, 0, 1, 2)

   def fillModelerList( self ):

      self.model_generator_selector.clear()
      current = self.model_configurator_widget.widget( 0 )
      while( current ):
         self.model_configurator_widget.removeWidget( current )
         current = self.model_configurator_widget.widget( 0 )

      experiment = self.main_widget.getExperiment()
      if not experiment:
         return

      num_params = experiment.getParameters().size()
      if num_params == 1:
         model_generators = [
             SingleParameterSimpleModeler( self, None ),
             SingleParameterRefiningModeler( self, None ),
             SingleParameterExhaustiveModeler( self, None ),
         ]
      else:
         model_generators = [
             MultiParameterSimpleModeler(self, None),
             MultiParameterSparseModeler(self, None)
         ]

      for model_generator in model_generators:
            self.model_configurator_widget.addWidget( model_generator )
            self.model_generator_selector.addItem( model_generator.getName() )        

   def getName( self ):
      return self.model_name_edit.text()

   def generator_changed( self, modelGenerator ):
      self.model_configurator_widget.setCurrentIndex( modelGenerator )

   def remodel( self ):
      modeler = self.model_configurator_widget.currentWidget()
      modeler.remodel()

   def applyCommonOptions( self, modeler ):
      # Set options only for the exhaustive modeler
      # (since the ExhaustiveModeler does not call onGenerate)
      if (self.model_mean_radio.isChecked()):
         modeler.setModelOptions(EXTRAP.GENERATE_MODEL_MEAN)
      elif (self.model_median_radio.isChecked()):
         modeler.setModelOptions(EXTRAP.GENERATE_MODEL_MEDIAN)

   def onGenerate( self, modeler, options ):
      
      # set the modeler options
      if (self.model_mean_radio.isChecked()):
         self.options.setGenerateModelOptions(EXTRAP.GENERATE_MODEL_MEAN)
      elif (self.model_median_radio.isChecked()):
         self.options.setGenerateModelOptions(EXTRAP.GENERATE_MODEL_MEDIAN)

      self.options.setMinNumberPoints(options.getMinNumberPoints())
      self.options.setUseAddPoints(options.getUseAddPoints())
      self.options.setNumberAddPoints(options.getNumberAddPoints())
      self.options.setSinglePointsStrategy(options.getSinglePointsStrategy())
      self.options.setMultiPointsStrategy(options.getMultiPointsStrategy())

      # Pass ownership to C++ library, because the model generator will become 
      # part of the experiment data
      modeler.thisown = False

      # call the modeler
      modeler.setUserName( self.model_name_edit.text() )
      self.main_widget.getExperiment().addModelGenerator( modeler )
      self.main_widget.getExperiment().modelAll( modeler, self.main_widget.getExperiment(), self.options)
      self.main_widget.selector_widget.updateModelList()
      self.main_widget.selector_widget.selectLastModel()
      self.main_widget.updateMinMaxValue()

      # must happen before 'valuesChanged' to update the color boxes
      self.main_widget.selector_widget.tree_model.valuesChanged()
      self.main_widget.update()