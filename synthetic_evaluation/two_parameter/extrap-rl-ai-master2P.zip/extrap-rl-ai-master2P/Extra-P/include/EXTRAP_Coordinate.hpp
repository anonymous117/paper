/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_COORDINATE_HPP
#define EXTRAP_COORDINATE_HPP

#include <EXTRAP_Parameter.hpp>
#include <EXTRAP_IoHelper.hpp>

namespace EXTRAP
{
class Coordinate : public ParameterValueList
{
public:
    static const std::string COORDINATE_PREFIX;

    Coordinate*
    copy() const;

    virtual void
    setId( int64_t id );

    virtual int64_t
    getId( void ) const;

    virtual bool
    serialize(
        IoHelper* helper );

    virtual const std::string
    toString() const;

    static Coordinate*
    deserialize(
        const Experiment* experiment,
        IoHelper*         helper );

private:
    int64_t m_id;
};
bool
lessCoordinate( const Coordinate* lhs,
                const Coordinate* rhs );

typedef std::vector<Coordinate*> CoordinateList;
};


#endif
