/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_FUNC_GEN_HPP
#define EXTRAP_FUNC_GEN_HPP

#include <EXTRAP_Function.hpp>
#include <EXTRAP_CompoundTerm.hpp>


namespace EXTRAP
{
enum FunctionCategory { CONST_CAT, COMMON_CAT, RARE_CAT, EXOTIC_CAT };

class FunctionGenerator
{
public:
    FunctionGenerator( FunctionCategory functionCat,
                       int              terms );

    virtual
    ~FunctionGenerator();

    virtual EXTRAP::Function*
    getFunction() = 0;

protected:
    double
    getRandomCoeff();

    int
    getRandomIdx( int lo,
                  int hi );

    virtual void
    generateCompoundTerm( EXTRAP::CompoundTerm& compTerm,
                          FunctionCategory&     actualCat,
                          bool&                 isTrivial );

    bool
    flipCoin();

    int
    randomSwitch( int min,
                  int max );

    FunctionCategory m_functionCat;
    int              m_terms;

    std::vector<double> m_expPolyCommon;
    std::vector<double> m_expPolyRare;
    std::vector<double> m_expPolyExotic;
    std::vector<double> m_expLogCommon;
    std::vector<double> m_expLogRare;
    std::vector<double> m_expLogExotic;
};
}

#endif   // EXTRAP_FUNC_GEN_HPP
