/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_SIMPLE_MODELER_HPP
#define EXTRAP_SINGLE_PARAMETER_SIMPLE_MODELER_HPP

#include <EXTRAP_SingleParameterFunctionModeler.hpp>
#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterFunction.hpp>
#include <EXTRAP_SingleParameterHypothesis.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
class SingleParameterSimpleFunctionModeler : public SingleParameterFunctionModeler
{
public:
    SingleParameterSimpleFunctionModeler();

    void
    addHypothesisBuildingBlock( CompoundTerm Term );

    void
    generateHypothesisBuildingBlockSet( const std::vector<double>& poly_exponents,
                                        const std::vector<double>& log_exponents );

    void
    generateDefaultHypothesisBuildingBlocks();

    const std::vector<CompoundTerm>&
    getBuildingBlocks( void ) const;

    void
    printHypothesisBuildingBlocks( void );

    void
    setMaxTermCount( int );

    virtual SingleParameterHypothesis
    createModel( const Experiment*             experiment,
                 const ModelGeneratorOptions&  options,
                 const std::vector<DataPoint>& modeledDataPointList,
                 ModelCommentList&             comments,
                 const Function*               expectationFunction = NULL );

    virtual bool
    initSearchSpace( void );

    virtual bool
    nextHypothesis( void );

    virtual SingleParameterFunction*
    buildCurrentHypothesis( void );

    int
    getMaxTermCount( void ) const;

protected:
    //Start of external state
    std::vector<CompoundTerm> m_hypotheses_building_blocks;
    int                       m_max_term_count;
    //End of external state

    int              m_current_hypothesis;
    int              m_current_term_count;
    std::vector<int> m_current_hypothesis_building_block_vector;
};
};

#endif
