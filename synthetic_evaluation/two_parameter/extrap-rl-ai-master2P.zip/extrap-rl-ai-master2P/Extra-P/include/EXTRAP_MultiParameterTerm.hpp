/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_MULTIPARAMETERTERM_HPP
#define EXTRAP_MULTIPARAMETERTERM_HPP

#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SimpleTerm.hpp>
#include <EXTRAP_Function.hpp>

namespace EXTRAP
{
class MultiParameterTerm : public Function
{
public:
    static const std::string MULTIPARAMETERTERM_PREFIX;
    MultiParameterTerm( void );
    MultiParameterTerm( const MultiParameterTerm& obj );


    virtual Value
    evaluate( const ParameterValueList& parameterValues ) const;

    void
    addCompoundTermParameterPair( const CompoundTerm& ct,
                                  const Parameter&    param );

    std::vector<std::pair<CompoundTerm, Parameter> >&
    getCompoundTermParameterPairs( void );

    const std::vector<std::pair<CompoundTerm, Parameter> >&
    getCompoundTermParameterPairs( void ) const;

    void
    setCoefficient( Value v );

    Value
    getCoefficient( void ) const;


    virtual std::string
    getAsString( const ParameterList& parameterNames ) const;

    virtual Function*
    clone( void ) const;

    virtual bool
    serialize( IoHelper* ioHelper ) const;

    static MultiParameterTerm
    deserialize( IoHelper* ioHelper );

private:
    std::vector<std::pair<CompoundTerm, Parameter> > m_compound_term_parameter_pairs;
    Value                                            m_coefficient;
};
bool
equal( const MultiParameterTerm* lhs,
       const MultiParameterTerm* rhs );
};
#endif
