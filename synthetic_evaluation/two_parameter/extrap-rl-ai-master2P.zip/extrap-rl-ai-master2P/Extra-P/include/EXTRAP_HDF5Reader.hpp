/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_HDF5READER_HPP
#define EXTRAP_HDF5READER_HPP

#include <EXTRAP_Experiment.hpp>
#include <EXTRAP_IncrementalPoint.hpp>
#include <H5Cpp.h>
#include <H5Group.h>
#include <H5DataSet.h>

using namespace H5;

namespace EXTRAP
{
class HDF5Reader
{
public:
    static const std::string H5_METRIC_ATTRIBUTE;
    static const std::string H5_UNIT_ATTRIBUTE;
    static const std::string H5_PARAMETER_ATTRIBUTE;
    static const std::string H5_VALUES_ATTRIBUTE;
    static const std::string H5_SOURCE_ATTRIBUTE;
    static const std::string H5_SOURCELINE_ATTRIBUTE;
    static const StrType     H5_STR_TYPE;
    HDF5Reader( const std::string& filename );
    ~HDF5Reader();
    //reads the HDF5 File
    Experiment*
    read();

protected:

    bool
    readData( const H5File* file );

private:
    //the ouptput experiment
    Experiment* m_experiment;
    //the list of files to read
    const std::string m_filename;
    //the file that is read
    H5File* m_file;
    //Begin lookup vectors for coordinates
    std::vector<std::vector<std::vector<Coordinate*> > > m_coordinates3D;
    std::vector<std::vector<Coordinate*> >               m_coordinates2D;
    std::vector<Coordinate*>                             m_coordinates1D;
    //a lookup map for regions by their name
    std::map<const std::string, Region*> m_regions;
    //a lookup map for metrics by their name
    std::map<const std::string, Metric*> m_metrics;
    //The parameters used in this experiment
    ParameterList m_parameters;
    /**
     * Extracts a region from the groups attribute given if they exist, returns NULL if not
     **/
    Region*
    extract_region( const std::string& regName,
                    const Group*       group,
                    const Attribute*   sourceAttr,
                    const Attribute*   lineAttr );

    /**
     * Extracts a metric from the groups attribute given if they exist, returns NULL if not
     **/
    Metric*
    extract_metric( const std::string& metricName,
                    const Group*       group,
                    const Attribute*   unitAttr );

    /**
     * Processes a group, depending on the group being a metric, a region or the root group.
     * Will recursively call process the groups child objects.
     * @param group :  the group that is processed
     * @param possibleParent: the parent Callpath(if it exists)
     * @param str: the name of the group that should be processed
     **/
    bool
    process_group( const Group*       group,
                   Callpath*          possibleParent,
                   const std::string& str );

    /**
     *  Processes the root group, meaning reading parameters, and parameter Values and creating the coordinates as well as creating the coordinate lookups
     *  returns false on malfunction
     **/
    bool
    process_root_group( const Group* root );

    bool
    process_dataset( const DataSet* set,
                     const Metric* metric,
                     const Callpath* callpath,
                     std::map<Coordinate*, IncrementalPoint*>& coordinateToIncrementalPoints );

    /**
     * Recursively creates Coordinates and adds them to the experiment, as well as a lookup array (m_coordinates1D,m_coordinates2D,m_coordinates3D)
     * returns false on malfunction
     **/
    bool
    create_coordinate_rec( int                               paramIndex,
                           std::vector<std::vector<Value> >& paramValues,
                           std::vector<Value>                indexVector,
                           Coordinate                        cand );

    /**
     * Creates Experiment Points from the IncrementalPoints stored in m_coordinates_to_incrementalpoints. Also deletes the IncrementalPoints afterward
     * returns false on malfunction
     **/
    bool
    create_experiment_points( Callpath* cp,
                              Metric* m,
                              std::map<Coordinate*, IncrementalPoint*>& coordinateToIncrementalPoints );

    /**
     * Sets up the lookup array (m_coordinates1D,m_coordinates2D,m_coordinates3D)
     * returns false on malfunction
     **/
    bool
    prepare_coordinate_vectors( std::vector<std::vector<Value> >& paramValues );
};
};

#endif
