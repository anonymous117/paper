/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2019,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_SINGLE_PARAMETER_MODEL_GENERATOR_HPP
#define EXTRAP_SINGLE_PARAMETER_MODEL_GENERATOR_HPP

#include <EXTRAP_ModelGenerator.hpp>
#include <EXTRAP_CompoundTerm.hpp>
#include <EXTRAP_SingleParameterHypothesis.hpp>
#include <EXTRAP_SingleParameterSimpleFunctionModeler.hpp>
#include <EXTRAP_ModelGeneratorOptions.hpp>

namespace EXTRAP
{
class SingleParameterFunction;

class SingleParameterModelGenerator : public ModelGenerator
{
public:
    SingleParameterModelGenerator();

    virtual
    ~SingleParameterModelGenerator();

    virtual Model*
    createModel( const Experiment*            experiment,
                 const ModelGeneratorOptions& options,
                 const ExperimentPointList&   modeledDataPointList,
                 const Function*              expectationFunction = NULL );

    void
    setCrossvalidationMethod( Crossvalidation cvMethod );

    Crossvalidation
    getCrossvalidationMethod( void ) const;

    void
        setEpsilon( Value );

    Value
    getEpsilon( void ) const;

    void
    setModelGeneratorOptions( ModelGeneratorOptions options );

    ModelGeneratorOptions
    getModelGeneratorOptions( void ) const;

    virtual bool
    serialize( IoHelper* ioHelper ) const = 0;

protected:
    virtual SingleParameterFunctionModeler&
    getFunctionModeler() const = 0;

    void
    deserialize( IoHelper* ioHelper );

    //Start of external state
    ModelGeneratorOptions m_options;
    //End of external state
};
};

#endif
