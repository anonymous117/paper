/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017-2018,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef EXTRAP_VISITOR_HPP
#define EXTRAP_VISITOR_HPP

#include <EXTRAP_Callpath.hpp>
namespace EXTRAP
{
class Visitor
{
public:
    virtual void
    visit( Callpath* cp ) = 0;
};

void
Callpath::accept( Visitor& v )
{
    v.visit( this );
}
};

#endif
