/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 * @file
 * @brief Declaring a class for reading cube files and storing
 * the relevant content in a textual representation as well as
 * reading the alternate respresentation.
 */

#ifndef EXTRAP_CUBEFILEREADER_HPP_
#define EXTRAP_CUBEFILEREADER_HPP_

#include <EXTRAP_Region.hpp>
#include <EXTRAP_Experiment.hpp>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cassert>

namespace cube
{
class Cnode;
class Region;
}

namespace EXTRAP
{
typedef void (* CallbackFunction)( void* func );
/**
 * @brief This class is used to read cube4 files
 * and store the relevant information in an Experiment.
 * It's intended use is to have one instance for
 * reading multiple cube Files. Use the prepareCubeFileReader methods
 * to reinitialize the Reader with new Data.
 */

struct FileName
{
    std::string path;
    double      parameter1;
    double      parameter2;
    double      parameter3;
    int         repetition;
};

class CubeFileReader
{
public:
    CubeFileReader();
    /**
     * Allows to externally set a callback function that is called by make_progress.
     * The program will work correctly without having a callback registered. This is
     * mainly thought for allowing the GUI having a callback from the loading.
     **/
    void
    setCallbackFunction( CallbackFunction cb,
                         void*            func );

    void
    addParameter( const Parameter&        param,
                  const std::string&      prefix,
                  const std::vector<int>& values );

    /**
     * Prepare the CubeFileReader for the next read action
     * by passing him a Cube Conf File
     */
    void
    prepareCubeFileReader( const std::string& pathToCubeConf );

    /**
     * Prepare the CubeFileReader for the next read action
     * by passing him most of the different parameters directly.
     * Vector parameters are not passed here but by the
     * addParameter method (Used by the Gui due to Python incompatibilities)
     */
    void
    prepareCubeFileReader(  int                scalingType,
                            const std::string& dir,
                            const std::string& prefix,
                            const std::string& postfix,
                            const std::string& cubeFileName,
                            int                reps );

    /**
     * Prepare the CubeFileReader for the next read action
     * by passing him all parameters manually
     */
    void
    prepareCubeFileReader( int                                   scalingType,
                           const std::string&                    dir,
                           const std::string&                    prefix,
                           const std::string&                    postfix,
                           const std::string&                    cubeFileName,
                           const ParameterList&                  parameters,
                           const std::vector<std::string>&       parameterPrefixes,
                           const std::vector<std::vector<int> >& parameterValues,
                           int                                   reps );

    Experiment*
    readCubeFiles( int dimensions );

    std::vector<FileName>
    getFileNames( int           numDimensions,
                  ParameterList paramlist );

    void
    getCoordinates( std::vector<FileName> file_name_objects,
                    ParameterList         paramlist,
                    int                   repetitions );

private:

    void
    make_progress() const;
    void
    clear();

    bool
    isReadyToRead() const;

    std::vector<std::vector<int> >
    getCombinationsRec( int                            param,
                        std::vector<int>               candidate,
                        std::vector<std::vector<int> > result,
                        int                            anchor,
                        Coordinate                     pmList );

    std::vector<std::vector<int> >
    getCombinations( int anchor );

    CallbackFunction               m_callback;
    void*                          m_callback_function;
    int                            m_scaling_type;
    std::string                    m_cube_file_name;
    std::string                    m_dir;
    std::string                    m_prefix;
    std::string                    m_postfix;
    std::vector<std::vector<int> > m_parameter_values;
    ParameterList                  m_parameters;
    CoordinateList                 m_parameter_value_lists;
    std::vector<std::string>       m_parameter_prefixes;
    int                            m_reps;
    bool                           m_use_input_file_name_list;
    bool                           m_use_reps_postfix;
};
};
#endif
