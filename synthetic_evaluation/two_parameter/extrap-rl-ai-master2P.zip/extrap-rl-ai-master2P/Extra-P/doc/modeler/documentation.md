# Extra-P modeler Documentation

What this tool does:

1. read either _input text files_ or sets of _cube files_
2. load experiment from input
3. run the extra-p modeler (i.e. create a model) from the experiment
4. save the experiment with the model as an experiment file

## Usage

```
Extrap modeler.

Usage:
  extrap-modeler input <inputfile> [-o=<out>] [--simple --poly=<poly>
--log=<log> <terms>] [--model=<m>] [--modelname=<n>]  [--debug]
  extrap-modeler cube <cubedir> [-o=<out>] [--simple --poly=<poly> --log=<log>
<terms>] [--model=<m>] [--modelname=<n>] [options] [--debug]
  extrap-modeler json  <jsonfile> [-o=<out>] [--simple --poly=<poly> 
--log=<log> <terms>] [--model=<m>] [--modelname=<n>]  [--debug]
  extrap-modeler experiment <experimentfile> [-o=<out>] [--simple 
--poly=<poly> --log=<log> <terms>] [--model=<m>] [--modelname=<n>]  [--debug]
  extrap-modeler -h | --help
  extrap-modeler --version

Options:
  -o=<out>                 Write output to <out> [default: ./out].
  --simple                 Use simple modeler (else use refining modeler)
  --poly=<poly>            Polynomial exponents for simple modeler e.g. '1.0,1.5,1.8'
  --log=<log>              Logarithm exponents for simple modeler e.g. '1.0,1.5,1.8'
  --model=<m>              Model (means | medians) [default: means]
  --modelname=<n>          Model name [default: default]
  --filename=<filename>    Cube files filename [default: profile.cubex]
  --parameter=<parameter>  Cube files parameter (disables parameter auto detection)
  --prefix=<prefix>        Cube files prefix (disables prefix auto detection).
  --postfix=<postfix>      Cube files postfix (disables postfix auto detection).
  --values=<values>        Cube files values e.g. '32,64,128' (disables values auto detection).
  --scaling=<scaling>      Cube files scaling (weak | strong) [default: weak]
  --repetitions=<reps>     Cube files repetitions (disables repetitions auto detection).
  -h --help                Show this screen.
  --version                Show version.
  --debug                  Enable debug logs.
```

## Opening Text Input Files

```
extrap-modeler input <inputfile> [options omitted for brevity]
```

## Opening Set of Cube Files

```
extrap-modeler cube <cubedir> [options omitted for brevity]
```

## Opening JSON Input Files

```
extrap-modeler json <jsonfile> [options omitted for brevity]
```

## Opening experiment Files

```
extrap-modeler experiment <experimentfile> [options omitted for brevity]
```

## Choosing The Modeler

use refining modeler (default behaviour)

use simple modeler:

```
--simple --poly=<poly> --log=<log> <terms>
```

* `--poly=<poly>` set polynomial exponents used by the simple modeler.
* `--log=<log>`set of logarithm exponents used by the simple modeler.
* `<terms>` number of terms for the model.

Modeler Specific Options

* `--model=<m>` choose what to model: either the (default: `means`) or medians.
* `--modelname=<n>` the name for the created model.

## Cube Files Loading Configuration

* `--filename=<filename>` override default cube file names (default: `profile.cubex`)

Note: the following options partially override the auto detection
made using cube file names.

* `--parameter=<parameter>` parameter name (disables parameter auto detection)
* `--prefix=<prefix>` cube files prefix (disables prefix auto detection).
* `--postfix=<postfix>` cube files postfix (disables postfix auto detection).
* `--values=<values>` cube files values e.g. '32,64,128' (disables values auto detection).
* `--scaling=<scaling>` cube files scaling (weak | strong) [default: `weak`]
* `--repetitions=<reps>` cube files repetitions (disables repetitions auto detection).

## Examples

### Open text input file, run refining modeler

Open `input.txt`, run refining modeler and save experiment file to `out`.

`./extrap-modeler input input.txt`

```
INFO:root:opening text input: input.txt
INFO:root:saving experiment to: ./out
```

### Open text input file, run simple modeler

Open `input.txt`, run simple modeler and save file to `output`.

`./extrap-modeler input input.txt -o output --simple --poly 0.1,0.2,0.5,1.0,1.2 --log 1 1`

```
INFO:root:opening text input: input.txt
INFO:root:saving experiment to: output
```

### Open set of cube files, run refining modeler

Open set of cube files `sweep3D`, run refining modeler on medians with debug logs enabled.

`./extrap-modeler cube sweep3D --model medians --debug`

```
DEBUG:root:{'--debug': True,
 '--filename': 'profile.cubex',
 '--help': False,
 '--log': None,
 '--model': 'medians',
 '--parameter': None,
 '--poly': None,
 '--postfix': None,
 '--prefix': None,
 '--repetitions': None,
 '--scaling': 'weak',
 '--simple': False,
 '--values': None,
 '--version': False,
 '-o': './out',
 '<cubedir>': 'sweep3D',
 '<inputfile>': None,
 '<term>': None,
 'cube': True,
 'input': False}
INFO:root:opening cube files: sweep3D
DEBUG:root:{'prefix': 'scorep_scorep_weak.', 'postfix': '', 'parameter': 'p',
'scaling': 1, 'repetitions': 4, 'values': [32, 64, 128, 256, 512, 1024, 2048],
'filename': 'profile.cubex'}
DEBUG:root:using refining model generator
DEBUG:root:model: medians
INFO:root:saving experiment to: ./out
```

### Open set of cube files run simple modeler

Open set of cube files `sweep3D`, run simple modeler, override values with debug logs enabled.

`./extrap-modeler cube sweep3D --simple --poly 0.1,0.2,1.0,1.2 --log 1 1 --values 32,64 --debug`

```
DEBUG:root:{'--debug': True,
 '--filename': 'profile.cubex',
 '--help': False,
 '--log': '1',
 '--model': 'means',
 '--parameter': None,
 '--poly': '0.1,0.2,1.0,1.2',
 '--postfix': None,
 '--prefix': None,
 '--repetitions': None,
 '--scaling': 'weak',
 '--simple': True,
 '--values': '32,64',
 '--version': False,
 '-o': './out',
 '<cubedir>': 'sweep3D',
 '<inputfile>': None,
 '<term>': '1',
 'cube': True,
 'input': False}
INFO:root:opening cube files: sweep3D
DEBUG:root:{'filename': 'profile.cubex', 'scaling': 1, 'values': [32, 64],
'postfix': '', 'repetitions': 4, 'parameter': 'p', 'prefix':
'scorep_scorep_weak.'}
DEBUG:root:using simple model generator
DEBUG:root:polynomial exponents: [0.1, 0.2, 1.0, 1.2]
DEBUG:root:logarithm exponents: [1.0]
DEBUG:root:model: means
INFO:root:saving experiment to: ./out
```

### Open set of cube files, override metadata

Open set of cube files in `test/data/` set prefix, set postfix, number of repetitions, name of parameter and values.

```
test/data
    mm.x1000y1z1.r1
    mm.x100y1z1.r1
    mm.x10y1z1.r1
    mm.x1y1z1.r1
    mm.x2000y1z1.r1
    mm.x250y1z1.r1
    mm.x25y1z1.r1
    mm.x500y1z1.r1
    mm.x50y1z1.r1
```

```
./extrap-modeler cube test/data --prefix mm. --postfix y1z1 --repetition 1 --parameter x --values 1,10,25
```

```
INFO:root:opening cube files: test/data
ERROR:root:files in test/data do not match cube file name format
INFO:root:saving experiment to: ./out
```

Note: despite of `ERROR:root:files in test/data do not match cube file name format` the cube files are opened successfully.


### Open json file, run simple modeler

Open a json file in `test/data/input` run simple modeler and save file to `output`.

`./extrap-modeler json input.txt -o output --simple --poly 0.1,0.2,0.5,1.0,1.2 --log 1 1`

```
INFO:root:opening json input: input.txt
INFO:root:saving experiment to: output
```

Note: The json input method can be used with the same arguments as the input method. It only reads a different JSON like input format.


### Open experiment input file, run refining modeler

Open `out` in Binary format (a serialized ExtraP experiment), run refining modeler and save experiment file to `out`.

`./extrap-modeler experiment out`

```
INFO:root:opening extrap file: out
INFO:root:saving experiment to: ./out
```

Note: The experiment input method can be used with the same arguments as the input method. It only reads an already existing ExtraP experiment file as binary and converts it back to an ExtraP experiment. After that e.g. a new modeler can be created. The experiment can be overwritten or saved to a new location.
