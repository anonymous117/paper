# EXTRAP Printer

Command Line Tool for Extra-P (<http://www.scalasca.org/software/extra-p/download.html>)

## Usage

```
"""Experiment File Printer.

Usage:
  extrap-print <file> [-o=<out>] [--debug]
  extrap-print <file> (callpaths | regions | metrics parameters | json | function) [-o=<out>] [--debug]
  extrap-print -h | --help
  extrap-print --version

Options:
  -o=<out>                  Write output to <out>.
  -h --help                 Show this screen.
  --version                 Show version.
  --debug                   Enable debug logs.
"""
```

## Examples

> Print experiment-file content

`./extrap-print experiment-file`

```
INFO:root:opening: experiment-file
callpath: met1
	metric: Test
		 1.00E+03 Mean: 4.02E+00 Median: 4.00E+00
		 2.00E+03 Mean: 4.02E+00 Median: 4.00E+00
		 4.00E+03 Mean: 4.08E+00 Median: 4.10E+00
		 8.00E+03 Mean: 4.02E+00 Median: 4.00E+00
		 1.60E+04 Mean: 4.20E+00 Median: 4.10E+00
		 model: 3.94994+0.00166031*(p^0.5)
		 RSS: 8.71E-03
		 Adjusted R^2: 5.26E-01
callpath: met2
	metric: Test
		 1.00E+03 Mean: 1.00E+00 Median: 1.00E+00
		 2.00E+03 Mean: 4.00E+00 Median: 4.00E+00
		 4.00E+03 Mean: 1.60E+01 Median: 1.60E+01
		 8.00E+03 Mean: 6.40E+01 Median: 6.40E+01
		 1.60E+04 Mean: 2.56E+02 Median: 2.56E+02
		 model: 0+9.99998e-07*(p^2)
		 RSS: 3.64E-06
		 Adjusted R^2: 1.00E+00
callpath: met1
	metric: Test
		 1.00E+03 Mean: 2.00E+00 Median: 2.00E+00
		 2.00E+03 Mean: 6.02E+00 Median: 6.00E+00
		 4.00E+03 Mean: 1.90E+01 Median: 1.90E+01
		 8.00E+03 Mean: 6.80E+01 Median: 6.80E+01
		 1.60E+04 Mean: 2.61E+02 Median: 2.61E+02
		 model: 2.18225+1.01217e-06*(p^2)
		 RSS: 3.09E+00
		 Adjusted R^2: 1.00E+00
callpath: met3
	metric: Test
		 1.00E+03 Mean: 1.00E+06 Median: 1.00E+06
		 2.00E+03 Mean: 4.00E+06 Median: 4.00E+06
		 4.00E+03 Mean: 1.60E+07 Median: 1.60E+07
		 8.00E+03 Mean: 6.40E+07 Median: 6.40E+07
		 1.60E+04 Mean: 2.56E+08 Median: 2.56E+08
		 model: 0+1*(p^2)
		 RSS: 1.87E+01
		 Adjusted R^2: 1.00E+00
```

> Print metrics from sweep3D experiment file and save output to output.txt

`./extrap-print sweep3D metrics -o output.txt`

```
INFO:root:opening: sweep3D
visits
time
min_time
max_time
bytes_sent
inter_node_bytes_sent
bytes_received
inter_node_bytes_received
INFO:root:output written to: output.txt
```

> Print call paths from sweep3D experiment file, save output to out.txt, with debug logs enabled.

`./extrap-print sweep3D callpaths -o out.txt --debug`

```
DEBUG:root:{'--debug': True,
 '--help': False,
 '--version': False,
 '-o': 'out.txt',
 '<file>': 'sweep3D',
 'callpaths': True,
 'metrics': False,
 'regions': False}
INFO:root:opening: sweep3D
DEBUG:root:printing call paths
driver
driver->task_init
driver->task_init->MPI_Init
driver->task_init->MPI_Comm_size
driver->task_init->MPI_Comm_rank
driver->task_init->bcast_int
driver->task_init->bcast_int->MPI_Bcast
driver->task_init->barrier_sync
driver->task_init->barrier_sync->MPI_Barrier
driver->read_input
driver->read_input->bcast_int
driver->read_input->bcast_int->MPI_Bcast
driver->read_input->bcast_real
driver->read_input->bcast_real->MPI_Bcast
driver->decomp
driver->inner_auto
driver->inner_auto->inner
driver->inner_auto->inner->initialize
driver->inner_auto->inner->initialize->initxs
driver->inner_auto->inner->initialize->initsnc
driver->inner_auto->inner->initialize->initsnc->octant
driver->inner_auto->inner->initialize->initgeom
driver->inner_auto->inner->barrier_sync
driver->inner_auto->inner->barrier_sync->MPI_Barrier
driver->inner_auto->inner->source
driver->inner_auto->inner->sweep
driver->inner_auto->inner->sweep->octant
driver->inner_auto->inner->sweep->rcv_real
driver->inner_auto->inner->sweep->rcv_real->MPI_Recv
driver->inner_auto->inner->sweep->snd_real
driver->inner_auto->inner->sweep->snd_real->MPI_Send
driver->inner_auto->inner->global_int_sum
driver->inner_auto->inner->global_int_sum->MPI_Allreduce
driver->inner_auto->inner->flux_err
driver->inner_auto->inner->flux_err->global_real_max
driver->inner_auto->inner->flux_err->global_real_max->MPI_Allreduce
driver->inner_auto->inner->global_real_sum
driver->inner_auto->inner->global_real_sum->MPI_Allreduce
driver->task_end
driver->task_end->MPI_Finalize
INFO:root:output written to: out.txt
```

> Print generated model function of an experiment file 'out' and save the function to 'function'.txt.

`./extrap-print out function -o function.txt`

```
INFO:root:opening: out
40.1206 + 0.932094*(x**1)*(y**2) + 0.10034*(x**1)*(y**2)*(z**1)
INFO:root:output written to: function
```

> Print JSON object of the experiment 'out' with the generated model function and save the JSON file to 'experiment.json'.

`./extrap-print out json -o experiment.json`

```
INFO:root:opening: out
{'parameters': ['x', 'y', 'z'], 'model': {'python': '40.1206 + 0.932094*(x**1)*(y**2) + 0.10034*(x**1)*(y**2)*(z**1)'}}
INFO:root:output written to: experiment.json
```

## Dependencies

* docopt (command line parsing <https://github.com/docopt/docopt>)
* Extra-P (<http://www.scalasca.org/software/extra-p/download.html>)
