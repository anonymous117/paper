/*
 * This file is part of the Extra-P software (http://www.scalasca.org/software/extra-p)
 *
 * Copyright (c) 2017,
 * Technische Universitaet Darmstadt, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stdio.h>
#include <iostream>
#include <EXTRAP_Interface.hpp>
#include <EXTRAP_SingleParameterSimpleModelGenerator.hpp>
#include <cmath>
#include <EXTRAP_CubeFileReader.hpp>
#include <realtime/EXTRAP_QuantileApproximator.hpp>
#include <realtime/EXTRAP_RealtimeDataPoint.hpp>

using namespace std;

double
testComputeAverage( vector<EXTRAP::Value> vec )
{
    double average = 0.0;
    for ( int i = 0; i < vec.size(); i++ )
    {
        average += vec[ i ];
    }
    average /= vec.size();

    return average;
}

double
testComputeStdDeviation( vector<EXTRAP::Value> vec )
{
    double        average = testComputeAverage( vec );
    EXTRAP::Value sum     = 0.0;
    for ( int i = 0; i < vec.size(); i++ )
    {
        sum += pow( vec[ i ] - average, 2 );
    }

    return sqrt( 1.0 / vec.size() * sum );
}

double
testComputeMedian( vector<EXTRAP::Value> vec )
{
    std::sort( vec.begin(), vec.end() );
    int len = vec.size();
    if ( len % 2 == 0 )
    {
        return ( vec[ len / 2 - 1 ] + vec[ len / 2 ] ) / 2.0;
    }
    else
    {
        return vec[ ( len - 1 ) / 2 ];
    }
}

#define EPSILON 1E-13;

bool
doubleEquals( double x, double y )
{
    return std::fabs( x - y ) < EPSILON;

    //double maxXYOne = std::max( { 1.0, std::fabs(x) , std::fabs(y) } ) ;
    //return std::fabs(x - y) <= std::numeric_limits<double>::epsilon()*maxXYOne ;
}

int
main()
{
    EXTRAP::SingleParameterSimpleModelGenerator* bob = new EXTRAP::SingleParameterSimpleModelGenerator();
    EXTRAP::ExperimentPointList                  input;
    EXTRAP::Interval                             interval;
    interval.start = 0;
    interval.end   = 0;
    EXTRAP::Parameter*    param = new EXTRAP::Parameter( "p" );
    EXTRAP::ParameterList paramlist;
    paramlist.push_back( *param );
    EXTRAP::ParameterValueList pvl1, pvl2, pvl3, pvl4, pvl5;
    pvl1.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 1 ) );
    pvl2.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 2 ) );
    pvl3.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 3 ) );
    pvl4.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 4 ) );
    pvl5.insert( std::pair<EXTRAP::Parameter, EXTRAP::Value>( *param, 5 ) );
    double                   y1 = 50 + 10;
    double                   y2 = 100 + 40;
    double                   y3 = 150 + 90;
    double                   y4 = 200 + 160;
    double                   y5 = 250 + 250;
    EXTRAP::ExperimentPoint* i1 = new EXTRAP::ExperimentPoint( &pvl1, 1, y1, interval, 0, y1, interval, y1, y1, NULL, NULL );
    EXTRAP::ExperimentPoint* i2 = new EXTRAP::ExperimentPoint( &pvl2, 1, y2, interval, 0, y2, interval, y2, y2, NULL, NULL );
    EXTRAP::ExperimentPoint* i3 = new EXTRAP::ExperimentPoint( &pvl3, 1, y3, interval, 0, y3, interval, y3, y3, NULL, NULL );
    EXTRAP::ExperimentPoint* i4 = new EXTRAP::ExperimentPoint( &pvl4, 1, y4, interval, 0, y4, interval, y4, y4, NULL, NULL );
    EXTRAP::ExperimentPoint* i5 = new EXTRAP::ExperimentPoint( &pvl5, 1, y5, interval, 0, y5, interval, y5, y5, NULL, NULL );
    input.push_back( i1 );
    input.push_back( i2 );
    input.push_back( i3 );
    input.push_back( i4 );
    input.push_back( i5 );
    EXTRAP::CompoundTerm t1, t2, t3, t4, t5;
    t1.setCoefficient( 42 );
    EXTRAP::SimpleTerm   s1, s2, s3;
    EXTRAP::FunctionType poly = EXTRAP::polynomial;
    EXTRAP::FunctionType log  = EXTRAP::logarithm;

    s1.setFunctionType( poly );
    s1.setExponent( 1 );
    s2.setFunctionType( poly );
    s2.setExponent( 2 );
    s3.setFunctionType( log );
    s3.setExponent( 1 );
    t1.addSimpleTerm( s3 );
    t2.addSimpleTerm( s1 );
    t3.addSimpleTerm( s2 );
    t4.addSimpleTerm( s3 );
    t4.addSimpleTerm( s1 );
    t5.addSimpleTerm( s3 );
    t5.addSimpleTerm( s2 );
    t1.setCoefficient( 1 );
    t2.setCoefficient( 1 );
    t3.setCoefficient( 1 );
    t4.setCoefficient( 1 );
    t5.setCoefficient( 1 );

    bob->addHypothesisBuildingBlock( t1 );
    bob->addHypothesisBuildingBlock( t2 );
    bob->addHypothesisBuildingBlock( t3 );
    bob->addHypothesisBuildingBlock( t4 );
    bob->addHypothesisBuildingBlock( t5 );
    bob->printHypothesisBuildingBlocks();
    bob->setMaxTermCount( 2 );
    DebugStream << "=== No crossvalidation ===" << endl;
    bob->setCrossvalidationMethod( EXTRAP::CROSSVALIDATION_NONE );
    EXTRAP::Model* m1 = bob->createModel( input, NULL );
    DebugStream << "Selected model: " << dynamic_cast<EXTRAP::SingleParameterFunction*>( m1->getModelFunction() )->getAsString( "p" ) << endl;
    DebugStream << "=== Leave-one-out crossvalidation ===" << endl;
    bob->setCrossvalidationMethod( EXTRAP::CROSSVALIDATION_LEAVE_ONE_OUT );
    EXTRAP::Model* m2 = bob->createModel( input, NULL );
    DebugStream << "Selected model: " << dynamic_cast<EXTRAP::SingleParameterFunction*>( m2->getModelFunction() )->getAsString( "p" ) << endl;
    assert( m2->getComments().empty() );
    delete i1;
    delete i2;
    delete i3;
    delete i4;
    delete i5;

    // read experiment file
    //EXTRAP::Experiment* experiment = EXTRAP::Experiment::openExtrapExperimentFile( "data/experiment.txt" );
    //delete experiment;

    const EXTRAP::Value arr[] = { 2.0,    2.1,       2.002,        2.03,           2.001,            2.4,                2.02,                 2.003,
                                  2.1,    3.0,       2.03,         2.006,          2.1,              2.2,                2.004,                2.007,
                                  2.3,    2.9,       2.8,          2.03,           2.0,              2.001,              2.0,                  2.002,
                                  2.2,    2.002,     2.006,        2.05,           2.4,              2.002,              2.0,                  2.0,
                                  2.001,  2.002,     2.0001,       2.001,          2.00003,          2.002,              2.01,                 2.2,
                                  2.0001, 2.0,       2.0,          2.02,           2.04,             2.002,              2.5,                  2.7,
                                  2.6,    2.0,       3.0,          200.0,          2.0,              2.0,                2.0,                  2.0,
                                  2.0,    2.0,       2.0,          2.0,            2.0,              2.0,                2.0,                  2.0,
                                  2.0,    2.0,       2.0,          2.0,            2.0,              2.0,                2.0,                  2.0,
                                  2.1,    2.002,     2.03,         2.001,          2.0,              2.0,                2.2,                  2.0,
                                  2.4,    2.02,      2.003,        2.1,            2.03,             2.03,               2.006,                2.1,
                                  2.004,  2.007,     2.3,          2.9,            2.8,              2.03,               2.0,                  2.001,
                                  2.002,  2.2,       2.002,        2.006,          2.05,             2.4,                2.002,                2.0,
                                  2.0,    2.001,     2.002,        2.0001,         2.001,            2.00003,            2.002,                2.02,
                                  2.01,   2.2,       2.0001,       2.0,            2.0,              2.02,               2.04,                 2.002,
                                  2.5,    2.7,       2.0,          2.1,            2.002,            2.03,               2.001,                2.4,
                                  2.003,  2.1,       3.0,          2.03,           2.006,            2.1,                2.2,                  2.004,
                                  2.007,  2.3,       2.9,          2.8,            2.03,             2.0,                2.001,                2.0,
                                  2.2,    2.002,     2.006,        2.05,           2.4,              2.002,              2.0,                  2.0,
                                  2.001,  2.002,     2.0001,       2.001,          2.00003,          2.002,              2.01,                 2.002,
                                  2.2,    2.0001,    200.0,        2.0,            2.02,             2.04,               2.002,                2.5,
                                  2.0,    2.1,       2.002,        2.03,           2.001,            2.4,                2.02,                 2.003,
                                  3.0,    2.03,      2.006,        2.1,            2.01,             2.004,              2.007,                2.02,
                                  2.8,    2.03,      2.0,          2.001,          2.0,              2.002,              2.2,                  2.002,
                                  2.05,   2.006,     2.002,        2.0,            2.0,              2.001,              2.002,                2.0001,
                                  2.001,  2.00003,   2.002,        2.01,           2.03,             2.0001,             2.0,                  2.0,
                                  2.02,   2.04,      2.002,        2.004,          2.01,             2.7,                2.1,                  2.0,
                                  2.006 };

    const EXTRAP::Value arr2[] = { 0,   1,   2,   3,   4,   5,   6,   7,   8,   9,   10,   11,   12,   13,   14,   15,    16,
                                   17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,   28,   29,   30,   31,   32,    33,
                                   34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,   45,   46,   47,   48,   49,    50,
                                   51,  52,  53,  54,  55,  56,  57,  58,  59,  60,  61,   62,   63,   64,   65,   66,    67,
                                   68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,   79,   80,   81,   82,   83,    84,
                                   85,  86,  87,  88,  89,  90,  91,  92,  93,  94,  95,   96,   97,   98,   99,   100,   101,
                                   102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112,  113,  114,  115,  116,  117,   118,
                                   119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129,  130,  131,  132,  133,  134,   135,
                                   136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146,  147,  148,  149,  150,  151,   152,
                                   153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163,  164,  165,  166,  167,  168,   169,
                                   170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180,  181,  182,  183,  184,  185,   186,
                                   187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197,  198,  199,  200,  201,  202,   203,
                                   204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214,  215,  216 };

    const int arr_len = sizeof( arr ) / sizeof( arr[ 0 ] );

    vector<EXTRAP::Value> vec( arr, arr + arr_len );

    double                average = testComputeAverage( vec );
    vector<EXTRAP::Value> vals;
    vals.push_back( vec[ 0 ] );
    EXTRAP::Value              s  = testComputeStdDeviation( vals );
    EXTRAP::RealtimeDataPoint* rp = new EXTRAP::RealtimeDataPoint( vec[ 0 ], new EXTRAP::Region( "test", "main", 1 ), new EXTRAP::Metric( "Time", "seconds" ) );
    for ( int i = 1; i < vec.size(); i++ )
    {
        double next_val = vec[ i ];
        rp->update( next_val );
        vals.push_back( next_val );
        double avg_computed           = testComputeAverage( vals );
        double avg_estimate           = rp->getMean();
        double std_deviation_computed = testComputeStdDeviation( vals );
        double std_deviation_estimate = rp->getStandardDeviation();
        if ( !doubleEquals( avg_computed, avg_estimate ) || !doubleEquals( std_deviation_computed, std_deviation_estimate ) )
        {
            cout << "Test failed:" << endl
                 << "avg computed: " << avg_computed << "; avg estimate: " << avg_estimate << endl
                 << "std deviation computed: " << std_deviation_computed << "; std deviation estimate: " << std_deviation_estimate << endl;
            exit( EXIT_FAILURE );
        }
    }

    /*vec.clear();
       vec.push_back(1.0);
       vec.push_back(2.0);
       vec.push_back(1.7);

       double avg = computeAverage(vec);
       double true_sd = compStdDeviation(vec, avg);
       //////////////////////////////////////////////////////////////////
       double sd = 0.0;
       for (int i = 0; i < vec.size(); i++)
       {
        sd += pow(vec[i] - avg, 2);
       }
       sd = sqrt(sd / vec.size());
       //////////////////////////////////////////////////////////////////
       sd = 0.0;
       for (int i = 0; i < vec.size(); i++)
       {
        sd += pow(vec[i], 2) - 2 * vec[i] * avg + pow(avg, 2);
       }
       sd = sqrt(sd / vec.size());
       //////////////////////////////////////////////////////////////////
       sd = 0.0;
       for (int i = 0; i < vec.size(); i++)
       {
        sd += pow(vec[i], 2) - 2 * vec[i] * avg;
       }
       sd = sqrt((sd + vec.size() * pow(avg, 2)) / vec.size());
       //////////////////////////////////////////////////////////////////
       double sumPoint = 0.0;
       sd = 0.0;
       for (int i = 0; i < vec.size(); i++)
       {
        sumPoint += vec[i];
        sd += pow(vec[i], 2);
       }
       sd = sqrt((sd - 2 * avg * sumPoint + vec.size() * pow(avg, 2)) / vec.size());
       //////////////////////////////////////////////////////////////////
       sd = 0.0;
       for (int i = 0; i < vec.size(); i++)
       {
        sd += pow(vec[i], 2);
       }
       sd = sqrt((sd - 2 * pow(avg, 2) * vec.size() + vec.size() * pow(avg, 2)) / vec.size());
       //////////////////////////////////////////////////////////////////
       sd = 0.0;
       for (int i = 0; i < vec.size(); i++)
       {
        sd += pow(vec[i], 2);
       }
       sd = sqrt((sd - pow(avg, 2) * vec.size()) / vec.size());
       /////////////////////////////////////////////////////////////////*/

    cout << testComputeAverage( vec ) << "|" << testComputeStdDeviation( vec ) << "|" << arr_len << endl;
    cout << "left: " << rp->getMeanCI().start << "; right: " << rp->getMeanCI().end << endl;
    cout << "left: " << rp->getMedianCI().start << "; right: " << rp->getMedianCI().end << endl;

    /*EXTRAP::Interval h = calculateLeBoudecConfidenceIntervalFor95( vec );
       cout << h.start << " - " << average << " - " << h.end << endl;

       EXTRAP::Interval i = calculateAsymmetricConfidenceInterval( vec, 0.95 );
       cout << i.start << " - " << average << " - " << i.end << endl;

       EXTRAP::Interval j = computeTConfidenceInterval( average, s, vec.size(), EXTRAP_TVALUES );
       cout << j.start << " - " << average << " - " << j.end << endl;*/

    vals.clear();
    EXTRAP::QuantileApproximator* qa = new EXTRAP::QuantileApproximator( 0.5 );
    for ( int i = 0; i < arr_len; i++ )
    {
        qa->Update( arr2[ i ] );
        vals.push_back( arr2[ i ] );
        double median_computed = testComputeMedian( vals );
        double median_estimate = qa->GetQuantileValue();
        //cout << "median computed: " << median_computed << "; median estimate: " << median_estimate << endl;
        if ( fabs( median_computed - median_estimate ) > 0.5 )
        {
            cout << "Test failed:" << endl
                 << "; median computed: " << median_computed << "; median estimate: " << median_estimate << endl;
            exit( EXIT_FAILURE );
        }
    }

    /*EXTRAP::CubeFileReader* cfr = new EXTRAP::CubeFileReader();
       cfr->prepareCubeFileReader( 0, "/Users/Jonas/Desktop/kripke-results", "kripke.", "d2r1", "profile.cubex", 1 );
       EXTRAP::Parameter* p = new EXTRAP::Parameter( "p" );
       vector<int>*       v = new vector<int>();
       v->push_back( 2 );

       cfr->addParameter( *p, "p", *v );

       EXTRAP::Experiment* ex            = cfr->readCubeFiles( 1 );
       int                 metric_number = 2;

       cout << ex->getMetrics()[ metric_number ]->getName() << endl;
       cout << ex->getPoints( *( ex->getMetrics()[ metric_number ] ), *( ex->getAllCallpaths()[ metric_number ] ) ).size() << endl;
     */

    cout << "Test successful." << endl;

    return 0;
}
