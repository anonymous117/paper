#!/bin/bash

# This script checks out the current trunk, build it and run the test suite.
# If it encounters any error, it will send an error report to the Extra-P
# mailing list.
# It assumes that the scorep-dev tools are in the path.

CUBE_CONFIG="--with-cube=/opt/packages/cube/$CUBE_VERSION"
CPPFLAGS="CPPFLAGS=-I/usr/include/python3.4m"
HDF5_CONFIG="--with-hdf5=/usr/local/hdf5"


check_error()
{
    if [ $? -ne 0 ]; then
	exit 1
    fi
}

set -x

env

if [ "x$QT_VERSION" = "x5" ]; then
    echo "Use QT 5"
    export PYTHONPATH=/opt/packages/sip/4.18.1:/opt/packages/pyqt/5.7:$PYTHONPATH
else
    echo "Use QT 4"
fi

./bootstrap
mkdir _build
cd _build
INSTALL_PATH=$PWD/install
../configure --prefix=$INSTALL_PATH $CUBE_CONFIG $CPPFLAGS $HDF5_CONFIG
check_error

make dist
check_error

tar -xf extrap*.tar.gz
cd extrap*

./configure --prefix=$INSTALL_PATH $CUBE_CONFIG $CPPFLAGS $HDF5_CONFIG
check_error

make
check_error

make install
check_error

make check
check_error

make installcheck
check_error

