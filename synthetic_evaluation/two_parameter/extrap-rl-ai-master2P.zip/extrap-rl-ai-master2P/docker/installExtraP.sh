#!/bin/sh
#svn co --username=$REDMINE_UNAME --password $REDMINE_PWD https://svn.parallel-programming.tu-darmstadt.de/extra-p/branches/EXTRAP_PARAM_SAMPLING_EVAL_FRAMEWORK extrap-repo
cd extrap-repo
./bootstrap
CUBE_HOME=/cube4.4.2
CPPFLAGS="-I/usr/include/python3.5 -std=c++11"
export CPPFLAGS
mkdir vpath
cd vpath
../configure --prefix=/extrap --with-cube=$CUBE_HOME
make install
#make installcheck
